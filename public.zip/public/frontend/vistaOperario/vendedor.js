/*
 * vendedor.js — Panel Operario AgroTrace
 * =======================================
 * Módulos:
 *  1.  Estado global y constantes
 *  2.  Utilidades
 *  3.  Catálogo de productos
 *  4.  Dashboard (corregido)
 *  5.  Filas dinámicas de productos  ← NUEVO
 *  6.  Productor — búsqueda QR/manual
 *  7.  Cliente — formulario de venta
 *  8.  Escáner QR
 *  9.  Registro de compra (multi-producto)  ← ACTUALIZADO
 *  10. Registro de venta  (multi-producto)  ← ACTUALIZADO
 *  11. Historial (con botón Editar)         ← ACTUALIZADO
 *  12. Modal de edición de operación        ← NUEVO
 *  13. Perfil de usuario (con edición)      ← ACTUALIZADO
 *  14. Seguridad — cambio de contraseña     ← NUEVO
 *  15. Foto de perfil
 *  16. Logout
 *  17. Sidebar toggle
 *  18. Event listeners
 *  19. Inicialización
 */

// =============================================
// 1. ESTADO GLOBAL Y CONSTANTES
// =============================================

const API_BASE = "http://localhost:3000/api";

let html5QrCode = null;
let isCameraActive = false;
let currentProductor = null;
let currentCliente = null;
let productos = [];       // catálogo cargado desde API
let preciosActuales = []; // precios activos cargados desde /precios/actual
let comerciantes = []; // lista de comerciantes cargada al iniciar
let rutaActiva = null; // { id_ruta, fecha, estado, n_entregas } — ruta actual del operario
let rutaActivaKgTotal = 0; // suma de kg de entregas de la ruta activa (para preview de precio)
let tipoProductorActual = 'AFILIADO'; // 'AFILIADO' | 'EXTERNO'
let historialCompleto = [];      // todos los registros para filtrado
let perfilData = null;

/**
 * FILAS DINÁMICAS
 * Cada fila: { rowId, productoId, cantidad, precio }
 * rowId es único y solo crece (evita colisiones al eliminar y re-agregar)
 */
let filasCompra = [];
let filasVenta = [];
let filasEdicion = [];   // reutiliza el mismo componente en el modal
let _nextRowId = 0;
function nextRowId() { return _nextRowId++; }

// Operación abierta en el modal de edición
let operacionEnEdicion = null;

// =============================================
// 2. UTILIDADES
// =============================================

function getToken() {
  return localStorage.getItem("token") || "";
}

/**
 * Muestra una alerta coloreada dentro del contenedor indicado.
 * Las de tipo "success" desaparecen solos a los 4 s.
 */
function showAlert(message, type = "error", containerId = "alert-container") {
  const container = document.getElementById(containerId);
  if (!container) return;
  const div = document.createElement("div");
  div.className = `alert ${type === "success" ? "alert-success" : "alert-error"}`;
  div.textContent = message;
  container.innerHTML = "";
  container.appendChild(div);
  if (type === "success") setTimeout(() => { container.innerHTML = ""; }, 4000);
}

function clearAlert(containerId = "alert-container") {
  const c = document.getElementById(containerId);
  if (c) c.innerHTML = "";
}

/**
 * fetch con Authorization Bearer.
 * Lanza Error con el mensaje del servidor si el status no es ok.
 */
async function fetchWithAuth(url, options = {}) {
  const headers = {
    "Content-Type": "application/json",
    ...(options.headers || {}),
    Authorization: `Bearer ${getToken()}`,
  };
  // Prevent stale cache — always fetch fresh data from server
  const method = (options.method || 'GET').toUpperCase();
  const cacheMode = (method === 'GET') ? 'no-store' : 'no-store';
  const response = await fetch(url, { ...options, headers, cache: cacheMode });
  let data;
  try { data = await response.json(); } catch { data = null; }
  if (!response.ok) {
    const errMsg = data
      ? (Array.isArray(data.message) ? data.message.join(', ') : (data.message || data.error || JSON.stringify(data)))
      : `Error ${response.status}`;
    console.error('[API ERROR]', response.status, response.url, errMsg, data);
    throw new Error(errMsg);
  }
  return data;
}

function formatFecha(fecha) {
  if (!fecha) return "—";
  return new Date(fecha).toLocaleDateString("es-CO", {
    day: "2-digit", month: "2-digit", year: "numeric"
  });
}

function formatMoneda(valor) {
  if (valor == null || isNaN(valor)) return "$0";
  return "$" + parseFloat(valor).toLocaleString("es-CO", { minimumFractionDigits: 0 });
}

// =============================================
// 3. CATÁLOGO DE PRODUCTOS
// =============================================

/**
 * Descarga el catálogo de productos y lo guarda en `productos`.
 * Las filas dinámicas lo usan para generar los <option>.
 */
async function cargarProductos() {
  try {
    const data = await fetchWithAuth(`${API_BASE}/productos`);
    productos = Array.isArray(data) ? data : data.productos || [];
  } catch (error) {
    console.warn("Error cargando productos:", error.message);
  }
}

// =============================================
// 3b. PRECIOS ACTUALES (desde módulo admin)
// =============================================

/**
 * Descarga los precios activos para todos los productos.
 * Se guarda en `preciosActuales` y se usa al seleccionar producto en filas.
 */
async function cargarPreciosActuales() {
  try {
    const data = await fetchWithAuth(`${API_BASE}/precios/actual`);
    preciosActuales = Array.isArray(data) ? data : [];
  } catch (error) {
    console.warn("[PRECIOS] Error cargando precios actuales:", error.message);
    preciosActuales = [];
  }
}

/**
 * Devuelve el precio_final_productor activo para un id_producto.
 * Este es el precio que se le PAGA al productor (fórmula 3.5%).
 * SOLO se usa en COMPRAS (entregas). No aplica en ventas.
 *
 * El backend devuelve:
 *   { id_producto, precio_base_kg, precio_final_productor, costo_transporte_kg }
 * Retorna null si no hay precio definido.
 */
function prc_obtenerPrecioProducto(id_producto) {
  const idNum = parseInt(id_producto, 10);
  const encontrado = preciosActuales.find(p => p.id_producto === idNum);
  if (!encontrado) return null;
  // precio_final_productor es el campo correcto del backend nuevo
  // precio_final_kg es el campo del backend viejo — soporte ambos por compatibilidad
  const precio = encontrado.precio_final_productor ?? encontrado.precio_final_kg;
  return precio != null ? parseFloat(precio) : null;
}

/**
 * Calcula el precio de VENTA para un comerciante.
 * SOLO aplica en ventas, NUNCA en entregas/compras al productor.
 *
 * Regla:
 *   - Comerciante "EL PRIMO" → precio_venta = precio_base_kg
 *   - Cualquier otro         → precio_venta = precio_base_kg + 100
 */
function prc_obtenerPrecioVenta(id_producto, nombre_comerciante) {
  const idNum = parseInt(id_producto, 10);
  const encontrado = preciosActuales.find(p => p.id_producto === idNum);
  if (!encontrado) return null;
  const base = parseFloat(encontrado.precio_base_kg);
  const esEspecial = (nombre_comerciante || '').trim().toUpperCase() === 'EL PRIMO';
  return esEspecial ? base : base + 100;
}

// =============================================
// 4. DASHBOARD (CORREGIDO)
// =============================================

/**
 * CORRECCIÓN:
 * Antes mostraba métricas "de hoy" que no coincidían con los títulos
 * de las tarjetas. Ahora muestra totales globales coherentes:
 *   - Tarjeta Compras   → total de operaciones de compra
 *   - Tarjeta Ventas    → total de operaciones de venta
 *   - Tarjeta Productores → productores únicos con compras registradas
 */
async function cargarDashboard() {
  const token = localStorage.getItem("token");
  if (!token) { window.location.href = "../../frontend/login.html"; return; }

  try {
    const data = await fetchWithAuth(`${API_BASE}/operario/historial`);
    // /operario/historial devuelve el array directamente (no envuelto)
    historialCompleto = Array.isArray(data) ? data : [];

    const compras = historialCompleto.filter(r => (r.tipo || "").toUpperCase() === "COMPRA");
    const ventas = historialCompleto.filter(r => (r.tipo || "").toUpperCase() === "VENTA");

    const productoresUnicos = new Set(
      compras.map(r => r.cedula_productor || r.id_productor).filter(Boolean)
    ).size;

    const set = (id, val) => {
      const el = document.getElementById(id);
      if (el) el.textContent = val;
    };

    set("dash-entregas-hoy", compras.length);
    set("dash-kilos-hoy", ventas.length);
    set("dash-productores", productoresUnicos || compras.length);

    // Última operación registrada
    const ultima = historialCompleto[0];
    const ultimaFecha = ultima?.fecha || ultima?.fecha_venta || ultima?.createdAt;
    set("dash-ultima-op", ultimaFecha
      ? new Date(ultimaFecha).toLocaleDateString("es-CO", { day: "2-digit", month: "2-digit", year: "numeric" })
      : "Sin registros");

    // Últimas 5 operaciones en el dashboard
    renderUltimasOps(historialCompleto.slice(0, 5));
  } catch (error) {
    console.warn("Dashboard error:", error.message);
  }
}

function renderUltimasOps(registros) {
  const tbody = document.getElementById("ultimas-ops-body");
  if (!tbody) return;

  if (!registros.length) {
    tbody.innerHTML = `<tr><td colspan="5" class="table-empty">No hay operaciones recientes.</td></tr>`;
    return;
  }

  tbody.innerHTML = registros.map(r => {
    const esCompra = (r.tipo || "").toUpperCase() === "COMPRA";
    const fecha = formatFecha(r.fecha || r.fecha_venta || r.createdAt);
    const tipo = `<span class="badge ${esCompra ? "badge-compra" : "badge-venta"}">${esCompra ? "Compra" : "Venta"}</span>`;
    const quien = esCompra
      ? (r.nombre_productor || `Prod. #${r.id_productor}` || "—")
      : (r.nombre || r.cliente || "Cliente general");
    const producto = r.nombre_producto || "—";
    const total = formatMoneda(r.total);

    return `<tr>
      <td data-label="Fecha">${fecha}</td>
      <td data-label="Tipo">${tipo}</td>
      <td data-label="Poductor / Cliente">${quien}</td>
      <td data-label="Producto">${producto}</td>
      <td data-label="Total"><strong>${total}</strong></td>
    </tr>`;
  }).join("");
}

// =============================================
// 5. FILAS DINÁMICAS DE PRODUCTOS
// =============================================

/** Devuelve el array de estado según el tipo de formulario */
function getFilas(tipo) {
  if (tipo === "compra") return filasCompra;
  if (tipo === "venta") return filasVenta;
  return filasEdicion;
}

function setFilas(tipo, arr) {
  if (tipo === "compra") filasCompra = arr;
  else if (tipo === "venta") filasVenta = arr;
  else filasEdicion = arr;
}

/** Agrega una fila vacía y re-renderiza */
function agregarFila(tipo) {
  getFilas(tipo).push({ rowId: nextRowId(), productoId: "", cantidad: "", precio: "" });
  renderFilas(tipo);
}

/** Elimina la fila por rowId y re-renderiza */
function eliminarFila(tipo, rowId) {
  setFilas(tipo, getFilas(tipo).filter(f => f.rowId !== rowId));
  renderFilas(tipo);
}

/**
 * Genera el bloque HTML de una fila de producto.
 * Usa data-* para identificar tipo y rowId en la delegación de eventos.
 */
function crearFilaHTML(tipo, fila, numero) {
  const { rowId, productoId, cantidad, precio } = fila;

  const opcionesHTML = productos.map(p => {
    const id = p.id_producto || p.id;
    const nombre = p.nombre || p.descripcion || "Producto";
    const precioBase = p.precio_base || p.precio_kg || p.precio || 0;
    const sel = String(id) === String(productoId) ? "selected" : "";
    return `<option value="${id}" data-precio="${precioBase}" ${sel}>${nombre}</option>`;
  }).join("");

  // Opcion "Otro producto" — sin emojis
  const otroSel = productoId === 'otro' ? 'selected' : '';
  const opcionOtro = `<option value="otro" ${otroSel}>+ Otro producto (escribir nombre)</option>`;

  // Input nombre libre (visible solo cuando se elige "Otro")
  const otroVisible = productoId === 'otro' ? '' : 'display:none';
  const otroNombre = fila.otroNombre || '';

  const subtotal = Math.round((parseFloat(cantidad) || 0) * (parseFloat(precio) || 0));

  return `
    <div class="producto-fila" data-row-id="${rowId}">
      <div class="producto-fila-header">
        <span class="producto-numero">Producto ${numero}</span>
        <button type="button" class="btn-eliminar-fila"
          data-tipo="${tipo}" data-row-id="${rowId}" title="Eliminar">x</button>
      </div>
      <div class="producto-fila-body">
        <div class="form-row">
          <div class="form-field">
            <label class="label">Producto</label>
            <select class="input producto-select" data-tipo="${tipo}" data-row-id="${rowId}">
              <option value="">Seleccionar producto</option>
              ${opcionesHTML}
              ${tipo === 'compra' ? opcionOtro : ''}
            </select>
          </div>
          <div class="form-field">
            <label class="label">Cantidad (kg)</label>
            <input type="number" class="input producto-cantidad"
              data-tipo="${tipo}" data-row-id="${rowId}"
              min="0" step="0.01" placeholder="0.00" value="${cantidad}"
              inputmode="decimal" pattern="[0-9]*[.,]?[0-9]*" />
          </div>
        </div>
        <div class="form-field otro-nombre-field" style="${otroVisible};margin:6px 0 10px">
          <label class="label">Nombre del producto</label>
          <input type="text" class="input producto-otro-nombre"
            data-tipo="${tipo}" data-row-id="${rowId}"
            placeholder="Escribe el nombre del producto"
            value="${otroNombre}"
            oninput="fila_onOtroNombreInput('${tipo}', ${rowId}, this.value)" />
        </div>
        <div class="form-row">
          <div class="form-field">
            <label class="label">Precio / kg</label>
            <input type="number" class="input producto-precio"
              data-tipo="${tipo}" data-row-id="${rowId}"
              min="0" step="0.01" placeholder="0.00"
              value="${precio || ""}" readonly />
          </div>
          <div class="form-field">
            <label class="label">Subtotal</label>
            <input type="number" class="input input-total producto-subtotal"
              data-tipo="${tipo}" data-row-id="${rowId}" readonly value="${subtotal.toFixed(2)}" />
          </div>
        </div>
      </div>
    </div>`;
}

/** Re-dibuja el contenedor de filas del tipo indicado */
function renderFilas(tipo) {
  const contenedores = {
    compra: "lista-productos-compra",
    venta: "lista-productos-venta",
    edicion: "lista-productos-edicion"
  };
  const container = document.getElementById(contenedores[tipo]);
  if (!container) return;

  const filas = getFilas(tipo);
  container.innerHTML = filas.length
    ? filas.map((f, i) => crearFilaHTML(tipo, f, i + 1)).join("")
    : `<p class="no-filas-msg">Usa el botón de abajo para agregar productos.</p>`;

  actualizarTotalFormulario(tipo);
}

/** Recalcula el subtotal visual de una fila y el total general */
function calcularSubtotalFila(tipo, rowId) {
  const fila = getFilas(tipo).find(f => f.rowId === rowId);
  if (!fila) return;

  const cantidad = parseFloat(fila.cantidad) || 0;
  const precio = parseFloat(fila.precio) || 0;
  const subtotal = cantidad * precio;

  // Usar data-tipo + data-row-id para encontrar exactamente el elemento correcto
  const subEl = document.querySelector(
    `.producto-subtotal[data-tipo="${tipo}"][data-row-id="${rowId}"]`
  );
  if (subEl) subEl.value = Math.round(subtotal);

  actualizarTotalFormulario(tipo);
}

/** Suma todos los subtotales y los muestra en el total de operación */
function actualizarTotalFormulario(tipo) {
  const filas = getFilas(tipo);
  let total = 0;

  filas.forEach(f => {
    const cantidad = parseFloat(f.cantidad) || 0;
    const precio = parseFloat(f.precio) || 0;
    const sub = cantidad * precio;
    total += sub;

    // Sincronizar también el input visual del subtotal de cada fila
    const subEl = document.querySelector(
      `.producto-subtotal[data-tipo="${tipo}"][data-row-id="${f.rowId}"]`
    );
    if (subEl) subEl.value = Math.round(sub);
  });

  const ids = { compra: "total-compra", venta: "total-venta", edicion: "total-edicion" };
  const el = document.getElementById(ids[tipo]);
  if (el) el.textContent = formatMoneda(total);
}

/**
 * DELEGACIÓN DE EVENTOS para filas dinámicas.
 * Un único listener en document maneja todos los cambios de cualquier fila,
 * independientemente de cuándo fue creada o re-renderizada.
 */
function initProductFilaEvents() {
  // Cambio de producto → precio según TIPO de operación
  //   COMPRA → precio_final_productor  (lo que se le PAGA al productor, fórmula 3.5%)
  //   VENTA  → precio_venta del comerciante (EL PRIMO = base, otros = base + 100)
  //   El campo siempre es readonly: el operario solo ve el precio, no lo edita.
  document.addEventListener("change", (e) => {
    const sel = e.target.closest(".producto-select");
    if (!sel) return;
    const tipo = sel.dataset.tipo;
    const rowId = parseInt(sel.dataset.rowId, 10);

    const fila = getFilas(tipo).find(f => f.rowId === rowId);
    if (!fila) return;

    fila.productoId = sel.value;

    let precioCalculado = null;

    if (sel.value) {
      if (tipo === "venta") {
        // ── VENTA: precio según regla del comerciante ──────────
        // Leer nombre del comerciante del campo de la venta
        const nombreCom = (
          document.getElementById("input-nombre-venta")?.value || ""
        ).trim().toUpperCase();
        precioCalculado = prc_obtenerPrecioVenta(sel.value, nombreCom);
      } else {
        // ── COMPRA / EDICIÓN: precio_final_productor ───────────
        precioCalculado = prc_obtenerPrecioProducto(sel.value);
        // Si el productor es EXTERNO, restar $100/kg
        if (precioCalculado !== null && tipo === 'compra' && tipoProductorActual === 'EXTERNO') {
          precioCalculado = Math.max(0, precioCalculado - 100);
        }
      }
    }

    if (precioCalculado !== null) {
      fila.precio = precioCalculado;
    } else if (sel.value) {
      fila.precio = "";
      const contenedorAlerta = tipo === "venta" ? "alert-venta" : "alert-container";
      showAlert(
        "No hay precio definido para este producto. El admin debe registrar el precio semanal en el módulo PRECIOS.",
        "error",
        contenedorAlerta
      );
    } else {
      fila.precio = "";
    }

    // Actualizar el input de precio (readonly)
    const precioInput = document.querySelector(
      `.producto-precio[data-tipo="${tipo}"][data-row-id="${rowId}"]`
    );
    if (precioInput) {
      precioInput.value = fila.precio > 0 ? Math.round(fila.precio) : "";
    }

    calcularSubtotalFila(tipo, rowId);
  });

  // Cambio de cantidad → recalcula subtotal
  document.addEventListener("input", (e) => {
    const input = e.target.closest(".producto-cantidad");
    if (!input) return;
    const tipo = input.dataset.tipo;
    const rowId = parseInt(input.dataset.rowId, 10);
    const fila = getFilas(tipo).find(f => f.rowId === rowId);
    if (fila) fila.cantidad = input.value;
    calcularSubtotalFila(tipo, rowId);
  });

  // Cambio de select producto → mostrar/ocultar campo "otro nombre"
  document.addEventListener("change", (e) => {
    const sel = e.target.closest(".producto-select");
    if (!sel) return;
    const rowId = parseInt(sel.dataset.rowId, 10);
    const tipo  = sel.dataset.tipo;
    const campoOtro = document.querySelector(`.otro-nombre-field[style*="display"]`)
      || document.querySelector(`.producto-otro-nombre[data-row-id="${rowId}"]`)?.closest('.form-field');
    // Buscar el campo otro-nombre de esta fila específica
    const inputOtro = document.querySelector(`.producto-otro-nombre[data-tipo="${tipo}"][data-row-id="${rowId}"]`);
    const fieldOtro = inputOtro?.closest('.otro-nombre-field');
    if (fieldOtro) {
      fieldOtro.style.display = sel.value === 'otro' ? '' : 'none';
      if (sel.value !== 'otro' && inputOtro) inputOtro.value = '';
    }
    // Limpiar otroNombre en el objeto fila si cambió de "otro" a algo más
    const fila2 = getFilas(tipo).find(f => f.rowId === rowId);
    if (fila2 && sel.value !== 'otro') fila2.otroNombre = '';
  });

  // Clic en eliminar fila
  document.addEventListener("click", (e) => {
    const btn = e.target.closest(".btn-eliminar-fila");
    if (!btn) return;
    eliminarFila(btn.dataset.tipo, parseInt(btn.dataset.rowId, 10));
  });
}

/** Guarda el nombre libre del producto "otro" en el objeto fila */
function fila_onOtroNombreInput(tipo, rowId, valor) {
  const fila = getFilas(tipo).find(f => f.rowId === rowId);
  if (fila) fila.otroNombre = valor.trim();
}

// =============================================
// 6. PRODUCTOR — COMPRA
// =============================================

/**
 * Cambia entre modo AFILIADO (QR/cédula) y EXTERNO (nombre manual).
 * Resetea el productor actual al cambiar de modo.
 */
function prod_setTipo(tipo) {
  tipoProductorActual = tipo;
  currentProductor = null;

  // Botones
  const btnAfil = document.getElementById('btn-tipo-afiliado');
  const btnExt  = document.getElementById('btn-tipo-externo');
  if (btnAfil) {
    btnAfil.className = tipo === 'AFILIADO' ? 'btn btn-primary' : 'btn btn-outline';
    btnAfil.style.flex = '1';
    btnAfil.style.fontSize = '.85rem';
  }
  if (btnExt) {
    btnExt.className = tipo === 'EXTERNO' ? 'btn btn-primary' : 'btn btn-outline';
    btnExt.style.flex = '1';
    btnExt.style.fontSize = '.85rem';
  }

  // Paneles
  const panelAfil = document.getElementById('panel-afiliado');
  const panelExt  = document.getElementById('panel-externo');
  if (panelAfil) panelAfil.style.display = tipo === 'AFILIADO' ? '' : 'none';
  if (panelExt)  panelExt.style.display  = tipo === 'EXTERNO'  ? '' : 'none';

  // Limpiar info del productor
  ['prod-nombre','prod-cedula','prod-ubicacion'].forEach(id => {
    const el = document.getElementById(id);
    if (el) { el.textContent = '—'; el.classList.add('vacio'); }
  });
  const rowTipo = document.getElementById('row-tipo-productor');
  if (rowTipo) rowTipo.style.display = tipo === 'EXTERNO' ? 'flex' : 'none';

  // Limpiar campos externos
  if (tipo === 'AFILIADO') {
    const ne = document.getElementById('input-nombre-externo');
    const te = document.getElementById('input-telefono-externo');
    if (ne) ne.value = '';
    if (te) te.value = '';
  }

  // Recalcular precios en filas de compra (externo = afiliado - 100)
  filasCompra.forEach(fila => {
    if (!fila.productoId) return;
    const precioAfiliado = prc_obtenerPrecioProducto(fila.productoId);
    if (precioAfiliado === null) return;
    fila.precio = tipo === 'EXTERNO' ? Math.max(0, precioAfiliado - 100) : precioAfiliado;
    const inp = document.querySelector(`.producto-precio[data-tipo="compra"][data-row-id="${fila.rowId}"]`);
    if (inp) inp.value = Math.round(fila.precio);
    calcularSubtotalFila('compra', fila.rowId);
  });
}

/**
 * Al escribir el nombre del productor externo, actualiza el panel de info.
 */
function prod_onExternoInput() {
  const nombre    = (document.getElementById('input-nombre-externo')?.value || '').trim();
  const cedula    = (document.getElementById('input-cedula-externo')?.value || '').trim();
  const ubicacion = (document.getElementById('input-ubicacion-externo')?.value || '').trim();
  const telefono  = (document.getElementById('input-telefono-externo')?.value || '').trim();

  const set = (id, val) => {
    const el = document.getElementById(id);
    if (el) { el.textContent = val || '—'; val ? el.classList.remove('vacio') : el.classList.add('vacio'); }
  };
  set('prod-nombre',    nombre || null);
  set('prod-cedula',    cedula || 'Sin cédula');
  set('prod-ubicacion', ubicacion || null);

  // currentProductor solo guarda lo que el backend acepta
  if (nombre) {
    currentProductor = {
      tipo: 'EXTERNO',
      nombre_externo:   nombre,
      telefono_externo: telefono,
    };
  } else {
    currentProductor = null;
  }
}

function llenarDatosProductor(productor) {
  currentProductor = { ...productor, tipo: 'AFILIADO' };
  const set = (id, val) => {
    const el = document.getElementById(id);
    if (el) { el.textContent = val || "—"; el.classList.remove("vacio"); }
  };
  set("prod-nombre", productor.nombre);
  set("prod-cedula", productor.cedula);
  set("prod-ubicacion", productor.finca || productor.ubicacion || productor.direccion);
  // Ocultar badge tipo para afiliados
  const rowTipo = document.getElementById('row-tipo-productor');
  if (rowTipo) rowTipo.style.display = 'none';
}

async function buscarProductorPorCedula(cedula) {
  if (!cedula) { showAlert("Ingresa una cédula para buscar al productor."); return; }
  clearAlert();
  try {
    const data = await fetchWithAuth(
      `${API_BASE}/operario/productor/${encodeURIComponent(cedula)}`
    );
    const productor = data.productor || data;
    if (!productor) { showAlert("No se encontró productor con esa cédula."); return; }
    llenarDatosProductor(productor);
    showAlert("Productor encontrado correctamente.", "success");
  } catch (error) {
    showAlert(`Error al buscar productor: ${error.message}`);
  }
}

// =============================================
// 7. CLIENTE — VENTA (con select de comerciantes)
// =============================================

/**
 * Carga comerciantes desde el backend y puebla el datalist.
 * Se llama al inicializar el panel.
 */
async function cargarComerciantesVenta() {
  try {
    const data = await fetchWithAuth(`${API_BASE}/comerciantes`);
    comerciantes = Array.isArray(data) ? data : (data.data || []);
    const dl = document.getElementById("dl-comerciantes");
    if (!dl) return;
    dl.innerHTML = "";
    comerciantes
      .filter(c => c.activo !== false)
      .forEach(c => {
        const opt = document.createElement("option");
        opt.value = c.nombre;
        opt.dataset.id = c.id_comerciante;
        dl.appendChild(opt);
      });
  } catch (e) {
    console.warn("[COMERCIANTES] Error cargando:", e.message);
  }
}

/**
 * Se dispara mientras el usuario escribe.
 * Actualiza el badge EL PRIMO en tiempo real.
 * También recalcula precios de filas de venta activas.
 */
function com_onInput(valor) {
  const nombre = (valor || "").trim().toUpperCase();

  // Badge EL PRIMO
  const badge = document.getElementById("badge-el-primo");
  if (badge) badge.style.display = (nombre === "EL PRIMO") ? "inline-flex" : "none";

  // Recalcular precios de filas de venta
  filasVenta.forEach(fila => {
    if (!fila.productoId) return;
    const nuevoPrecio = prc_obtenerPrecioVenta(fila.productoId, nombre);
    if (nuevoPrecio === null) return;
    fila.precio = nuevoPrecio;
    const inp = document.querySelector(
      `.producto-precio[data-tipo="venta"][data-row-id="${fila.rowId}"]`
    );
    if (inp) inp.value = Math.round(nuevoPrecio);
    calcularSubtotalFila("venta", fila.rowId);
  });

  // Preview: solo nombre, sin rellenar campos aún
  const setEl = (id, val) => {
    const el = document.getElementById(id);
    if (!el) return;
    el.textContent = val || "—";
    val ? el.classList.remove("vacio") : el.classList.add("vacio");
  };
  setEl("cliente-nombre", valor.trim() || "Sin identificar");

  // Si el usuario borró el campo, limpiar currentCliente
  if (!valor.trim()) {
    currentCliente = null;
    _com_limpiarCampos();
    return;
  }

  // currentCliente provisional (sin id, por si no hay match en BD)
  currentCliente = { nombre: valor.trim(), id_comerciante: null };
}

/**
 * Se dispara cuando el usuario selecciona una opción del datalist
 * o sale del campo (onchange).
 * Rellena teléfono, dirección y fija currentCliente con id_comerciante.
 */
function com_onSelect(valor) {
  if (!valor.trim()) { limpiarFormCliente(); return; }

  const match = comerciantes.find(
    c => c.nombre.trim().toUpperCase() === valor.trim().toUpperCase()
  );

  if (match) {
    // Rellenar campos automáticamente
    const tel = document.getElementById("input-telefono-venta");
    const dir = document.getElementById("input-direccion-venta");
    if (tel) tel.value = match.telefono || "";
    if (dir) dir.value = match.direccion || "";

    // Actualizar preview
    const setEl = (id, val) => {
      const el = document.getElementById(id);
      if (!el) return;
      el.textContent = val || "—";
      val ? el.classList.remove("vacio") : el.classList.add("vacio");
    };
    setEl("cliente-nombre", match.nombre);
    setEl("cliente-telefono", match.telefono || "—");
    const esEspecial = match.nombre.trim().toUpperCase() === "EL PRIMO";
    setEl("cliente-precio-tipo",
      esEspecial ? "Precio base (EL PRIMO)" : "Precio base + $100/kg"
    );

    currentCliente = {
      nombre: match.nombre,
      id_comerciante: match.id_comerciante,
      telefono: match.telefono || "",
      direccion: match.direccion || "",
    };

    // Recalcular precios con el nombre definitivo
    com_onInput(match.nombre);
  }
}

/** Limpia campos de solo lectura */
function _com_limpiarCampos() {
  ["input-telefono-venta", "input-direccion-venta"].forEach(id => {
    const el = document.getElementById(id);
    if (el) el.value = "";
  });
  const setEl = (id, val) => {
    const el = document.getElementById(id);
    if (el) { el.textContent = val; el.classList.add("vacio"); }
  };
  setEl("cliente-nombre", "Sin identificar");
  setEl("cliente-telefono", "—");
  setEl("cliente-precio-tipo", "—");
}

function limpiarFormCliente() {
  currentCliente = null;
  const inp = document.getElementById("input-nombre-venta");
  if (inp) inp.value = "";
  _com_limpiarCampos();
  const badge = document.getElementById("badge-el-primo");
  if (badge) badge.style.display = "none";
}

function initClienteVentaListeners() {
  // El listener principal ya está en los atributos oninput/onchange del HTML.
  // Este hook garantiza que el badge se oculte si el campo está vacío al cargar.
  const inp = document.getElementById("input-nombre-venta");
  if (inp && !inp.value) {
    const badge = document.getElementById("badge-el-primo");
    if (badge) badge.style.display = "none";
  }
}

// =============================================
// 8. ESCANER QR
// =============================================

// Estado del escaner
let _lastScannedCedula = '';
let _scanCooldown = false;

/**
 * Inicia el escaner de QR usando Html5QrcodeScanner (alto nivel).
 * Compatible con la mayoria de navegadores moviles sin necesitar
 * manejo manual de constraints de camara.
 */
function startScanner() {
  if (isCameraActive) return;
  if (!getToken()) { showAlert("No hay token de sesion."); return; }

  const btnActivar    = document.getElementById("btn-activar-camara");
  const btnDesactivar = document.getElementById("btn-desactivar-camara");
  const container     = document.getElementById("qr-reader");

  if (!container) {
    showAlert("Error interno: contenedor del escaner no encontrado.");
    return;
  }

  // Limpiar instancia anterior
  if (html5QrCode) {
    try { html5QrCode.clear(); } catch (_) {}
    html5QrCode = null;
  }
  container.innerHTML = "";

  try {
    // Html5QrcodeScanner maneja internamente la seleccion de camara,
    // los permisos y el renderizado del visor — mucho mas robusto que
    // la API de bajo nivel en moviles.
    html5QrCode = new Html5QrcodeScanner(
      "qr-reader",
      {
        fps: 10,
        qrbox: { width: 220, height: 220 },
        rememberLastUsedCamera: true,
        showTorchButtonIfSupported: true,
        aspectRatio: 1.0,
        videoConstraints: {
          facingMode: "environment",  // camara trasera, sin "exact" para maxima compatibilidad
        },
      },
      /* verbose= */ false
    );

    html5QrCode.render(
      // Exito: se leyo un QR
      (decoded) => {
        if (_scanCooldown) return;
        const cedula = decoded.trim().replace(/\D/g, '') || decoded.trim();
        if (!cedula || cedula === _lastScannedCedula) return;

        _lastScannedCedula = cedula;
        _scanCooldown = true;
        setTimeout(() => { _scanCooldown = false; }, 2500);

        const inputCedula = document.getElementById("input-cedula");
        if (inputCedula) inputCedula.value = cedula;

        // Detener escaner automaticamente tras leer exitosamente
        try { html5QrCode.clear(); } catch (_) {}
        html5QrCode = null;
        isCameraActive = false;
        if (btnActivar)    btnActivar.disabled    = false;
        if (btnDesactivar) btnDesactivar.disabled = true;

        buscarProductorPorCedula(cedula);
        showAlert("QR leido correctamente. Buscando productor...", "success");
      },
      // Error de frame (ignorar — ocurre constantemente cuando no hay QR en camara)
      (_err) => {}
    );

    isCameraActive = true;
    if (btnActivar)    btnActivar.disabled    = true;
    if (btnDesactivar) btnDesactivar.disabled = false;
    showAlert("Camara activada. Apunta al codigo QR del productor.", "success");

  } catch (err) {
    isCameraActive = false;
    if (html5QrCode) {
      try { html5QrCode.clear(); } catch (_) {}
      html5QrCode = null;
    }
    if (btnActivar)    btnActivar.disabled    = false;
    if (btnDesactivar) btnDesactivar.disabled = true;
    showAlert("No se pudo activar la camara: " + (err.message || err));
    console.error("[ESCANER]", err);
  }
}

function stopScanner() {
  const btnActivar    = document.getElementById("btn-activar-camara");
  const btnDesactivar = document.getElementById("btn-desactivar-camara");

  if (html5QrCode) {
    try { html5QrCode.clear(); } catch (_) {}
    html5QrCode = null;
  }

  isCameraActive = false;
  _lastScannedCedula = '';
  _scanCooldown = false;

  const container = document.getElementById("qr-reader");
  if (container) container.innerHTML = "";

  if (btnActivar)    btnActivar.disabled    = false;
  if (btnDesactivar) btnDesactivar.disabled = true;
  showAlert("Camara desactivada.", "success");
}

// =============================================
// 9. REGISTRAR COMPRA — adaptado al backend
// =============================================
async function registrarEntrega(event) {
  event.preventDefault();
  clearAlert();

  // ── Validar productor según tipo ─────────────────────────────────────
  if (tipoProductorActual === 'EXTERNO') {
    const nombreExt = document.getElementById('input-nombre-externo')?.value?.trim();
    const telefonoExt = document.getElementById('input-telefono-externo')?.value?.trim() || '';

    if (!nombreExt) {
      showAlert("Ingresa el nombre del productor externo.", "error");
      return;
    }

    // Cédula y ubicación son informativos — no bloquean el registro
    // porque la entidad Entrega del backend no tiene esas columnas para externos
    currentProductor = {
      tipo: 'EXTERNO',
      nombre_externo: nombreExt,
      telefono_externo: telefonoExt,
    };
  } else {
    if (!currentProductor?.cedula) {
      showAlert("Primero selecciona un productor (escanea QR o busca por cédula).");
      return;
    }
  }

  if (filasCompra.length === 0) {
    showAlert("Agrega al menos un producto a la compra.");
    return;
  }

  for (const fila of filasCompra) {
    if (!fila.productoId) { showAlert("Selecciona un producto en todas las filas."); return; }
    if (fila.productoId === 'otro' && !fila.otroNombre) {
      showAlert("Escribe el nombre del producto en la fila marcada como 'Otro producto'."); return;
    }
    if (!fila.cantidad || parseFloat(fila.cantidad) <= 0) {
      showAlert("Ingresa cantidades válidas en todos los productos."); return;
    }
    if (!rutaActiva && (!fila.precio || parseFloat(fila.precio) <= 0)) {
      showAlert("El precio no está definido. El admin debe registrar los precios en el módulo PRECIOS.");
      return;
    }
  }

  const btn = document.getElementById("btn-registrar-entrega");
  btn.disabled = true;
  btn.textContent = "Registrando...";

  try {
    const payloads = filasCompra.map(fila => {
      const base = {
        tipo_productor: tipoProductorActual,
        id_producto: fila.productoId === 'otro' ? 'otro' : parseInt(fila.productoId, 10),
        nombre_producto_otro: fila.productoId === 'otro' ? (fila.otroNombre || '') : null,
        peso_kg: parseFloat(fila.cantidad),
        precio_unitario: parseFloat(fila.precio),
        ruta_id: rutaActiva ? rutaActiva.id_ruta : null,
        id_usuario: perfilData?.id_usuario || perfilData?.id || null, // ID del operario que registra
        nombre_operario: perfilData?.nombre || null, // Nombre del operario
      };
      if (tipoProductorActual === 'EXTERNO') {
        // Solo los campos que el backend (Entrega entity) soporta:
        // nombre_productor_externo y telefono_productor_externo
        base.nombre_productor_externo  = currentProductor.nombre_externo;
        base.telefono_productor_externo = currentProductor.telefono_externo || null;
      } else {
        base.cedula_productor = currentProductor.cedula;
      }
      return base;
    });

    if (!navigator.onLine) {
      for (const p of payloads) await AgroSync.encolarCompra(p);
      showAlert("Sin internet. Compra guardada localmente — se sincronizará al volver la conexión.", "success");
    } else {
      let exitosasC = 0;
      for (const p of payloads) {
        try {
          await fetchWithAuth(`${API_BASE}/operario/registrar-entrega`, {
            method: "POST",
            body: JSON.stringify(p)
          });
          exitosasC++;
        } catch (err) {
          if (!navigator.onLine || err.name === "TypeError") {
            await AgroSync.encolarCompra(p);
            showAlert("Sin conexión. Compra guardada localmente.", "success");
          } else {
            throw err;
          }
        }
      }
      if (exitosasC > 0) {
        const msgRuta = rutaActiva ? ` — Ruta #${rutaActiva.id_ruta}` : '';
        const msgTipo = tipoProductorActual === 'EXTERNO' ? ' (productor externo)' : '';
        showAlert(`Compra registrada correctamente${msgRuta}${msgTipo}.`, "success");
        if (rutaActiva) {
          fetchWithAuth(`${API_BASE}/rutas/${rutaActiva.id_ruta}/vincular-pendientes`, {
            method: 'POST'
          }).catch(() => {});
          rut_cargarRutas();
        }
      }
    }

    // Limpiar formulario
    filasCompra = [];
    renderFilas("compra");
    currentProductor = null;
    tipoProductorActual = 'AFILIADO';
    prod_setTipo('AFILIADO');

    const cedInput = document.getElementById("input-cedula");
    if (cedInput) cedInput.value = "";
    const nombreExtInput = document.getElementById("input-nombre-externo");
    if (nombreExtInput) nombreExtInput.value = "";
    const cedulaExtInput = document.getElementById("input-cedula-externo");
    if (cedulaExtInput) cedulaExtInput.value = "";
    const ubicacionExtInput = document.getElementById("input-ubicacion-externo");
    if (ubicacionExtInput) ubicacionExtInput.value = "";
    const telExtInput = document.getElementById("input-telefono-externo");
    if (telExtInput) telExtInput.value = "";
    ["prod-nombre", "prod-cedula", "prod-ubicacion"].forEach(id => {
      const el = document.getElementById(id);
      if (el) { el.textContent = "—"; el.classList.add("vacio"); }
    });

    cargarDashboard();
  } catch (error) {
    const msg = error.message || 'Error desconocido';
    showAlert(`Error al registrar la compra: ${msg}`, "error");
  } finally {
    btn.disabled = false;
    btn.textContent = "Registrar compra";
  }
}

// =============================================
// 10. REGISTRAR VENTA — adaptado al backend
// =============================================
async function registrarVenta(event) {
  event.preventDefault();
  clearAlert("alert-venta");

  if (!currentCliente) {
    showAlert("Completa al menos el nombre del cliente.", "error", "alert-venta");
    return;
  }
  if (filasVenta.length === 0) {
    showAlert("Agrega al menos un producto a la venta.", "error", "alert-venta");
    return;
  }

  for (const fila of filasVenta) {
    if (!fila.productoId) { showAlert("Selecciona un producto en todas las filas.", "error", "alert-venta"); return; }
    if (!fila.cantidad || parseFloat(fila.cantidad) <= 0) { showAlert("Ingresa cantidades válidas.", "error", "alert-venta"); return; }
    if (!fila.precio || parseFloat(fila.precio) <= 0) {
      showAlert("El precio de uno o más productos no está definido. El admin debe registrar los precios de la semana en el módulo PRECIOS.", "error", "alert-venta");
      return;
    }
  }

  const btn = document.getElementById("btn-registrar-venta");
  btn.disabled = true;
  btn.textContent = "Registrando...";

  try {
    const payloadsVenta = filasVenta.map(fila => ({
      id_comerciante: currentCliente?.id_comerciante ?? null,
      cliente: currentCliente?.nombre || "Sin comerciante",
      id_usuario: perfilData?.id_usuario || perfilData?.id || null, // ID del operario que registra
      nombre_operario: perfilData?.nombre || null, // Nombre del operario
      detalles: [{
        id_producto: parseInt(fila.productoId, 10),
        cantidad: parseFloat(fila.cantidad),
        precio_unitario: parseFloat(fila.precio),
      }],
    }));

    if (!navigator.onLine) {
      // ── SIN INTERNET: encolar en IndexedDB ──────────────
      for (const p of payloadsVenta) await AgroSync.encolarVenta(p);
      showAlert(
        "Sin internet. Venta guardada localmente — se sincronizará al volver la conexión.",
        "success",
        "alert-venta"
      );
    } else {
      // ── CON INTERNET: enviar al backend ─────────────────
      let exitosasV = 0;
      for (const p of payloadsVenta) {
        try {
          await fetchWithAuth(`${API_BASE}/operario/registrar-venta`, {
            method: "POST",
            body: JSON.stringify(p)
          });
          exitosasV++;
        } catch (err) {
          if (!navigator.onLine || err.name === "TypeError") {
            await AgroSync.encolarVenta(p);
            showAlert("Sin conexión. Venta guardada localmente.", "success", "alert-venta");
          } else {
            throw err;
          }
        }
      }
      if (exitosasV > 0) {
        showAlert("Venta registrada correctamente.", "success", "alert-venta");
      }
    }
    filasVenta = [];
    renderFilas("venta");
    limpiarFormCliente();
    cargarDashboard();
  } catch (error) {
    showAlert(`Error al registrar la venta: ${error.message}`, "error", "alert-venta");
  } finally {
    btn.disabled = false;
    btn.textContent = "Registrar venta";
  }
}

// =============================================
// 11. HISTORIAL
// =============================================

async function cargarHistorial() {
  const token = localStorage.getItem("token");
  if (!token) { window.location.href = "../../frontend/login.html"; return; }

  const tbody = document.getElementById("historial-body");
  if (tbody) tbody.innerHTML = `<tr><td colspan="7" class="table-empty">Cargando...</td></tr>`;

  try {
    const data = await fetchWithAuth(`${API_BASE}/operario/historial`);
    // /operario/historial devuelve el array directamente (no envuelto)
    historialCompleto = Array.isArray(data) ? data : [];
    renderHistorial(historialCompleto);
  } catch (error) {
    if (tbody) tbody.innerHTML = `<tr><td colspan="7" class="table-empty">Error: ${error.message}</td></tr>`;
  }
}

/**
 * Dibuja la tabla del historial.
 * El índice `idx` se pasa al botón Editar para localizar el registro en el array global.
 */
// =============================================
// 11. HISTORIAL — corregido
// =============================================
function renderHistorial(registros) {
  const tbody = document.getElementById("historial-body");
  if (!tbody) return;

  if (!registros?.length) {
    tbody.innerHTML = `<tr><td colspan="7" class="table-empty">No hay registros para mostrar.</td></tr>`;
    return;
  }

  tbody.innerHTML = registros.map((r, idx) => {
    const esCompra = r.tipo === "COMPRA";
    const badgeClass = esCompra ? "badge-compra" : "badge-venta";
    const badgeTexto = esCompra ? "Compra" : "Venta";
    const fecha = formatFecha(r.fecha || r.fecha_venta);

    const quien = esCompra
      ? (r.nombre_productor || `Prod. #${r.id_productor}` || "Sin productor")
      : (r.nombre || r.cliente || "Cliente general");

    const producto = r.nombre_producto || "—";

    const volumen = esCompra
      ? parseFloat(r.peso_kg || 0).toFixed(2) + " kg"
      : parseFloat(r.cantidad_kg || 0).toFixed(2) + " kg";

    // ── Total: null = pendiente de liquidación ──────────────────
    let totalCol;
    if (!esCompra) {
      totalCol = `<strong>${formatMoneda(r.total)}</strong>`;
    } else if (r.total != null && Number(r.total) > 0) {
      totalCol = `<strong>${formatMoneda(r.total)}</strong>`;
    } else {
      // Entrega vinculada a ruta — precio pendiente
      const liq = r.estado_liquidacion || 'PENDIENTE_LIQUIDACION';
      if (liq === 'LIQUIDADO' || liq === 'PAGADO') {
        totalCol = `<strong>${formatMoneda(r.total)}</strong>`;
      } else {
        totalCol = `<span style="color:#d97706;font-size:.8rem;font-weight:600">
          Pendiente${r.ruta_id ? '<br><span style="font-size:.72rem;color:#9ca3af">Ruta #' + r.ruta_id + '</span>' : ''}
        </span>`;
      }
    }

    // ── Badge estado liquidación (solo compras) ─────────────────
    let estadoCol = '';
    if (esCompra) {
      const liq = r.estado_liquidacion || 'PENDIENTE_LIQUIDACION';
      const liqColor = liq === 'PAGADO'
        ? 'background:#d1fae5;color:#065f46'
        : liq === 'LIQUIDADO'
          ? 'background:#dbeafe;color:#1d4ed8'
          : 'background:#fef3c7;color:#92400e';
      const liqLabel = liq === 'PAGADO' ? 'Pagado'
        : liq === 'LIQUIDADO' ? 'Liquidado' : 'Pendiente';
      estadoCol = `<span style="${liqColor};border-radius:99px;padding:2px 8px;font-size:.7rem;font-weight:700">${liqLabel}</span>`;
    }

    return `
      <tr>
        <td data-label="Fecha">${fecha}</td>
        <td data-label="Tipo"><span class="badge ${badgeClass}">${badgeTexto}</span></td>
        <td data-label="Productor / Cliente">${quien}</td>
        <td data-label="Producto">${producto}</td>
        <td data-label="Peso / Cant.">${volumen}</td>
        <td data-label="Total">${totalCol}</td>
        <td data-label="Estado">${estadoCol}</td>
        <td data-label="Acciones">
          <button class="btn btn-secondary btn-editar-op"
            onclick="abrirModalEdicion(${idx})"
            title="Editar esta operación">Editar</button>
        </td>
      </tr>`;
  }).join("");
}

// =============================================
// 12. GUARDAR EDICIÓN — endpoint y payload corregidos
// =============================================
function filtrarHistorial() {
  const fecha = document.getElementById("hist-fecha")?.value || "";
  const cedula = (document.getElementById("hist-cedula")?.value || "").toLowerCase().trim();
  const tipo = document.getElementById("hist-tipo")?.value || "";

  let filtrado = historialCompleto;
  if (fecha) filtrado = filtrado.filter(r => (r.fecha || r.fecha_venta || "").toString().split("T")[0] === fecha);
  if (cedula) filtrado = filtrado.filter(r =>
    (r.cedula_productor || r.cedula || "").toLowerCase().includes(cedula) ||
    (r.nombre_productor || r.nombre || r.cliente || "").toLowerCase().includes(cedula)
  );
  if (tipo) filtrado = filtrado.filter(r => r.tipo === tipo);

  renderHistorial(filtrado);
}

function limpiarFiltros() {
  ["hist-fecha", "hist-cedula"].forEach(id => { const el = document.getElementById(id); if (el) el.value = ""; });
  const tipoEl = document.getElementById("hist-tipo");
  if (tipoEl) tipoEl.value = "";
  renderHistorial(historialCompleto);
}

// =============================================
// 12. MODAL DE EDICIÓN DE OPERACIÓN
// =============================================

/**
 * Abre el modal relleno con los datos del registro seleccionado.
 * idx: posición en historialCompleto (usado para obtener el objeto completo).
 */
function abrirModalEdicion(idx) {
  const operacion = historialCompleto[idx];
  if (!operacion) return;

  operacionEnEdicion = operacion;
  const esCompra = operacion.tipo === "COMPRA";

  // Título
  document.getElementById("modal-titulo").textContent = esCompra ? "Editar Compra" : "Editar Venta";

  // Tipo (readonly) y fecha
  document.getElementById("modal-tipo").value = esCompra ? "Compra" : "Venta";
  const rawFecha = operacion.fecha || operacion.fecha_venta || "";
  document.getElementById("modal-fecha").value = rawFecha.toString().split("T")[0];

  // Mostrar sección correspondiente
  document.getElementById("modal-grupo-productor").style.display = esCompra ? "block" : "none";
  document.getElementById("modal-grupo-cliente").style.display = esCompra ? "none" : "block";

  if (esCompra) {
    document.getElementById("modal-productor-nombre").value = operacion.nombre_productor || operacion.productor || "";
    document.getElementById("modal-productor-cedula").value = operacion.cedula_productor || "";
  } else {
    document.getElementById("modal-cliente-nombre").value = operacion.nombre || operacion.cliente || "";
    document.getElementById("modal-cliente-cedula").value = operacion.cedula || "";
  }

  // Inicializar filas del modal
  // Soporta tanto operaciones con array de productos como con producto único
  const productosOp = Array.isArray(operacion.productos) && operacion.productos.length
    ? operacion.productos
    : [{
      id_producto: operacion.id_producto,
      cantidad: operacion.peso || operacion.cantidad || 0,
      precio_unitario: operacion.precio_unitario || 0
    }];

  filasEdicion = productosOp.map(p => ({
    rowId: nextRowId(),
    productoId: String(p.id_producto || ""),
    cantidad: String(p.cantidad || p.peso_kg || 0),
    precio: String(p.precio_unitario || 0)
  }));

  renderFilas("edicion");
  clearDrawerAlert("modal-alert");

  // Abrir como drawer lateral derecho
  document.getElementById("modal-overlay")?.classList.add("active");
  document.getElementById("modal-edicion").classList.add("active");
  document.body.style.overflow = "hidden";
}

function cerrarModalEdicion() {
  document.getElementById("modal-overlay")?.classList.remove("active");
  document.getElementById("modal-edicion").classList.remove("active");
  document.body.style.overflow = "auto";
  operacionEnEdicion = null;
  filasEdicion = [];
}

/**
 * Construye el payload actualizado y lo envía al servidor.
 * PUT /operario/operacion/:id
 */
async function guardarEdicionOperacion() {
  if (!operacionEnEdicion) return;
  clearDrawerAlert("modal-alert");

  if (filasEdicion.length === 0) {
    showDrawerAlert("Agrega al menos un producto.", "error", "modal-alert"); return;
  }
  for (const f of filasEdicion) {
    if (!f.productoId) { showDrawerAlert("Selecciona un producto en todas las filas.", "error", "modal-alert"); return; }
    if (!f.cantidad || parseFloat(f.cantidad) <= 0) { showDrawerAlert("Ingresa cantidades válidas.", "error", "modal-alert"); return; }
  }

  const btn = document.getElementById("btn-guardar-edicion");
  btn.disabled = true;
  btn.textContent = "Guardando...";

  try {
    const esCompra = operacionEnEdicion.tipo === "COMPRA";
    const fecha = document.getElementById("modal-fecha").value;

    const productosPayload = filasEdicion.map(f => ({
      id_producto: parseInt(f.productoId, 10),
      peso_kg: parseFloat(f.cantidad),
      precio_unitario: Math.round(parseFloat(f.precio)),   // entero, sin decimales
      subtotal: Math.round(parseFloat(f.cantidad) * parseFloat(f.precio))
    }));
    const total = productosPayload.reduce((s, p) => s + p.subtotal, 0);

    // Payload que espera el backend /operario/editar-entrega/:id
    const payload = {
      fecha,
      peso_kg: productosPayload[0]?.peso_kg,
      precio_unitario: productosPayload[0]?.precio_unitario,
      total: Math.round(total),
      productos: productosPayload,
      ...(!esCompra && {
        nombre: document.getElementById("modal-cliente-nombre").value.trim(),
        cedula_cliente: document.getElementById("modal-cliente-cedula").value.trim()
      })
    };

    // ID de la entrega (el backend usa id_entrega)
    const opId = operacionEnEdicion.id_entrega || operacionEnEdicion.id
      || operacionEnEdicion.id_operacion || operacionEnEdicion.id_venta;

    if (!opId) {
      showDrawerAlert("No se pudo identificar la operación a editar.", "error", "modal-alert");
      return;
    }

    await fetchWithAuth(`${API_BASE}/operario/editar-entrega/${opId}`, {
      method: "PUT",
      body: JSON.stringify(payload)
    });

    showDrawerAlert("Operación actualizada correctamente.", "success", "modal-alert");
    setTimeout(() => { cerrarModalEdicion(); cargarHistorial(); cargarDashboard(); }, 1500);
  } catch (error) {
    showDrawerAlert(`Error: ${error.message}`, "error", "modal-alert");
  } finally {
    btn.disabled = false;
    btn.textContent = "Guardar cambios";
  }
}

// Helper: muestra alertas dentro del modal o drawer
function showDrawerAlert(msg, type, containerId = "drawer-alert-perfil") {
  const el = document.getElementById(containerId);
  if (!el) return;
  el.textContent = msg;
  el.className = `drawer-alert active ${type}`;
  if (type === "success") setTimeout(() => el.classList.remove("active"), 3000);
}

function clearDrawerAlert(containerId = "drawer-alert-perfil") {
  const el = document.getElementById(containerId);
  if (el) el.className = "drawer-alert";
}

// =============================================
// 13. PERFIL DE USUARIO
// =============================================

async function cargarPerfil() {
  try {
    const data = await fetchWithAuth(`${API_BASE}/operario/perfil`);
    console.log('[PERFIL DEBUG] Datos recibidos del backend:', data);
    perfilData = data;
    renderPerfil(data);
  } catch (error) {
    console.warn("No se pudo cargar el perfil:", error.message);
  }
}

function renderPerfil(data) {
  if (!data) return;

  // Intentar obtener el nombre de diferentes campos posibles
  const nombre = data.nombre || data.nombre_usuario || data.first_name || "";
  const apellido = data.apellido || data.apellido_usuario || data.last_name || "";
  const nombreCompleto = apellido ? `${nombre} ${apellido}` : nombre;

  // Si aún no hay nombre, intentar extraerlo del email
  const nombreFinal = nombre || (data.email || data.correo || "").split('@')[0] || "Usuario";

  // Campos de sinc (ocultos, usados para leer después)
  const setHidden = (id, val) => {
    const el = document.getElementById(id);
    if (el) el.textContent = val || "—";
  };
  setHidden("perfil-nombre", nombre);
  setHidden("perfil-apellido", apellido);
  setHidden("perfil-email", data.email || data.correo);
  setHidden("perfil-telefono", data.telefono);
  setHidden("perfil-cedula", data.cedula);
  setHidden("perfil-rol", data.rol || data.role || "Operario");

  // Topbar
  const topbarName = document.getElementById("topbar-user-name");
  if (topbarName) topbarName.textContent = nombreFinal;
  const topbarAvatar = document.getElementById("topbar-avatar");
  if (topbarAvatar) topbarAvatar.textContent = (nombreFinal || "U")[0].toUpperCase();
  const topbarRole = document.getElementById("topbar-user-role");
  if (topbarRole) topbarRole.textContent = data.rol || data.role || "Operario";

  // Drawer header
  const set = (id, val) => { const el = document.getElementById(id); if (el) el.textContent = val || "—"; };
  set("drawer-nombre", nombreCompleto);
  set("drawer-cedula-badge", data.cedula);
  set("drawer-rol-badge", (data.rol || data.role || "OPERARIO").toUpperCase());
  set("drawer-email-badge", data.email || data.correo);

  // Campos readonly del tab Info
  const setVal = (id, val) => { const el = document.getElementById(id); if (el) el.value = val || "—"; };
  setVal("drawer-field-nombre", nombreCompleto);
  setVal("drawer-field-cedula", data.cedula);
  setVal("drawer-field-email", data.email || data.correo);
  setVal("drawer-field-telefono", data.telefono);
  setVal("drawer-field-rol", data.rol || data.role || "Operario");

  // Restaurar foto guardada localmente
  const fotoKey = `foto_perfil_${data.id_usuario || data.id}`;
  const foto = localStorage.getItem(fotoKey);
  const fotoEl = document.getElementById("drawer-photo");
  if (fotoEl && foto) fotoEl.src = foto;
}

function openDrawer() {
  document.getElementById("drawer-overlay")?.classList.add("active");
  document.getElementById("drawer")?.classList.add("active");
  document.body.style.overflow = "hidden";
  mostrarVistaReadonly();     // siempre empieza en modo lectura
  activarTabDrawer("info");   // siempre empieza en tab Info
}

function closeDrawer() {
  document.getElementById("drawer-overlay")?.classList.remove("active");
  document.getElementById("drawer")?.classList.remove("active");
  document.body.style.overflow = "auto";
}

/** Activa el tab indicado y muestra su panel */
function activarTabDrawer(tabNombre) {
  document.querySelectorAll(".drawer-tab").forEach(btn => {
    btn.classList.toggle("active", btn.dataset.tab === tabNombre);
  });
  document.querySelectorAll(".tab-pane").forEach(pane => {
    pane.style.display = pane.id === `tab-${tabNombre}` ? "block" : "none";
  });
}

/** Muestra los campos en modo solo lectura */
function mostrarVistaReadonly() {
  document.getElementById("perfil-vista-readonly").style.display = "block";
  document.getElementById("perfil-vista-edicion").style.display = "none";
}

/** Abre el formulario de edición del perfil */
function mostrarVistaEdicion() {
  document.getElementById("perfil-vista-readonly").style.display = "none";
  document.getElementById("perfil-vista-edicion").style.display = "block";
  rellenarFormEdicion();
}

/** Llena el formulario de edición con los valores actuales */
function rellenarFormEdicion() {
  const d = perfilData || {};
  const setVal = (id, val) => { const el = document.getElementById(id); if (el) el.value = val === "—" ? "" : (val || ""); };
  setVal("edit-nombre", d.nombre);
  setVal("edit-apellido", d.apellido);
  setVal("edit-email", d.email || d.correo);
  setVal("edit-telefono", d.telefono);
  setVal("edit-cedula", d.cedula);       // readonly en el HTML
  setVal("edit-rol", d.rol || d.role || "Operario"); // readonly en el HTML
  clearDrawerAlert("drawer-alert-perfil");
}

/**
 * Guarda los cambios del perfil en la API.
 * Cédula y rol no se envían (son solo lectura).
 */
async function guardarPerfil(event) {
  event.preventDefault();
  clearDrawerAlert("drawer-alert-perfil");

  const nombre = document.getElementById("edit-nombre")?.value.trim();
  const apellido = document.getElementById("edit-apellido")?.value.trim();
  const email = document.getElementById("edit-email")?.value.trim();
  const telefono = document.getElementById("edit-telefono")?.value.trim();

  if (!nombre) {
    showDrawerAlert("El nombre es obligatorio.", "error", "drawer-alert-perfil"); return;
  }

  try {
    const body = { nombre };
    if (apellido) body.apellido = apellido;
    if (email) body.email = email;
    if (telefono) body.telefono = telefono;

    const data = await fetchWithAuth(`${API_BASE}/operario/perfil`, {
      method: "PUT",
      body: JSON.stringify(body)
    });

    perfilData = { ...perfilData, ...data };
    renderPerfil(perfilData);
    showDrawerAlert("Perfil actualizado correctamente.", "success", "drawer-alert-perfil");
    setTimeout(() => mostrarVistaReadonly(), 1500);
  } catch (error) {
    showDrawerAlert(`Error: ${error.message}`, "error", "drawer-alert-perfil");
  }
}

// =============================================
// 14. SEGURIDAD — CAMBIO DE CONTRASEÑA
// =============================================

/**
 * Valida las tres contraseñas y envía al backend.
 * Endpoint esperado: POST /operario/cambiar-contrasena
 */
async function cambiarContrasena(event) {
  event.preventDefault();
  clearDrawerAlert("drawer-alert-password");

  const actual = document.getElementById("edit-password-actual")?.value;
  const nueva = document.getElementById("edit-nueva-password")?.value;
  const confirmar = document.getElementById("edit-confirmar-password")?.value;

  if (!actual || !nueva || !confirmar) {
    showDrawerAlert("Completa todos los campos.", "error", "drawer-alert-password"); return;
  }
  if (nueva.length < 8) {
    showDrawerAlert("La nueva contraseña debe tener al menos 8 caracteres.", "error", "drawer-alert-password"); return;
  }
  if (nueva !== confirmar) {
    showDrawerAlert("Las contraseñas nuevas no coinciden.", "error", "drawer-alert-password"); return;
  }

  const btn = document.getElementById("btn-cambiar-password");
  btn.disabled = true;
  btn.textContent = "Guardando...";

  try {
    // El backend actualiza la contraseña via PUT /operario/perfil
    // con el campo 'contrasena' (operario.service.ts → updatePerfil)
    await fetchWithAuth(`${API_BASE}/operario/perfil`, {
      method: "PUT",
      body: JSON.stringify({ contrasena: nueva })
    });

    showDrawerAlert("Contraseña cambiada correctamente.", "success", "drawer-alert-password");
    document.getElementById("form-cambiar-password").reset();
    document.getElementById("password-strength-bar").style.display = "none";
  } catch (error) {
    showDrawerAlert(`Error: ${error.message}`, "error", "drawer-alert-password");
  } finally {
    btn.disabled = false;
    btn.textContent = "Cambiar contraseña";
  }
}

/**
 * Indicador visual de fortaleza de contraseña.
 * Criterios: longitud, mayúsculas, números, caracteres especiales.
 */
function evaluarFortaleza(password) {
  const bar = document.getElementById("password-strength-bar");
  const fill = document.getElementById("strength-fill");
  const label = document.getElementById("strength-label");
  if (!bar || !fill || !label) return;

  if (!password) { bar.style.display = "none"; return; }
  bar.style.display = "flex";

  let score = 0;
  if (password.length >= 8) score++;
  if (password.length >= 12) score++;
  if (/[A-Z]/.test(password)) score++;
  if (/[0-9]/.test(password)) score++;
  if (/[^A-Za-z0-9]/.test(password)) score++;

  const levels = [
    { pct: "20%", color: "#ef4444", text: "Muy débil" },
    { pct: "40%", color: "#f97316", text: "Débil" },
    { pct: "60%", color: "#eab308", text: "Regular" },
    { pct: "80%", color: "#22c55e", text: "Fuerte" },
    { pct: "100%", color: "#16a34a", text: "Muy fuerte" }
  ];
  const level = levels[Math.min(score, 4)];
  fill.style.width = level.pct;
  fill.style.background = level.color;
  label.textContent = level.text;
  label.style.color = level.color;
}

// =============================================
// 15. FOTO DE PERFIL
// =============================================

function cambiarFotoPerfil(event) {
  const file = event.target.files[0];
  if (!file) return;
  const reader = new FileReader();
  reader.onload = (e) => {
    const base64 = e.target.result;
    const fotoKey = `foto_perfil_${perfilData?.id_usuario || perfilData?.id || "user"}`;
    localStorage.setItem(fotoKey, base64);
    const el = document.getElementById("drawer-photo");
    if (el) el.src = base64;
  };
  reader.readAsDataURL(file);
}

// =============================================
// 16. LOGOUT
// =============================================

function logout() { handleLogout(); }
function handleLogout() {
  localStorage.removeItem("token");
  localStorage.removeItem("usuario");
  window.location.href = "../../frontend/login.html";
}

// =============================================
// 17. SIDEBAR TOGGLE
// =============================================

function initSidebarToggle() {
  const sidebar = document.getElementById("sidebar");
  const btnToggle = document.getElementById("btn-toggle-sidebar");
  if (!sidebar || !btnToggle) return;

  // Restaurar estado previo
  if (localStorage.getItem("sidebar-collapsed") === "true") {
    sidebar.classList.add("collapsed");
  }
  btnToggle.addEventListener("click", () => {
    const collapsed = sidebar.classList.toggle("collapsed");
    localStorage.setItem("sidebar-collapsed", collapsed);
  });
}

// =============================================
// 18. EVENT LISTENERS
// =============================================

function initEventListeners() {
  initSidebarToggle();
  initProductFilaEvents(); // delegación de eventos para filas dinámicas

  // --- Cámara ---
  document.getElementById("btn-activar-camara")?.addEventListener("click", startScanner);
  document.getElementById("btn-desactivar-camara")?.addEventListener("click", stopScanner);

  // --- Buscar productor ---
  document.getElementById("btn-buscar-productor")?.addEventListener("click", () => {
    const inputCed = document.getElementById("input-cedula");
    const cedBuscar = (inputCed?.value || '').trim().replace(/\D/g, '') || (inputCed?.value || '').trim();
    buscarProductorPorCedula(cedBuscar);
  });
  document.getElementById("input-cedula")?.addEventListener("keydown", (e) => {
    if (e.key === "Enter") { e.preventDefault(); buscarProductorPorCedula(document.getElementById("input-cedula").value.trim()); }
  });

  // --- Botones agregar producto ---
  document.getElementById("btn-agregar-compra")?.addEventListener("click", () => agregarFila("compra"));
  document.getElementById("btn-agregar-venta")?.addEventListener("click", () => agregarFila("venta"));
  document.getElementById("btn-agregar-edicion")?.addEventListener("click", () => agregarFila("edicion"));

  // --- Formularios de registro ---
  document.getElementById("form-entrega")?.addEventListener("submit", registrarEntrega);
  document.getElementById("form-venta")?.addEventListener("submit", registrarVenta);

  // --- Cliente (actualización en tiempo real) ---
  initClienteVentaListeners();

  // --- Historial ---
  document.getElementById("btn-filtrar-historial")?.addEventListener("click", filtrarHistorial);
  document.getElementById("btn-limpiar-historial")?.addEventListener("click", limpiarFiltros);
  document.getElementById("hist-cedula")?.addEventListener("input", filtrarHistorial);
  document.getElementById("hist-tipo")?.addEventListener("change", filtrarHistorial);

  // --- Drawer ---
  document.querySelector(".topbar-user")?.addEventListener("click", openDrawer);
  document.getElementById("drawer-close")?.addEventListener("click", closeDrawer);
  document.getElementById("drawer-overlay")?.addEventListener("click", (e) => {
    if (e.target.id === "drawer-overlay") closeDrawer();
  });

  // --- Tabs del drawer ---
  document.querySelectorAll(".drawer-tab").forEach(btn => {
    btn.addEventListener("click", () => activarTabDrawer(btn.dataset.tab));
  });

  // --- Edición de perfil ---
  document.getElementById("btn-editar-perfil")?.addEventListener("click", mostrarVistaEdicion);
  document.getElementById("btn-cancelar-edicion")?.addEventListener("click", mostrarVistaReadonly);
  document.getElementById("form-editar-perfil")?.addEventListener("submit", guardarPerfil);

  // --- Seguridad ---
  document.getElementById("form-cambiar-password")?.addEventListener("submit", cambiarContrasena);
  document.getElementById("edit-nueva-password")?.addEventListener("input", (e) => evaluarFortaleza(e.target.value));

  // --- Foto de perfil ---
  document.getElementById("drawer-photo-btn")?.addEventListener("click", () => {
    document.getElementById("input-foto-perfil")?.click();
  });
  document.getElementById("input-foto-perfil")?.addEventListener("change", cambiarFotoPerfil);

  // --- Modal de edición ---
  document.getElementById("modal-close")?.addEventListener("click", cerrarModalEdicion);
  document.getElementById("btn-cancelar-modal")?.addEventListener("click", cerrarModalEdicion);
  document.getElementById("btn-guardar-edicion")?.addEventListener("click", guardarEdicionOperacion);
  document.getElementById("modal-overlay")?.addEventListener("click", cerrarModalEdicion);

  // --- Logout (sidebar y drawer) ---
  document.getElementById("btn-logout")?.addEventListener("click", handleLogout);
  document.getElementById("drawer-btn-logout")?.addEventListener("click", handleLogout);

  // --- Escape: cierra modal o drawer ---
  document.addEventListener("keydown", (e) => {
    if (e.key !== "Escape") return;
    if (document.getElementById("modal-edicion")?.classList.contains("active")) {
      cerrarModalEdicion();
    } else if (document.getElementById("drawer")?.classList.contains("active")) {
      closeDrawer();
    }
  });

  // --- Navegación entre secciones ---
  document.querySelectorAll(".nav-item").forEach(item => {
    item.addEventListener("click", (e) => {
      e.preventDefault();
      const sectionId = item.getAttribute("href").substring(1);
      const section = document.getElementById(sectionId);
      if (!section) return;

      document.querySelectorAll(".nav-item").forEach(n => n.classList.remove("active"));
      document.querySelectorAll(".content-section").forEach(s => s.classList.remove("active"));
      item.classList.add("active");
      section.classList.add("active");

      const titles = {
        "section-dashboard": "Dashboard",
        "section-escanear": "Registrar compra",
        "section-venta": "Registrar venta",
        "section-rutas": "Mis rutas",
        "section-stock": "Stock",
        "section-historial": "Historial"
      };
      const topbarTitle = document.getElementById("topbar-title");
      if (topbarTitle) topbarTitle.textContent = titles[sectionId] || "Dashboard";

      // Cargar datos al entrar a la sección
      if (sectionId === "section-historial" && historialCompleto.length === 0) cargarHistorial();
      if (sectionId === "section-rutas") rut_cargarRutas();
      if (sectionId === "section-stock") stk_op_cargar();
      if (sectionId === "section-dashboard") cargarDashboard();
    });
  });
}


// =============================================
// RUTAS — Gestión desde el operario
// =============================================

/**
 * Carga todas las rutas del día y determina si hay una activa (ABIERTA).
 * Actualiza el panel de estado y el historial.
 */
async function rut_cargarRutas() {
  try {
    const data = await fetchWithAuth(`${API_BASE}/rutas`);
    const rutas = Array.isArray(data) ? data : (data.data || []);

    // Ruta activa = la más reciente que esté ABIERTA
    rutaActiva = rutas.find(r => r.estado === 'ABIERTA') || null;

    // Si hay ruta activa, vincular automaticamente entregas sin ruta
    if (rutaActiva) {
      fetchWithAuth(`${API_BASE}/rutas/${rutaActiva.id_ruta}/vincular-pendientes`, {
        method: 'POST'
      }).catch(() => { }); // silencioso — no bloquear la carga
    }

    rut_actualizarPanel();
    rut_renderHistorial(rutas);

    // Si hay ruta activa, cargar sus entregas
    if (rutaActiva) {
      rut_cargarEntregas(rutaActiva.id_ruta);
    } else {
      document.getElementById('rut-entregas-tbody').innerHTML =
        '<tr><td colspan="3" style="text-align:center;padding:20px;color:#9ca3af">Sin ruta activa</td></tr>';
      document.getElementById('rut-entregas-subtitle').textContent = 'Inicia una ruta para ver las entregas';
    }
  } catch (e) {
    console.warn('[RUTAS] Error cargando:', e.message);
  }
}

function rut_actualizarPanel() {
  const panel = document.getElementById('rut-estado-panel');
  const btnNueva = document.getElementById('btn-nueva-ruta');
  const btnCerrar = document.getElementById('btn-cerrar-ruta');
  const cardActiva = document.getElementById('rut-card-activa');   // tarjeta ruta activa
  const cardEntregas = document.getElementById('rut-card-entregas'); // entregas de la ruta
  if (!panel) return;

  const sinRuta = document.getElementById('rut-sin-ruta');

  if (rutaActiva) {
    // Mostrar tarjetas, ocultar bloque "iniciar"
    if (cardActiva) cardActiva.style.display = '';
    if (cardEntregas) cardEntregas.style.display = '';
    if (sinRuta) sinRuta.style.display = 'none';
    panel.innerHTML = `
      <div style="background:#d1fae5;border-radius:10px;padding:14px 16px">
        <div style="display:flex;justify-content:space-between;align-items:center;margin-bottom:8px">
          <span style="font-weight:800;color:#065f46;font-size:1rem">Ruta #${rutaActiva.id_ruta} — ABIERTA</span>
          <span style="background:#10b981;color:#fff;padding:2px 10px;border-radius:99px;font-size:.75rem;font-weight:700">ACTIVA</span>
        </div>
        <div style="font-size:.85rem;color:#047857">
          Fecha: ${rutaActiva.fecha || 'Hoy'}<br>
          Entregas registradas: <strong>${rutaActiva.n_entregas ?? 0}</strong>
        </div>
        <p style="margin:8px 0 0;font-size:.8rem;color:#065f46;background:#a7f3d0;padding:8px;border-radius:6px">
          Las entregas que registres en Compras quedarán vinculadas a esta ruta.
          Al terminar el recorrido, cierra la ruta con el flete.
        </p>
      </div>`;
    if (btnNueva) btnNueva.style.display = 'none';
    if (btnCerrar) btnCerrar.style.display = 'block';
  } else {
    // Sin ruta activa — ocultar tarjetas completamente, mostrar solo botón iniciar
    if (cardActiva) cardActiva.style.display = 'none';
    if (cardEntregas) cardEntregas.style.display = 'none';
    if (sinRuta) sinRuta.style.display = '';
    if (btnCerrar) btnCerrar.style.display = 'none';
    if (btnNueva) btnNueva.style.display = '';
    if (panel) panel.innerHTML = '';  // limpiar panel vacío
  }
}

async function rut_cargarEntregas(id_ruta) {
  const subtitle = document.getElementById('rut-entregas-subtitle');
  const tbody = document.getElementById('rut-entregas-tbody');
  if (!tbody) return;

  try {
    const data = await fetchWithAuth(`${API_BASE}/rutas/${id_ruta}/entregas`);
    const entregas = Array.isArray(data) ? data : (data.data || []);

    // Actualizar total kg para el preview de precio al cerrar ruta
    rutaActivaKgTotal = entregas.reduce((sum, e) => sum + Number(e.peso_kg || 0), 0);

    if (subtitle) subtitle.textContent = `${entregas.length} entrega${entregas.length !== 1 ? 's' : ''} registradas`;

    if (!entregas.length) {
      if (subtitle) subtitle.textContent = 'Sin entregas registradas en esta ruta';
      tbody.innerHTML = '<tr><td colspan="3" style="text-align:center;padding:20px;color:#9ca3af">Registra compras para verlas aquí</td></tr>';
      return;
    }

    const fmtP = n => n != null ? '$' + Number(n).toLocaleString('es-CO') : 'Pendiente';
    tbody.innerHTML = entregas.map(e => `
      <tr style="border-bottom:1px solid #f3f4f6">
        <td style="padding:8px;font-size:.82rem">${e.nombre_productor || ('Productor #' + e.id_productor)}</td>
        <td style="padding:8px;font-size:.82rem">${e.nombre_producto || ('Prod. #' + e.id_producto)}</td>
        <td style="padding:8px;text-align:center;font-weight:700">${Number(e.peso_kg).toFixed(2)} kg</td>
        <td style="padding:8px;text-align:right;color:#15803d">${e.precio_unitario != null ? fmtP(e.precio_unitario) + '/kg' : 'Pendiente'}</td>
        <td style="padding:8px;text-align:right;font-weight:700">${e.total != null ? fmtP(e.total) : '—'}</td>
      </tr>`).join('');
  } catch (e) {
    console.warn('[RUTAS] Error cargando entregas:', e.message);
  }
}

function rut_renderHistorial(rutas) {
  const tbody = document.getElementById('rut-historial-tbody');
  if (!tbody) return;

  const cerradas = rutas.filter(r => r.estado === 'CERRADA');
  if (!cerradas.length) {
    tbody.innerHTML = '<tr><td colspan="7" style="text-align:center;padding:20px;color:#9ca3af">Sin rutas cerradas</td></tr>';
    return;
  }

  const fmt = n => n != null ? `$${Number(n).toLocaleString('es-CO')}` : '—';
  tbody.innerHTML = cerradas.map(r => `
    <tr style="border-bottom:1px solid #f3f4f6;cursor:pointer"
        onclick="rut_verEntregasRuta(${r.id_ruta}, '${r.fecha || ''}')">
      <td data-label="FECHA" style="padding:8px;font-size:.85em;color:#6b7280">${r.fecha || '—'}</td>
      <td data-label="ENTREGA" style="padding:8px;text-align:center">${r.n_entregas ?? '—'}</td>
      <td data-label="KILOS" style="padding:8px;text-align:right">${r.total_kilos != null ? Number(r.total_kilos).toLocaleString('es-CO') + ' kg' : '—'}</td>
      <td data-label="PRECIO" style="padding:8px;text-align:right;font-weight:700;color:#15803d">${r.precio_final_kg != null ? fmt(r.precio_final_kg) + '/kg' : '—'}</td>
      <td data-label="ESTADO" style="padding:8px;text-align:center">
        <span style="font-size:.75rem;padding:2px 8px;border-radius:99px;background:#d1fae5;color:#065f46;font-weight:700">CERRADA</span>
      </td>
      <td data-label="DETALLE" style="padding:8px;text-align:center">
        <button style="font-size:.75rem;padding:3px 8px;border-radius:6px;background:#f0fdf4;color:#166534;border:1px solid #bbf7d0;cursor:pointer"
                onclick="event.stopPropagation();rut_verEntregasRuta(${r.id_ruta}, '${r.fecha || ''}')">
          Ver entregas
        </button>
      </td>
    </tr>`).join('');
}

async function rut_verEntregasRuta(id_ruta, fecha) {
  try {
    const data = await fetchWithAuth(`${API_BASE}/rutas/${id_ruta}/entregas`);
    const entregas = Array.isArray(data) ? data : (data.data || []);
    const fmt = n => n != null ? '$' + Number(n).toLocaleString('es-CO') : '—';
    const fmtKg = n => n != null ? Number(n).toFixed(2) + ' kg' : '—';

    if (!entregas.length) {
      showAlert('Esta ruta no tiene entregas registradas.', 'error');
      return;
    }

    // Agrupar entregas por productor para el PDF detallado
    const porProductor = {};
    for (const e of entregas) {
      const key = e.id_productor || ('ext_' + (e.nombre_productor || 'desconocido'));
      if (!porProductor[key]) {
        porProductor[key] = {
          nombre: e.nombre_productor || 'Sin nombre',
          cedula: e.cedula_productor || '—',
          productos: [],
          totalProductor: 0,
        };
      }
      const subtotal = Number(e.total) || 0;
      porProductor[key].productos.push({
        nombre: e.nombre_producto || ('Producto #' + e.id_producto),
        cantidad: Number(e.peso_kg) || 0,
        precio_kg: e.precio_unitario != null ? Number(e.precio_unitario) : null,
        subtotal,
      });
      porProductor[key].totalProductor += subtotal;
    }

    const totalGeneral = entregas.reduce((s, e) => s + (Number(e.total) || 0), 0);

    // Construir filas HTML por productor
    const bloquesProductores = Object.values(porProductor).map(prod => {
      const filasProductos = prod.productos.map(p => `
        <tr>
          <td style="padding:6px 8px;padding-left:24px;color:#374151">${p.nombre}</td>
          <td style="padding:6px 8px;text-align:center">${fmtKg(p.cantidad)}</td>
          <td style="padding:6px 8px;text-align:right">${p.precio_kg != null ? fmt(p.precio_kg) + '/kg' : 'Pendiente'}</td>
          <td style="padding:6px 8px;text-align:right;font-weight:600">${p.subtotal > 0 ? fmt(p.subtotal) : '—'}</td>
        </tr>`).join('');

      return `
        <tr style="background:#f0fdf4">
          <td colspan="2" style="padding:8px;font-weight:700;color:#166534">
            ${prod.nombre}
            <span style="font-weight:400;color:#6b7280;font-size:.88em"> — Cedula: ${prod.cedula}</span>
          </td>
          <td colspan="2" style="padding:8px;text-align:right;font-weight:700;color:#15803d">
            ${prod.totalProductor > 0 ? fmt(prod.totalProductor) : '—'}
          </td>
        </tr>
        ${filasProductos}`;
    }).join('');

    const html = `<!DOCTYPE html>
<html lang="es">
<head>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width,initial-scale=1">
  <title>Ruta de Recoleccion #${id_ruta}</title>
  <style>
    * { box-sizing: border-box; margin: 0; padding: 0; }
    body { font-family: Arial, Helvetica, sans-serif; font-size: 13px; color: #111; padding: 24px; max-width: 720px; margin: 0 auto; }
    h1 { font-size: 1.2rem; color: #166534; margin-bottom: 4px; }
    .meta { color: #6b7280; font-size: .88rem; margin-bottom: 20px; }
    table { width: 100%; border-collapse: collapse; margin-top: 8px; }
    thead tr { background: #166534; color: #fff; }
    thead th { padding: 8px; text-align: left; font-size: .85rem; font-weight: 600; }
    thead th:not(:first-child) { text-align: right; }
    thead th:nth-child(2) { text-align: center; }
    tbody tr:nth-child(even):not([style*="background"]) { background: #f9fafb; }
    td { border-bottom: 1px solid #e5e7eb; font-size: .88rem; }
    .total-row { background: #166534 !important; color: #fff; }
    .total-row td { padding: 10px 8px; font-weight: 800; font-size: 1rem; border: none; }
    @media print {
      body { padding: 12px; }
      .no-print { display: none; }
    }
  </style>
</head>
<body>
  <h1>Ruta de Recoleccion #${id_ruta}</h1>
  <p class="meta">Fecha: ${fecha || 'Sin fecha'} &nbsp;|&nbsp; ${entregas.length} entrega(s) registrada(s)</p>

  <table>
    <thead>
      <tr>
        <th>Productor / Producto</th>
        <th style="text-align:center">Cantidad</th>
        <th style="text-align:right">Precio/kg</th>
        <th style="text-align:right">Subtotal</th>
      </tr>
    </thead>
    <tbody>
      ${bloquesProductores}
      <tr class="total-row">
        <td colspan="3">TOTAL GENERAL</td>
        <td style="text-align:right">${fmt(totalGeneral)}</td>
      </tr>
    </tbody>
  </table>

  <p class="no-print" style="margin-top:20px;text-align:center">
    <button onclick="window.print()" style="background:#166534;color:#fff;border:none;padding:10px 28px;border-radius:6px;font-size:1rem;cursor:pointer;font-weight:600">
      Imprimir / Guardar PDF
    </button>
    <button onclick="window.close()" style="background:#f3f4f6;color:#374151;border:1px solid #d1d5db;padding:10px 20px;border-radius:6px;font-size:1rem;cursor:pointer;margin-left:8px">
      Cerrar
    </button>
  </p>
</body>
</html>`;

    const win = window.open('', '_blank', 'width=760,height=600');
    if (!win) { showAlert('El navegador bloqueo la ventana emergente. Permite las ventanas emergentes para este sitio.', 'error'); return; }
    win.document.write(html);
    win.document.close();

  } catch (e) {
    showAlert('Error al cargar entregas: ' + e.message, 'error');
  }
}

async function rut_crearRuta() {
  if (!confirm('¿Iniciar una nueva ruta de recolección para hoy?')) return;
  showAlert('Creando ruta...', 'success');
  try {
    await fetchWithAuth(`${API_BASE}/rutas`, { method: 'POST', body: JSON.stringify({}) });
    await rut_cargarRutas();
    showAlert('Ruta iniciada. Ahora registra las entregas normalmente.', 'success');
  } catch (e) {
    showAlert('Error al crear ruta: ' + e.message, 'error');
  }
}

function rut_previsualizarPrecio() {
  const flete = parseFloat(document.getElementById('rut-input-flete').value) || 0;
  const preview = document.getElementById('rut-preview-precio');
  if (!preview) return;

  const idProducto = rutaActiva?.id_producto;
  const precioInfo = idProducto
    ? (preciosActuales || []).find(p => p.id_producto == idProducto)
    : (preciosActuales?.[0]);
  const precioBase = precioInfo?.precio_base_kg ?? null;
  const totalKg = rutaActivaKgTotal > 0 ? rutaActivaKgTotal : null;

  if (!flete || flete <= 0) { preview.style.display = 'none'; return; }

  if (!precioBase) {
    preview.style.display = 'block';
    preview.style.background = '#fef3c7';
    preview.style.color = '#92400e';
    preview.textContent = 'Sin precio base configurado — el admin debe registrar el precio semanal.';
    return;
  }

  if (!totalKg) {
    preview.style.display = 'block';
    preview.style.background = '#eff6ff';
    preview.style.color = '#1e40af';
    preview.textContent = `Precio base: $${Number(precioBase).toLocaleString('es-CO')}/kg — aún no hay entregas en esta ruta.`;
    return;
  }

  const costoTransporte   = flete / totalKg;
  const precioSinTransp   = Number(precioBase) - costoTransporte;
  const descuento         = precioSinTransp * 0.035;
  const precioFinal       = precioSinTransp - descuento;
  const precioExterno     = Math.max(0, precioFinal - 100);

  if (precioFinal <= 0) {
    preview.style.display = 'block';
    preview.style.background = '#fee2e2';
    preview.style.color = '#991b1b';
    preview.innerHTML =
      `Advertencia: Flete demasiado alto — precio quedaría en $${precioFinal.toFixed(0)}/kg<br>` +
      `<span style="font-size:.78rem;font-weight:400">` +
      `Flete ÷ ${totalKg.toFixed(1)} kg = $${costoTransporte.toFixed(0)}/kg de transporte, ` +
      `base $${Number(precioBase).toLocaleString('es-CO')}. Reduce el flete.</span>`;
  } else {
    preview.style.display = 'block';
    preview.style.background = '#d1fae5';
    preview.style.color = '#065f46';
    preview.innerHTML =
      `Precio afiliado: <strong>$${Math.round(precioFinal).toLocaleString('es-CO')}/kg</strong> &nbsp;|&nbsp; ` +
      `Externo: <strong>$${Math.round(precioExterno).toLocaleString('es-CO')}/kg</strong><br>` +
      `<span style="font-size:.78rem;font-weight:400">` +
      `${totalKg.toFixed(1)} kg — Total est. afiliados: $${Math.round(totalKg * precioFinal).toLocaleString('es-CO')}</span>`;
  }
}

function rut_abrirModalCierre() {
  if (!rutaActiva) {
    showAlert('No hay ninguna ruta activa para cerrar.', 'error');
    return;
  }
  const modal = document.getElementById('rut-modal-cierre');
  if (modal) {
    modal.style.display = 'flex';
    document.getElementById('rut-input-flete').value = '';
    document.getElementById('rut-modal-resultado').style.display = 'none';
    const preview = document.getElementById('rut-preview-precio');
    if (preview) preview.style.display = 'none';
  }
}

function rut_cerrarModal() {
  const modal = document.getElementById('rut-modal-cierre');
  if (modal) modal.style.display = 'none';
}

async function rut_confirmarCierre() {
  const flete = parseFloat(document.getElementById('rut-input-flete').value);
  if (!flete || flete <= 0) {
    showAlert('Ingresa un valor de flete válido.', 'error');
    return;
  }
  if (!rutaActiva) {
    showAlert('No hay ruta activa.', 'error');
    return;
  }

  const btn = document.querySelector('#rut-modal-cierre .btn-primary');
  if (btn) { btn.disabled = true; btn.textContent = 'Calculando...'; }

  try {
    const res = await fetchWithAuth(`${API_BASE}/rutas/${rutaActiva.id_ruta}/cerrar`, {
      method: 'POST',
      body: JSON.stringify({ flete })
    });

    const r = res.ruta || res;
    const calc = res.calculo || {};
    const fmt = n => n != null ? `$${Number(n).toLocaleString('es-CO')}` : '—';

    const resultado = document.getElementById('rut-modal-resultado');
    resultado.style.display = 'block';
    resultado.innerHTML = `
      <strong>Ruta cerrada exitosamente</strong><br>
      Entregas liquidadas: <strong>${res.entregas_liquidadas}</strong><br>
      Total kg: <strong>${calc.total_kilos} kg</strong><br>
      Flete: <strong>${fmt(calc.flete)}</strong><br>
      Precio base: <strong>${fmt(calc.precio_base_kg)}/kg</strong><br>
      Precio final: <strong style="color:#15803d;font-size:1.1rem">${fmt(r.precio_final_kg)}/kg</strong><br>
      <em style="font-size:.78rem">${calc.formula || ''}</em>`;

    // Recargar datos
    await rut_cargarRutas();

    setTimeout(() => rut_cerrarModal(), 4000);
  } catch (e) {
    const msg = e.message || 'Error desconocido';
    // Mensajes amigables para errores comunes
    if (msg.includes('no tiene entregas')) {
      showAlert('Esta ruta no tiene entregas registradas. Registra compras vinculadas a esta ruta antes de cerrarla.', 'error');
    } else if (msg.includes('precio activo')) {
      showAlert('No hay precio configurado para el producto. El admin debe registrar el precio en el módulo PRECIOS.', 'error');
    } else if (msg.includes('precio final calculado')) {
      showAlert('El flete es muy alto — el precio final sería negativo. Verifica el valor del flete.', 'error');
    } else {
      showAlert('Error al cerrar ruta: ' + msg, 'error');
    }
  } finally {
    if (btn) { btn.disabled = false; btn.textContent = 'Calcular y cerrar'; }
  }
}

// =============================================
// 19. INICIALIZACIÓN
// =============================================

function init() {
  const token = localStorage.getItem("token");
  if (!token) {
    window.location.href = "../../frontend/login.html";
    return;
  }

  initEventListeners();
  cargarProductos();           // catálogo de productos
  cargarPreciosActuales();     // precios activos del admin (módulo PRECIOS)
  cargarComerciantesVenta();   // comerciantes para el select de ventas
  rut_cargarRutas();           // rutas del operario

  // Mobile nav — Stock
  const mnavStock = document.getElementById('mnav-stock');
  if (mnavStock) {
    mnavStock.addEventListener('click', () => {
      document.querySelectorAll('.mobile-nav-item').forEach(b => b.classList.remove('active'));
      mnavStock.classList.add('active');
      document.querySelectorAll('.content-section').forEach(s => s.classList.remove('active'));
      const sec = document.getElementById('section-stock');
      if (sec) sec.classList.add('active');
      stk_op_cargar();
    });
  }
  cargarDashboard();
  cargarPerfil();
}

document.addEventListener("DOMContentLoaded", init);

// Recargar historial cuando AgroSync sincronice datos offline
window.addEventListener("agrotrace:sincronizado", () => {
  cargarHistorial();
  cargarDashboard();
  cargarPreciosActuales();  // refrescar precios tras sincronización
});
//  MENÚ USUARIO
let panelAbierto = false;

function togglePanelUsuario() {

  const menu = document.getElementById('hp_menu');
  const chevron = document.getElementById('hp_chevron');

  panelAbierto = !panelAbierto;

  menu.classList.toggle('show', panelAbierto);
  chevron?.classList.toggle('abierto', panelAbierto);
}
document.addEventListener('click', (e) => {

  if (
    panelAbierto &&
    !e.target.closest('.hp-trigger') &&
    !e.target.closest('.hp-menu')
  ) {

    panelAbierto = false;

    document.getElementById('hp_menu')?.classList.remove('show');
    document.getElementById('hp_chevron')?.classList.remove('abierto');
  }

});


// ════════════════════════════════════════════════════════════════════════
//  STOCK — Vista Operario (solo lectura)
// ════════════════════════════════════════════════════════════════════════

let _stk_op_datos = [];

async function stk_op_cargar() {
  try {
    const data = await fetchWithAuth(`${API_BASE}/stock`);
    _stk_op_datos = Array.isArray(data) ? data : [];
    stk_op_renderCards();
    await stk_op_cargarMovimientos();
  } catch (e) {
    console.error('[STOCK-OP]', e.message);
    showAlert('Error al cargar stock: ' + e.message, 'error');
  }
}

function stk_op_renderCards() {
  const container = document.getElementById('stk_op_cards');
  if (!container) return;

  if (!_stk_op_datos.length) {
    container.innerHTML = '<p style="color:#9ca3af;font-size:.85rem;grid-column:1/-1">Sin datos de stock disponibles.</p>';
    return;
  }

  const fmt = n => new Intl.NumberFormat('es-CO', { maximumFractionDigits: 2 }).format(Number(n ?? 0));

  container.innerHTML = _stk_op_datos.map(s => {
    const kilos = Math.max(0, Number(s.kilos_disponibles ?? 0));
    const color = kilos <= 0 ? '#dc2626' : kilos < 50 ? '#d97706' : '#16a34a';
    const bg = kilos <= 0 ? '#fee2e2' : kilos < 50 ? '#fef3c7' : '#f0fdf4';
    const label = kilos <= 0 ? ' Sin stock' : kilos < 50 ? ' Stock bajo' : ' Disponible';

    return '<div style="background:' + bg + ';border-radius:12px;padding:16px;text-align:center">'
      + '<div style="font-size:.78rem;color:' + color + ';font-weight:700;text-transform:uppercase;margin-bottom:6px">' + (s.producto || '—') + '</div>'
      + '<div style="font-size:2rem;font-weight:800;color:' + color + '">' + fmt(kilos) + '</div>'
      + '<div style="font-size:.75rem;color:' + color + ';margin-top:2px">kg disponibles</div>'
      + '<div style="font-size:.72rem;margin-top:6px;font-weight:600;color:' + color + '">' + label + '</div>'
      + '</div>';
  }).join('');
}

async function stk_op_cargarMovimientos() {
  const tbody = document.getElementById('stk_op_tbody');
  if (!tbody) return;

  try {
    const movs = await fetchWithAuth(`${API_BASE}/stock/movimientos`);
    const lista = Array.isArray(movs) ? movs.slice(0, 20) : [];

    if (!lista.length) {
      tbody.innerHTML = '<tr><td colspan="5" style="text-align:center;padding:20px;color:#9ca3af">Sin movimientos recientes</td></tr>';
      return;
    }

    const fmt = n => new Intl.NumberFormat('es-CO', { maximumFractionDigits: 2 }).format(Number(n ?? 0)) + ' kg';
    const fmtF = f => f ? new Date(f).toLocaleDateString('es-CO', { day: '2-digit', month: 'short', year: 'numeric' }) : '—';

    tbody.innerHTML = lista.map(m => {
      var entrada = m.tipo === 'ENTRADA';
      return '<tr style="border-bottom:1px solid #f3f4f6">'
        + '<td data-label="FECHA" style="padding:8px 10px;font-size:.8rem;color:#6b7280">' + fmtF(m.fecha) + '</td>'
        + '<td data-label="TIPO" style="padding:8px 10px"><span style="background:' + (entrada ? '#d1fae5' : '#fee2e2') + ';color:' + (entrada ? '#065f46' : '#dc2626') + ';border-radius:99px;padding:2px 8px;font-size:.7rem;font-weight:700">' + (entrada ? 'Entrada' : 'Salida') + '</span></td>'
        + '<td data-label="PRODUCTO" style="padding:8px 10px;font-weight:600">' + (m.producto || '—') + '</td>'
        + '<td data-label="KILOS" style="padding:8px 10px;text-align:right;font-weight:700;color:' + (entrada ? '#16a34a' : '#dc2626') + '">' + (entrada ? '+' : '-') + fmt(m.kilos) + '</td>'
        + '<td data-label="ORIGEN" style="padding:8px 10px;font-size:.78rem;color:#6b7280">' + (m.referencia_tipo || '—') + ' #' + (m.referencia_id || '—') + '</td>'
        + '</tr>';
    }).join('');
  } catch (e) {
    tbody.innerHTML = '<tr><td colspan="5" style="text-align:center;padding:20px;color:#9ca3af">Error al cargar movimientos</td></tr>';
  }
}

// Polling 30s cuando sección stock está activa
setInterval(function () {
  var sec = document.getElementById('section-stock');
  if (sec && sec.classList.contains('active')) stk_op_cargar();
}, 30000);