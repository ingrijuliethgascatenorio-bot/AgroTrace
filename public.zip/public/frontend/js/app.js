// ── Helpers globales de fecha — AgroTrace ──────────────────────────────────
//
// PROBLEMA: Colombia es UTC-5. Registros a las 9pm llegan del backend como
// "2026-04-11T02:00:00.000Z" (UTC). Sin corrección, el frontend muestra el
// día siguiente.
//
// REGLA:
//   · String 'YYYY-MM-DD' solo  → construir con partes locales (sin desfase)
//   · String con 'T' / ISO UTC  → extraer fecha en zona Bogotá con Intl
//   · Date object               → ídem

/**
 * Convierte cualquier valor de fecha a milisegundos en hora Colombia.
 * Seguro para comparar y ordenar fechas de diferentes fuentes del backend.
 */
function parseFechaLocal(f) {
    if (!f) return 0;
    const s = String(f).trim();
    if (!s) return 0;

    // Caso A: solo fecha 'YYYY-MM-DD' — construir como fecha local
    // (new Date('2026-04-10') es UTC midnight = 7pm del 9 en Colombia → INCORRECTO)
    if (/^\d{4}-\d{2}-\d{2}$/.test(s)) {
        const [y, m, d] = s.split('-').map(Number);
        return new Date(y, m - 1, d).getTime();
    }

    // Caso B: timestamp con hora (ISO UTC, con offset, o Date.toString)
    // Convertir a Bogotá y extraer la fecha correcta
    const ts = new Date(s);
    if (isNaN(ts.getTime())) return 0;
    const colStr = new Intl.DateTimeFormat('en-CA', {
        timeZone: 'America/Bogota',
        year: 'numeric', month: '2-digit', day: '2-digit',
    }).format(ts); // → 'YYYY-MM-DD' en hora Bogotá
    const [y, m, d] = colStr.split('-').map(Number);
    return new Date(y, m - 1, d).getTime();
}

/**
 * Formatea cualquier valor de fecha como string legible en Colombia.
 * Maneja tanto 'YYYY-MM-DD' como timestamps ISO UTC correctamente.
 */
function fmtFechaLocal(f) {
    if (!f) return '—';
    const t = parseFechaLocal(f);
    if (!t) return '—';
    return new Date(t).toLocaleDateString('es-CO', { timeZone: 'America/Bogota' });
}

// ── Helper: fecha actual en hora Colombia ─────────────────────────────────────
function fechaHoyColombia() {
    return new Intl.DateTimeFormat('en-CA', {
        timeZone: 'America/Bogota',
        year: 'numeric', month: '2-digit', day: '2-digit',
    }).format(new Date());
}

// app.js - AgroTrace
// Detección automática de entorno: localhost → dev, cualquier otro host → producción/ngrok
const _BASE_URL = window.location.hostname === 'localhost'
    ? 'http://localhost:3000'
    : ' https://irregular-sycamore-qualified.ngrok-free.dev';
const API_URL    = `${_BASE_URL}/api`;
const STATIC_URL = _BASE_URL;

// ── Obtener usuario autenticado desde JWT / localStorage ───
function obtenerUsuarioDesdeToken() {
    try {
        const token = localStorage.getItem('token') || sessionStorage.getItem('token');
        if (token) {
            // Decodificar payload del JWT (base64url)
            const payload = token.split('.')[1];
            if (payload) {
                const decoded = JSON.parse(atob(payload.replace(/-/g, '+').replace(/_/g, '/')));
                if (decoded && (decoded.nombre || decoded.email)) return decoded;
            }
        }
    } catch (_) { }
    // Fallback: localStorage
    try {
        const u = JSON.parse(localStorage.getItem('usuario') || 'null');
        if (u) return u;
    } catch (_) { }
    return null;
}

// ── Nombre completo del operario autenticado ───────────────
function getNombreOperarioActual() {
    const u = obtenerUsuarioDesdeToken();
    if (!u) return '—';
    const nombre = (u.nombre || '').trim();
    const apellido = (u.apellido || '').trim();
    return [nombre, apellido].filter(Boolean).join(' ') || u.email || '—';
}

// ── Resolver nombre de operario desde registro de BD ───────
function resolverNombreOperario(registro) {
    // Prioridad: campo nombre_operario del backend → relación operario/usuario
    const candidatos = [
        registro.nombre_operario,
        registro.operario?.nombre_completo,
        registro.operario
            ? `${registro.operario.nombre || ''} ${registro.operario.apellido || ''}`.trim()
            : null,
        registro.usuario
            ? `${registro.usuario.nombre || ''} ${registro.usuario.apellido || ''}`.trim()
            : null,
    ];
    for (const c of candidatos) {
        if (c && c.trim() && c.toLowerCase() !== 'usuario prueba') return c.trim();
    }
    return '—';
}

// ── Guard: solo ADMIN y OPERARIO entran aquí ───────────
(function () {
    const token = localStorage.getItem('token') || sessionStorage.getItem('token');
    const usuario = JSON.parse(localStorage.getItem('usuario') || 'null');
    if (!token || !usuario) {
        window.location.replace('./login.html');
        throw new Error('GUARD: sin sesión');
    }
    const rol = usuario.tipo_usuario;
    if (rol === 'PRODUCTOR') {
        window.location.replace('./vista_productor/productor.html');
        throw new Error('GUARD: rol incorrecto');
    }
    if (rol !== 'ADMIN' && rol !== 'OPERARIO') {
        localStorage.removeItem('token');
        localStorage.removeItem('usuario');
        window.location.replace('./login.html');
        throw new Error('GUARD: rol desconocido');
    }
})()

// ── Sidebar toggle ──────────────────────────────────────
const toggle = document.querySelector(".menu-toggle");
const header = document.querySelector(".sidebar");
toggle.addEventListener("click", () => {
    header.classList.toggle("collapsed");
});

// Estado global
let charts = {
    tendencia: null,
    historial: null,
    proyeccion: null,
    tendenciaDetalle: null,
    ranking: null,
    capacidad: null
};

// NAVEGACION
function mostrarSeccion(sectionId) {
    document.querySelectorAll('main .section').forEach(s => {
        s.classList.remove('active');
        s.style.display = 'none';
    });

    const el = document.getElementById(sectionId);
    if (el) {
        el.classList.add('active');
        el.style.display = 'block';
    }

    document.querySelectorAll('.nav-btn').forEach(b => b.classList.remove('active'));
    const btn = document.querySelector(`.nav-btn[data-section="${sectionId}"]`);
    if (btn) btn.classList.add('active');

    // Cargar datos del módulo
    if (sectionId === 'analisis') { analisis_cargarProductores(); analisis_loadProyeccion(); }
    if (sectionId === 'usuarios') usr_cargar();
    if (sectionId === 'productores') prd_cargar();
    if (sectionId === 'productos') pro_cargar();
    if (sectionId === 'compras') cmp_cargar();
    if (sectionId === 'ventas') vnt_cargar();
    if (sectionId === 'comerciantes') com_cargar();
    if (sectionId === 'historial') his_cargar();
    if (sectionId === 'dashboard') cargarDashboard();
    if (sectionId === 'stock') stk_cargar();
}

document.querySelectorAll('.nav-btn').forEach(btn => {
    btn.addEventListener('click', () => {
        mostrarSeccion(btn.dataset.section);
    });
});

/* Mostrar dashboard al cargar*/
window.addEventListener('DOMContentLoaded', () => {
    // Bind sidebar toggle
    document.querySelectorAll('.menu-toggle').forEach(btn => {
        btn.addEventListener('click', e => { e.stopPropagation(); toggleSidebar(); });
    });

    // Ocultar todas menos dashboard
    document.querySelectorAll('main .section').forEach(s => {
        s.style.display = 'none';
        s.classList.remove('active');
    });
    const dash = document.getElementById('dashboard');
    if (dash) { dash.style.display = 'block'; dash.classList.add('active'); }

    // Cargar datos iniciales del dashboard
    cargarDashboard();
});

// Utilidades
function showLoading() {
    document.getElementById('loading').classList.add('show');
}

function hideLoading() {
    document.getElementById('loading').classList.remove('show');
}

function formatNumber(num) {
    return new Intl.NumberFormat('es-CO').format(num);
}

function formatCurrency(num) {
    return new Intl.NumberFormat('es-CO', {
        style: 'currency',
        currency: 'COP',
        minimumFractionDigits: 0
    }).format(num);
}

// Destruir gráfico existente
function destroyChart(chartName) {
    if (charts[chartName]) {
        charts[chartName].destroy();
        charts[chartName] = null;
    }
}

// ==========================================
// 1️⃣ DASHBOARD GENERAL
// ==========================================
async function cargarDashboard() {
    // Saludo y fecha
    const hora = new Date().getHours();
    const saludo = hora < 12 ? 'Buenos días' : hora < 18 ? 'Buenas tardes' : 'Buenas noches';
    const greetEl = document.getElementById('db_greeting_text');
    if (greetEl) greetEl.textContent = saludo;

    const fechaStr = new Date().toLocaleDateString('es-CO', { weekday: 'long', day: 'numeric', month: 'long' });
    const fechaEl = document.getElementById('db_hero_fecha');
    if (fechaEl) fechaEl.textContent = fechaStr;
    const ecoFecha = document.getElementById('db_eco_fecha');
    if (ecoFecha) ecoFecha.textContent = fechaStr;

    try {
        const token = localStorage.getItem('token') || sessionStorage.getItem('token') || '';
        const headers = token ? { Authorization: `Bearer ${token}` } : {};

        // Cargar todo en paralelo
        const [meRes, cRes, vRes, prRes, plRes] = await Promise.allSettled([
            fetch(`${API_URL}/me`, { headers }),
            fetch(`${API_URL}/compras`, { headers }),
            fetch(`${API_URL}/ventas`, { headers }),
            fetch(`${API_URL}/productos`, { headers }),
            fetch(`${API_URL}/productores?todos=true`, { headers }),
        ]);

        // Nombre usuario en hero
        if (meRes.status === 'fulfilled') {
            const me = await meRes.value.json();
            const nombre = me.nombre || me.email || '—';
            const nameEl = document.getElementById('db_hero_nombre_text');
            if (nameEl) nameEl.textContent = nombre;
            const nameEl2 = document.getElementById('db_hero_nombre_text2');
            if (nameEl2) nameEl2.textContent = nombre;
        }
        // Eco greeting sync
        const greetEl2 = document.getElementById('db_greeting_text2');
        if (greetEl2) {
            const h = new Date().getHours();
            greetEl2.textContent = h < 12 ? 'Buenos días' : h < 18 ? 'Buenas tardes' : 'Buenas noches';
        }

        const compras = cRes.status === 'fulfilled' ? await cRes.value.json() : [];
        const ventas = vRes.status === 'fulfilled' ? await vRes.value.json() : [];
        const prods = prRes.status === 'fulfilled' ? await prRes.value.json() : [];
        const prodList = plRes.status === 'fulfilled' ? await plRes.value.json() : [];

        const cArr = Array.isArray(compras) ? compras : [];
        const vArr = Array.isArray(ventas) ? ventas : [];
        const pArr = Array.isArray(prods) ? prods : [];
        const plArr = Array.isArray(prodList) ? prodList : (prodList.data || []);

        // ── Infografía derecha ──
        // Compras
        const totalC = cArr.reduce((s, c) => s + parseFloat(c.total || 0), 0);
        db_animNum('db_stat_compras', cArr.length);
        const subC = document.getElementById('db_stat_compras_monto');
        if (subC) subC.textContent = `$${totalC.toLocaleString('es-CO')} en total`;

        // Ventas
        const totalV = vArr.reduce((s, v) => s + parseFloat(v.total || 0), 0);
        db_animNum('db_stat_ventas', vArr.length);
        const subV = document.getElementById('db_stat_ventas_monto');
        if (subV) subV.textContent = `$${totalV.toLocaleString('es-CO')} en total`;

        // Productores
        const activos = plArr.filter(p => p.estado === 'ACTIVO').length;
        db_animNum('db_stat_prod', plArr.length);
        const subP = document.getElementById('db_stat_prod_sub');
        if (subP) subP.textContent = `${activos} activos · ${plArr.length - activos} inactivos`;

        // Productos
        const disponibles = pArr.filter(p => p.disponible).length;
        db_animNum('db_stat_prods', pArr.length);
        const subPr = document.getElementById('db_stat_prods_sub');
        if (subPr) subPr.textContent = `${disponibles} disponibles`;

        // Animar nodos con entrada escalonada
        document.querySelectorAll('.db-info-node').forEach((n, i) => {
            n.style.opacity = '0';
            n.style.transform = 'translateY(16px)';
            setTimeout(() => {
                n.style.transition = 'opacity .4s ease, transform .4s ease';
                n.style.opacity = '1';
                n.style.transform = 'translateY(0)';
            }, 200 + i * 120);
        });

        // Animar pasos con entrada
        document.querySelectorAll('.db-step').forEach((s, i) => {
            s.style.opacity = '0';
            s.style.transform = 'translateX(-12px)';
            setTimeout(() => {
                s.style.transition = 'opacity .35s ease, transform .35s ease, background .15s, box-shadow .15s';
                s.style.opacity = '1';
                s.style.transform = 'translateX(0)';
            }, 100 + i * 80);
        });

    } catch (e) {
        console.warn('Dashboard error:', e.message);
    }
}

function db_abrirGuia() {
    document.getElementById('db_guia_overlay').classList.add('open');
    document.getElementById('db_guia_modal').classList.add('open');
    document.body.style.overflow = 'hidden';
}

function db_cerrarGuia() {
    document.getElementById('db_guia_overlay').classList.remove('open');
    document.getElementById('db_guia_modal').classList.remove('open');
    document.body.style.overflow = '';
}

function db_animNum(id, target) {
    const el = document.getElementById(id);
    if (!el) return;
    const dur = 900;
    const t0 = performance.now();
    const run = (now) => {
        const p = Math.min((now - t0) / dur, 1);
        const ease = 1 - Math.pow(1 - p, 3);
        el.textContent = Math.round(target * ease).toLocaleString('es-CO');
        if (p < 1) requestAnimationFrame(run);
    };
    requestAnimationFrame(run);
}


function crearGraficoTendenciaDashboard(data) {
    destroyChart('tendencia');

    const ctx = document.getElementById('chart_tendencia');
    charts.tendencia = new Chart(ctx, {
        type: 'bar',
        data: {
            labels: ['Período Anterior (hace 3-6 meses)', 'Período Actual (últimos 3 meses)'],
            datasets: [{
                label: 'Promedio de Producción (kg)',
                data: [data.promedio_anterior, data.promedio_actual],
                backgroundColor: [
                    'rgba(156, 163, 175, 0.7)',
                    data.tendencia === 'Creciente' ? 'rgba(16, 185, 129, 0.7)' :
                        data.tendencia === 'Decreciente' ? 'rgba(239, 68, 68, 0.7)' :
                            'rgba(245, 158, 11, 0.7)'
                ],
                borderColor: [
                    'rgb(156, 163, 175)',
                    data.tendencia === 'Creciente' ? 'rgb(16, 185, 129)' :
                        data.tendencia === 'Decreciente' ? 'rgb(239, 68, 68)' :
                            'rgb(245, 158, 11)'
                ],
                borderWidth: 2
            }]
        },
        options: {
            responsive: true,
            maintainAspectRatio: true,
            plugins: {
                legend: {
                    display: true,
                    position: 'top'
                },
                title: {
                    display: true,
                    text: `Tendencia: ${data.tendencia} (${data.diferencia_porcentual}%)`,
                    font: { size: 16, weight: 'bold' }
                }
            },
            scales: {
                y: {
                    beginAtZero: true,
                    ticks: {
                        callback: function (value) {
                            return value + ' kg';
                        }
                    }
                }
            }
        }
    });
}

// ==========================================
// 2️⃣ HISTORIAL
// ==========================================
async function cargarHistorial() {
    const productor = document.getElementById('historial_productor').value;
    const inicio = document.getElementById('historial_inicio').value;
    const fin = document.getElementById('historial_fin').value;

    showLoading();

    try {
        const response = await fetch(`${API_URL}/estadisticas/historial?id_productor=${productor}&inicio=${inicio}&fin=${fin}`, { headers: { Authorization: `Bearer ${localStorage.getItem('token')}` } });
        const data = await response.json();

        // Actualizar contador
        document.getElementById('historial_count').textContent = `${data.length} registros`;

        // Actualizar tabla
        const tbody = document.getElementById('tabla_historial_body');
        if (data.length === 0) {
            tbody.innerHTML = '<tr><td colspan="5" class="empty-state">No hay registros en este rango de fechas</td></tr>';
        } else {
            tbody.innerHTML = data.map(item => `
                <tr>
                    <td>${item.fecha_produccion}</td>
                    <td><strong>${item.cantidad}</strong></td>
                    <td>${item.unidad}</td>
                    <td>${item.lote || 'N/A'}</td>
                    <td><span class="badge badge-info">${item.estado}</span></td>
                </tr>
            `).join('');
        }

        // Crear gráfico
        crearGraficoHistorial(data);

    } catch (error) {
        console.error('Error:', error);
        alert('Error al cargar el historial');
    } finally {
        hideLoading();
    }
}

function crearGraficoHistorial(data) {
    destroyChart('historial');

    const ctx = document.getElementById('chart_historial');
    charts.historial = new Chart(ctx, {
        type: 'line',
        data: {
            labels: data.map(d => d.fecha_produccion),
            datasets: [{
                label: 'Cantidad Producida (kg)',
                data: data.map(d => parseFloat(d.cantidad)),
                borderColor: 'rgb(102, 126, 234)',
                backgroundColor: 'rgba(102, 126, 234, 0.1)',
                borderWidth: 3,
                fill: true,
                tension: 0.4,
                pointRadius: 5,
                pointHoverRadius: 7,
                pointBackgroundColor: 'rgb(102, 126, 234)',
                pointBorderColor: '#fff',
                pointBorderWidth: 2
            }]
        },
        options: {
            responsive: true,
            maintainAspectRatio: true,
            plugins: {
                legend: {
                    display: true,
                    position: 'top'
                },
                tooltip: {
                    callbacks: {
                        label: function (context) {
                            return `${context.parsed.y} kg`;
                        }
                    }
                }
            },
            scales: {
                y: {
                    beginAtZero: true,
                    ticks: {
                        callback: function (value) {
                            return value + ' kg';
                        }
                    }
                }
            }
        }
    });
}

// ==========================================
// 3️⃣ PROYECCIONES
// ==========================================
async function cargarProyeccion() {
    const productor = document.getElementById('proyeccion_productor').value;
    showLoading();

    try {
        // Proyección
        const proyeccionRes = await fetch(`${API_URL}/estadisticas/proyeccion?id_productor=${productor}`, { headers: { Authorization: `Bearer ${localStorage.getItem('token')}` } });
        const proyeccion = await proyeccionRes.json();

        // Tendencia
        const tendenciaRes = await fetch(`${API_URL}/estadisticas/tendencia?id_productor=${productor}`, { headers: { Authorization: `Bearer ${localStorage.getItem('token')}` } });
        const tendencia = await tendenciaRes.json();

        // Gráficos
        crearGraficoProyeccion(proyeccion);
        crearGraficoTendenciaDetalle(tendencia);

        // Info adicional
        document.getElementById('proyeccion_info').innerHTML = `
            <p><strong> Proyección:</strong> ${proyeccion.proyeccion} ${proyeccion.unidad}</p>
            ${proyeccion.advertencia ? `<p class="badge badge-warning">${proyeccion.advertencia}</p>` :
                `<p><strong>Registros analizados:</strong> ${proyeccion.registros_analizados}</p>`}
        `;

        document.getElementById('tendencia_info').innerHTML = `
            <p><strong> Tendencia:</strong> ${tendencia.tendencia}</p>
            <p><strong>Diferencia:</strong> ${tendencia.diferencia_porcentual}%</p>
            <p><strong>Promedio Actual:</strong> ${tendencia.promedio_actual.toFixed(2)} kg</p>
            <p><strong>Promedio Anterior:</strong> ${tendencia.promedio_anterior.toFixed(2)} kg</p>
        `;

    } catch (error) {
        console.error('Error:', error);
        alert('Error al cargar proyecciones');
    } finally {
        hideLoading();
    }
}

function crearGraficoProyeccion(data) {
    destroyChart('proyeccion');

    const proyeccionValor = parseFloat(data.proyeccion || 0);
    const promedioHistorico = proyeccionValor * 0.9; // Simulado

    const ctx = document.getElementById('chart_proyeccion');
    charts.proyeccion = new Chart(ctx, {
        type: 'doughnut',
        data: {
            labels: ['Proyección Próxima Entrega', 'Promedio Histórico'],
            datasets: [{
                data: [proyeccionValor, promedioHistorico],
                backgroundColor: [
                    'rgba(102, 126, 234, 0.8)',
                    'rgba(118, 75, 162, 0.8)'
                ],
                borderColor: ['rgb(102, 126, 234)', 'rgb(118, 75, 162)'],
                borderWidth: 2
            }]
        },
        options: {
            responsive: true,
            plugins: {
                legend: {
                    position: 'bottom'
                },
                tooltip: {
                    callbacks: {
                        label: function (context) {
                            return `${context.label}: ${context.parsed} kg`;
                        }
                    }
                }
            }
        }
    });
}

function crearGraficoTendenciaDetalle(data) {
    destroyChart('tendenciaDetalle');

    const ctx = document.getElementById('chart_tendencia_detalle');
    charts.tendenciaDetalle = new Chart(ctx, {
        type: 'polarArea',
        data: {
            labels: ['Promedio Anterior', 'Promedio Actual'],
            datasets: [{
                data: [data.promedio_anterior, data.promedio_actual],
                backgroundColor: [
                    'rgba(156, 163, 175, 0.6)',
                    data.tendencia === 'Creciente' ? 'rgba(16, 185, 129, 0.6)' :
                        data.tendencia === 'Decreciente' ? 'rgba(239, 68, 68, 0.6)' :
                            'rgba(245, 158, 11, 0.6)'
                ],
                borderWidth: 2
            }]
        },
        options: {
            responsive: true,
            plugins: {
                legend: {
                    position: 'bottom'
                }
            }
        }
    });
}

// ==========================================
// 4️⃣ RANKING
// ==========================================
async function cargarRanking() {
    const tipo = document.getElementById('ranking_tipo').value;
    showLoading();

    try {
        const response = await fetch(`${API_URL}/estadisticas/ranking?tipo=${tipo}`, { headers: { Authorization: `Bearer ${localStorage.getItem('token')}` } });
        const data = await response.json();

        // Actualizar tabla
        const tbody = document.getElementById('tabla_ranking_body');
        tbody.innerHTML = data.map(item => {
            let medalla = '';
            if (item.posicion === 1) medalla = '<span class="medal medal-gold">#1</span>';
            else if (item.posicion === 2) medalla = '<span class="medal medal-silver">#2</span>';
            else if (item.posicion === 3) medalla = '<span class="medal medal-bronze">#3</span>';

            return `
                <tr>
                    <td><strong>${item.posicion}</strong></td>
                    <td>Productor ${item.id_productor}</td>
                    <td><strong>${formatNumber(item.valor.toFixed(2))}</strong></td>
                    <td>${medalla}</td>
                </tr>
            `;
        }).join('');

        // Crear gráfico
        crearGraficoRanking(data, tipo);

    } catch (error) {
        console.error('Error:', error);
        alert('Error al cargar el ranking');
    } finally {
        hideLoading();
    }
}

function crearGraficoRanking(data, tipo) {
    destroyChart('ranking');

    const ctx = document.getElementById('chart_ranking');

    // Colores degradados
    const colors = data.map((_, index) => {
        const hue = 220 - (index * 15);
        return `hsla(${hue}, 70%, 60%, 0.8)`;
    });

    charts.ranking = new Chart(ctx, {
        type: 'bar',
        data: {
            labels: data.map(d => `Productor ${d.id_productor}`),
            datasets: [{
                label: tipo === 'total' ? 'Total Producido (kg)' :
                    tipo === 'promedio' ? 'Promedio (kg)' :
                        'Frecuencia de Entregas',
                data: data.map(d => d.valor),
                backgroundColor: colors,
                borderColor: colors.map(c => c.replace('0.8', '1')),
                borderWidth: 2
            }]
        },
        options: {
            indexAxis: 'y',
            responsive: true,
            plugins: {
                legend: {
                    display: false
                },
                tooltip: {
                    callbacks: {
                        label: function (context) {
                            return `${context.dataset.label}: ${formatNumber(context.parsed.x)}`;
                        }
                    }
                }
            },
            scales: {
                x: {
                    beginAtZero: true
                }
            }
        }
    });
}

// ==========================================
// 5️⃣ PLANIFICACIÓN
// ==========================================
async function cargarPlanificacion() {
    const precio = parseFloat(document.getElementById('planificacion_precio').value);
    const capacidad = parseFloat(document.getElementById('planificacion_capacidad').value);

    if (!precio || precio <= 0) {
        alert('Ingrese un precio válido');
        return;
    }

    if (!capacidad || capacidad <= 0) {
        alert('Ingrese una capacidad válida');
        return;
    }

    showLoading();

    try {
        const response = await fetch(`${API_URL}/estadisticas/planificacion?precio=${precio}&capacidad=${capacidad}`, { headers: { Authorization: `Bearer ${localStorage.getItem('token')}` } });
        const data = await response.json();

        // Mostrar resultado
        const resultDiv = document.getElementById('planificacion_result');
        resultDiv.innerHTML = `
            <div class="result-card info">
                <div class="result-label">Total Proyectado</div>
                <div class="result-value">${formatNumber(data.total_proyectado)} kg</div>
            </div>
            <div class="result-card info">
                <div class="result-label">Valor Estimado</div>
                <div class="result-value">${formatCurrency(data.total_estimado)}</div>
            </div>
            <div class="result-card ${data.supera_capacidad ? 'danger' : 'success'}">
                <div class="result-label">Capacidad</div>
                <div class="result-value">${formatNumber(data.capacidad)} kg</div>
                <div class="result-subtitle">${data.supera_capacidad ? 'Superada' : 'Suficiente'}</div>
            </div>
        `;

        // Alerta
        resultDiv.innerHTML += `
            <div class="alert-box ${data.supera_capacidad ? 'alert-danger' : 'alert-success'}">
                <span class="alert-icon">${data.supera_capacidad ? '' : ''}</span>
                <span>${data.alerta}</span>
            </div>
        `;

        // Gráfico de capacidad
        crearGraficoCapacidad(data);

    } catch (error) {
        console.error('Error:', error);
        alert('Error al calcular la planificación');
    } finally {
        hideLoading();
    }
}

function crearGraficoCapacidad(data) {
    destroyChart('capacidad');

    const utilizado = Math.min(data.total_proyectado, data.capacidad);
    const disponible = Math.max(0, data.capacidad - data.total_proyectado);
    const exceso = Math.max(0, data.total_proyectado - data.capacidad);

    const ctx = document.getElementById('chart_capacidad');
    charts.capacidad = new Chart(ctx, {
        type: 'doughnut',
        data: {
            labels: ['Utilizado', 'Disponible', 'Exceso'],
            datasets: [{
                data: [utilizado, disponible, exceso],
                backgroundColor: [
                    'rgba(59, 130, 246, 0.8)',
                    'rgba(16, 185, 129, 0.8)',
                    'rgba(239, 68, 68, 0.8)'
                ],
                borderWidth: 2
            }]
        },
        options: {
            responsive: true,
            plugins: {
                legend: {
                    position: 'bottom'
                },
                tooltip: {
                    callbacks: {
                        label: function (context) {
                            return `${context.label}: ${formatNumber(context.parsed)} kg`;
                        }
                    }
                }
            }
        }
    });
}

// Dashboard carga desde DOMContentLoaded en la navegación unificada
// ==========================================
// MÓDULO ANÁLISIS — Sub-tabs
// ==========================================

// Instancias de gráficos propias del módulo análisis
let analisisCharts = { historial: null, tendencia: null, ranking: null, planificacion: null };

function destroyAnalisisChart(name) {
    if (analisisCharts[name]) { analisisCharts[name].destroy(); analisisCharts[name] = null; }
}

// Cambiar sub-pestaña
// ── Cargar productores en selects de análisis ──────────
async function analisis_cargarProductores() {
    try {
        const token = localStorage.getItem('token') || sessionStorage.getItem('token') || '';
        const res = await fetch(`${API_URL}/productores?todos=true`, {
            headers: token ? { Authorization: `Bearer ${token}` } : {}
        });
        const data = await res.json();
        const lista = Array.isArray(data) ? data : (data.data || []);

        // Construir opciones
        const opcionTodos = '<option value="">Todos los productores</option>';
        const opciones = lista.map(p => {
            const nombre = p.usuario
                ? `${p.usuario.nombre} ${p.usuario.apellido || ''}`.trim()
                : (p.nombre || `Productor ${p.id_productor}`);
            return `<option value="${p.id_productor}">${nombre}</option>`;
        }).join('');

        // Llenar todos los selects de análisis
        ['ap_productor', 'ah_productor', 'at_productor'].forEach(id => {
            const sel = document.getElementById(id);
            if (sel) sel.innerHTML = opcionTodos + opciones;
        });
    } catch (e) {
        console.warn('No se pudieron cargar productores para análisis:', e.message);
        // Dejar con opción por defecto
        ['ap_productor', 'ah_productor', 'at_productor'].forEach(id => {
            const sel = document.getElementById(id);
            if (sel) sel.innerHTML = '<option value="">Todos los productores</option>';
        });
    }
}

function switchAnalisisTab(name, btn) {
    document.querySelectorAll('.analisis-panel').forEach(p => p.classList.remove('active'));
    document.querySelectorAll('.an-tab').forEach(b => b.classList.remove('active'));
    document.getElementById('panel-' + name).classList.add('active');
    btn.classList.add('active');
}

// ── PROYECCIÓN ──
async function analisis_loadProyeccion() {
    const id = document.getElementById('ap_productor').value;
    const cards = document.getElementById('ap_cards');
    cards.innerHTML = '<div class="an-kpi-skeleton"></div><div class="an-kpi-skeleton"></div><div class="an-kpi-skeleton"></div><div class="an-kpi-skeleton"></div>';
    // Solo agregar id_productor si hay un productor seleccionado
    const qId = id ? `?id_productor=${id}` : '';
    try {
        const [pRes, tRes] = await Promise.all([
            fetch(`${API_URL}/estadisticas/proyeccion${qId}`, { headers: { Authorization: `Bearer ${localStorage.getItem('token')}` } }),
            fetch(`${API_URL}/estadisticas/tendencia${qId}`, { headers: { Authorization: `Bearer ${localStorage.getItem('token')}` } })
        ]);
        const p = await pRes.json();
        const t = await tRes.json();
        const pVal = parseFloat(p.proyeccion || 0);
        const tTag = t.tendencia === 'Creciente' ? 'ok' : t.tendencia === 'Decreciente' ? 'danger' : 'warn';
        const pTag = p.advertencia ? 'warn' : 'ok';
        const dif = parseFloat(t.diferencia_porcentual || 0);
        cards.innerHTML = `
        <div class="an-kpi">
            <div class="an-kpi-icon green"><i class="fi fi-rr-box"></i></div>
            <span class="an-kpi-label">Próxima entrega</span>
            <span class="an-kpi-value">${pVal} <small style="font-size:.5em;color:#9ca3af">${p.unidad || 'kg'}</small></span>
            <span class="an-kpi-tag ${pTag}">${p.advertencia || `${p.registros_analizados} registros`}</span>
        </div>
        <div class="an-kpi">
            <div class="an-kpi-icon blue"><i class="fi fi-rr-arrow-trend-up"></i></div>
            <span class="an-kpi-label">Tendencia</span>
            <span class="an-kpi-value">${t.tendencia}</span>
            <span class="an-kpi-tag ${tTag}">${dif > 0 ? '+' : ''}${dif}% vs anterior</span>
        </div>
        <div class="an-kpi">
            <div class="an-kpi-icon orange"><i class="fi fi-rr-coins"></i></div>
            <span class="an-kpi-label">Valor proyectado</span>
            <span class="an-kpi-value">${formatCurrency(pVal * 2000)}</span>
            <span class="an-kpi-tag info">a $2,000/kg</span>
        </div>
        <div class="an-kpi">
            <div class="an-kpi-icon purple"><i class="fi fi-rr-target"></i></div>
            <span class="an-kpi-label">Diferencia</span>
            <span class="an-kpi-value">${dif > 0 ? '+' : ''}${dif}%</span>
            <span class="an-kpi-tag neutral">vs período anterior</span>
        </div>`;
    } catch (e) {
        cards.innerHTML = `<div class="an-kpi" style="grid-column:1/-1"><span class="an-kpi-label" style="color:#dc2626">Error: ${e.message}</span></div>`;
    }
}

// ── HISTORIAL ──
async function analisis_loadHistorial() {
    const id = document.getElementById('ah_productor').value;
    const ini = document.getElementById('ah_inicio').value;
    const fin = document.getElementById('ah_fin').value;
    showLoading();
    try {
        const params = new URLSearchParams();
        if (id) params.append('id_productor', id);
        if (ini) params.append('inicio', ini);
        if (fin) params.append('fin', fin);

        const token = localStorage.getItem('token') || '';
        const res = await fetch(`${API_URL}/estadisticas/historial?${params.toString()}`,
            { headers: { Authorization: `Bearer ${token}` } });
        const data = await res.json();
        document.getElementById('ah_count').textContent = `${data.length} registros`;

        // ── Tabla ──
        const tbody = document.getElementById('ah_tbody');
        if (!data.length) {
            tbody.innerHTML = '<tr><td colspan="7" class="empty-state">Sin registros en ese período</td></tr>';
        } else {
            tbody.innerHTML = data.map(r => {
                const fecha = fmtFechaLocal(r.fecha || r.fecha_produccion || '');
                const cantKg = parseFloat(r.cantidad || r.peso_kg || 0);
                const precio = parseFloat(r.precio_unitario || 0);
                const total = parseFloat(r.total || (cantKg * precio) || 0);
                const nombre = r.nombre_productor || `Productor #${r.id_productor}`;
                const prod = r.nombre_producto || `Producto #${r.id_producto}`;
                return `<tr>
                    <td>${fecha}</td>
                    <td>${nombre}</td>
                    <td>${prod}</td>
                    <td><strong>${formatNumber(cantKg)} kg</strong></td>
                    <td>${formatCurrency(precio)}/kg</td>
                    <td><strong style="color:#16a34a">${formatCurrency(total)}</strong></td>
                    <td><span class="badge badge-success">Entregado</span></td>
                  </tr>`;
            }).join('');
        }

        // ── Gráfico kg por fecha ──
        destroyAnalisisChart('historial');
        const ctx = document.getElementById('ah_chart').getContext('2d');
        analisisCharts.historial = new Chart(ctx, {
            type: 'line',
            data: {
                labels: data.map(d => fmtFechaLocal(d.fecha || d.fecha_produccion || '')),
                datasets: [{
                    label: 'kg entregados',
                    data: data.map(d => parseFloat(d.cantidad || d.peso_kg || 0)),
                    borderColor: 'rgb(10,174,10)', backgroundColor: 'rgba(10,174,10,0.1)',
                    borderWidth: 3, fill: true, tension: 0.4, pointRadius: 5,
                    pointBackgroundColor: 'rgb(10,174,10)', pointBorderColor: '#fff', pointBorderWidth: 2
                }]
            },
            options: { responsive: true, plugins: { legend: { display: false } }, scales: { y: { beginAtZero: true } } }
        });
    } catch (e) {
        document.getElementById('ah_tbody').innerHTML =
            `<tr><td colspan="7" class="empty-state" style="color:red">Error: ${e.message}</td></tr>`;
    } finally { hideLoading(); }
}

// ── TENDENCIA ──
async function analisis_loadTendencia() {
    const id = document.getElementById('at_productor').value;
    showLoading();
    try {
        const qId = id ? `?id_productor=${id}` : '';
        const token = localStorage.getItem('token') || '';
        const res = await fetch(`${API_URL}/estadisticas/tendencia${qId}`,
            { headers: { Authorization: `Bearer ${token}` } });
        const d = await res.json();

        const tClass = d.tendencia === 'Creciente' ? 'ok' : d.tendencia === 'Decreciente' ? 'danger' : 'warn';
        const dif = parseFloat(d.diferencia_porcentual || 0);

        document.getElementById('at_cards').innerHTML = `
        <div class="an-kpi">
            <div class="an-kpi-icon blue"><i class="fi fi-rr-stats"></i></div>
            <span class="an-kpi-label">Tendencia</span>
            <span class="an-kpi-value">${d.tendencia}</span>
            <span class="an-kpi-tag ${tClass}">${dif > 0 ? '+' : ''}${dif}%</span>
        </div>
        <div class="an-kpi">
            <div class="an-kpi-icon green"><i class="fi fi-rr-weight"></i></div>
            <span class="an-kpi-label">Promedio últimos 3 meses</span>
            <span class="an-kpi-value">${parseFloat(d.promedio_actual).toFixed(1)} <small style="font-size:.5em;color:#9ca3af">kg</small></span>
            <span class="an-kpi-tag info">${d.n_entregas_actual || 0} entregas</span>
        </div>
        <div class="an-kpi">
            <div class="an-kpi-icon orange"><i class="fi fi-rr-coins"></i></div>
            <span class="an-kpi-label">Total pagado (3 meses)</span>
            <span class="an-kpi-value">${formatCurrency(d.total_dinero_actual || 0)}</span>
            <span class="an-kpi-tag ok">precio_final_productor</span>
        </div>`;

        destroyAnalisisChart('tendencia');
        const ctx = document.getElementById('at_chart').getContext('2d');
        analisisCharts.tendencia = new Chart(ctx, {
            type: 'bar',
            data: {
                labels: ['3 meses anteriores', 'Últimos 3 meses'],
                datasets: [{
                    label: 'Promedio kg/entrega',
                    data: [parseFloat(d.promedio_anterior), parseFloat(d.promedio_actual)],
                    backgroundColor: [
                        'rgba(156,163,175,0.7)',
                        d.tendencia === 'Creciente' ? 'rgba(10,174,10,0.8)'
                            : d.tendencia === 'Decreciente' ? 'rgba(239,68,68,0.8)'
                                : 'rgba(245,158,11,0.8)'
                    ],
                    borderRadius: 8, borderWidth: 2
                }]
            },
            options: {
                responsive: true,
                plugins: { legend: { display: false } },
                scales: { y: { beginAtZero: true } }
            }
        });
    } catch (e) {
        document.getElementById('at_cards').innerHTML =
            `<div class="an-kpi" style="grid-column:1/-1"><span class="an-kpi-label" style="color:#dc2626">Error: ${e.message}</span></div>`;
    } finally { hideLoading(); }
}

// ── RANKING ──
async function analisis_loadRanking() {
    const tipo = document.getElementById('ar_tipo').value;
    const inicio = document.getElementById('ar_inicio')?.value || '';
    const fin = document.getElementById('ar_fin')?.value || '';
    const labels = { total: 'Total kg entregados', promedio: 'Promedio kg/entrega', frecuencia: 'Nº de entregas' };
    document.getElementById('ar_tipo_label').textContent = labels[tipo] || tipo;
    showLoading();
    try {
        const params = new URLSearchParams({ tipo });
        if (inicio) params.append('inicio', inicio);
        if (fin) params.append('fin', fin);

        const token = localStorage.getItem('token') || '';
        const res = await fetch(`${API_URL}/estadisticas/ranking?${params.toString()}`,
            { headers: { Authorization: `Bearer ${token}` } });
        const data = await res.json();

        // Guardar para exportación
        _ranking_data = Array.isArray(data) ? data : [];

        const tbody = document.getElementById('ar_tbody');
        tbody.innerHTML = _ranking_data.length ? _ranking_data.map(r => {
            const medalla = r.posicion === 1 ? '#1' : r.posicion === 2 ? '#2' : r.posicion === 3 ? '#3' : `#${r.posicion}`;
            const nombre = (r.nombre && r.nombre.trim()) ? r.nombre.trim() : `Productor ${r.id_productor}`;
            const valorFmt = tipo === 'frecuencia'
                ? `${r.valor} entregas`
                : `${formatNumber(parseFloat(r.valor).toFixed(1))} kg`;
            const pagadoFmt = r.total_pagado ? formatCurrency(r.total_pagado) : '—';
            return `<tr>
                <td style="font-weight:800;color:#111827;font-size:1.1em">${medalla}</td>
                <td>
                    <strong>${nombre}</strong>
                    ${r.finca ? `<br><small style="color:#9ca3af">${r.finca}</small>` : ''}
                    ${r.cedula ? `<br><small style="color:#9ca3af">CC ${r.cedula}</small>` : ''}
                </td>
                <td style="font-weight:700">${valorFmt}</td>
                <td style="color:#16a34a;font-weight:600">${pagadoFmt}</td>
              </tr>`;
        }).join('') : '<tr><td colspan="4" class="empty-state">Sin datos de entregas</td></tr>';

        destroyAnalisisChart('ranking');
        const colors = _ranking_data.map((_, i) => `hsla(${130 - i * 12},65%,45%,0.85)`);
        const ctx = document.getElementById('ar_chart').getContext('2d');
        analisisCharts.ranking = new Chart(ctx, {
            type: 'bar',
            data: {
                labels: _ranking_data.map(d => (d.nombre && d.nombre.trim()) ? d.nombre.trim() : `#${d.id_productor}`),
                datasets: [{ data: _ranking_data.map(d => d.valor), backgroundColor: colors, borderRadius: 6 }]
            },
            options: {
                indexAxis: 'y', responsive: true,
                plugins: { legend: { display: false } },
                scales: { x: { beginAtZero: true } }
            }
        });
    } catch (e) {
        document.getElementById('ar_tbody').innerHTML =
            `<tr><td colspan="4" class="empty-state" style="color:red">Error: ${e.message}</td></tr>`;
    } finally { hideLoading(); }
}

// ── PLANIFICACIÓN ──
async function analisis_loadPlanificacion() {
    const precio = parseFloat(document.getElementById('apl_precio').value);
    const capacidad = parseFloat(document.getElementById('apl_capacidad').value);
    if (!precio || precio <= 0) { alert('Ingrese un precio válido'); return; }
    if (!capacidad || capacidad <= 0) { alert('Ingrese una capacidad válida'); return; }
    showLoading();
    try {
        const res = await fetch(`${API_URL}/estadisticas/planificacion?precio=${precio}&capacidad=${capacidad}`, { headers: { Authorization: `Bearer ${localStorage.getItem('token')}` } });
        const d = await res.json();

        document.getElementById('apl_alert').innerHTML = `
            <div class="an-alert ${d.supera_capacidad ? 'danger' : 'ok'}">
                <i class="fi fi-rr-${d.supera_capacidad ? 'triangle-warning' : 'check'}"></i>
                <span>${d.alerta}</span>
            </div>`;

        document.getElementById('apl_cards').innerHTML = `
        <div class="an-kpi">
            <div class="an-kpi-icon blue"><i class="fi fi-rr-weight"></i></div>
            <span class="an-kpi-label">Total proyectado</span>
            <span class="an-kpi-value">${formatNumber(d.total_proyectado)} <small style="font-size:.45em;color:#9ca3af">kg</small></span>
            <span class="an-kpi-tag info">suma de proyecciones</span>
        </div>
        <div class="an-kpi">
            <div class="an-kpi-icon orange"><i class="fi fi-rr-coins"></i></div>
            <span class="an-kpi-label">Valor estimado</span>
            <span class="an-kpi-value">${formatCurrency(d.total_estimado)}</span>
            <span class="an-kpi-tag info">al precio indicado</span>
        </div>
        <div class="an-kpi">
            <div class="an-kpi-icon ${d.supera_capacidad ? 'red' : 'green'}"><i class="fi fi-rr-truck-side"></i></div>
            <span class="an-kpi-label">Capacidad</span>
            <span class="an-kpi-value">${formatNumber(d.capacidad)} <small style="font-size:.45em;color:#9ca3af">kg</small></span>
            <span class="an-kpi-tag ${d.supera_capacidad ? 'danger' : 'ok'}">${d.supera_capacidad ? 'Superada' : 'Suficiente'}</span>
        </div>`;

        destroyAnalisisChart('planificacion');
        const utilizado = Math.min(d.total_proyectado, d.capacidad);
        const disponible = Math.max(0, d.capacidad - d.total_proyectado);
        const exceso = Math.max(0, d.total_proyectado - d.capacidad);
        const ctx = document.getElementById('apl_chart').getContext('2d');
        analisisCharts.planificacion = new Chart(ctx, {
            type: 'doughnut',
            data: {
                labels: ['Utilizado', 'Disponible', 'Exceso'],
                datasets: [{
                    data: [utilizado, disponible, exceso],
                    backgroundColor: ['rgba(59,130,246,0.8)', 'rgba(10,174,10,0.8)', 'rgba(239,68,68,0.8)'],
                    borderWidth: 2
                }]
            },
            options: { responsive: true, plugins: { legend: { position: 'bottom' } } }
        });
    } catch (e) {
        document.getElementById('apl_alert').innerHTML = `<div class="an-alert danger"><i class="fi fi-rr-triangle-warning"></i><span>Error: ${e.message}</span></div>`;
    } finally { hideLoading(); }
}

// ════════════════════════════════════════════════════════
//  PERFIL DE USUARIO
const ROL_GRADIENTS = {
    ADMIN: 'linear-gradient(135deg,#fbbf24,#d97706)',
    OPERARIO: 'linear-gradient(135deg,#a78bfa,#7c3aed)',
    PRODUCTOR: 'linear-gradient(135deg,#0aae0a,#1b5e20)',
};
const ROL_HERO_BG = {
    ADMIN: 'linear-gradient(135deg,#fffbeb,#fef3c7)',
    OPERARIO: 'linear-gradient(135deg,#f5f3ff,#ede9fe)',
    PRODUCTOR: 'linear-gradient(135deg,#f0fdf4,#dcfce7)',
};
const ROL_BADGE_CLASS = {
    ADMIN: 'hp-rol-ADMIN',
    OPERARIO: 'hp-rol-OPERARIO',
    PRODUCTOR: 'hp-rol-PRODUCTOR',
};
const ROL_LABEL = {
    ADMIN: 'Administrador', OPERARIO: 'Operario', PRODUCTOR: 'Productor',
};
const PERMISO_LABEL = {
    dashboard: 'Dashboard', compras: 'Compras', ventas: 'Ventas',
    productores: 'Productores', productos: 'Productos',
    analisis: 'Análisis', historial: 'Historial', usuarios: 'Usuarios',
};

let _hp_usuario = null;  // usuario activo en memoria

// ── Obtener iniciales ──────────────────────────────────
function hp_iniciales(nombre, apellido) {
    const n = (nombre || '').trim()[0] || '';
    const a = (apellido || '').trim()[0] || '';
    return (n + a).toUpperCase() || '?';
}

// ── Cargar usuario desde el backend ───────────────────
async function hp_cargarUsuario() {
    const token = localStorage.getItem('token');

    // 1️⃣ Intentar con JWT
    if (token) {
        try {
            const res = await fetch(`${API_URL}/me`, {
                headers: { Authorization: `Bearer ${token}` }
            });
            if (res.ok) {
                const usuario = await res.json();
                _hp_usuario = usuario;
                localStorage.setItem('usuario', JSON.stringify(usuario));
                hp_pintarTodo(usuario);
                return;
            }
        } catch (e) {
            console.warn('Error al cargar perfil:', e);
        }
    }

    // 2️⃣ Fallback: leer del localStorage (guardado al hacer login)
    const guardado = localStorage.getItem('usuario');
    if (guardado) {
        try {
            const usuario = JSON.parse(guardado);
            _hp_usuario = usuario;
            hp_pintarTodo(usuario);
        } catch (e) { console.warn(e); }
    }
}

// ── Helper null-safe ──────────────────────────────────
function hp_set(id, prop, val) {
    const el = document.getElementById(id);
    if (!el) return;
    if (prop === 'text') el.textContent = val;
    else if (prop === 'value') el.value = val;
    else if (prop === 'bg') el.style.background = val;
    else if (prop === 'class') el.className = val;
    else if (prop === 'display') el.style.display = val;
    else if (prop === 'html') el.innerHTML = val;
}

// ── Pintar trigger (header) y panel ───────────────────
function hp_pintarTodo(u) {
    if (!u) return;
    const iniciales = hp_iniciales(u.nombre, u.apellido);
    const rolLabel = ROL_LABEL[u.tipo_usuario] || u.tipo_usuario;
    const gradient = ROL_GRADIENTS[u.tipo_usuario] || ROL_GRADIENTS.PRODUCTOR;
    const badgeCls = ROL_BADGE_CLASS[u.tipo_usuario] || '';
    const heroBg = ROL_HERO_BG[u.tipo_usuario] || ROL_HERO_BG.PRODUCTOR;
    const nombreCompleto = `${u.nombre || ''} ${u.apellido || ''}`.trim();

    /* ── Trigger header ── */
    hp_set('hp_avatar', 'bg', gradient);
    hp_set('hp_iniciales', 'text', iniciales);
    hp_set('hp_nombre', 'text', nombreCompleto);
    hp_set('hp_rol_badge', 'text', rolLabel);
    hp_set('hp_rol_badge', 'class', `hp-rol-badge ${badgeCls}`);

    /* ── Hero del panel ── */
    hp_set('hp_hero_bg', 'bg', heroBg);
    hp_set('hp_hero_avatar', 'bg', gradient);
    hp_set('hp_hero_iniciales', 'text', iniciales);
    hp_set('hp_hero_nombre', 'text', nombreCompleto);
    hp_set('hp_hero_cedula', 'text', u.cedula ? `CC: ${u.cedula}` : 'Sin cédula');
    hp_set('hp_hero_email_small', 'text', u.email || '');
    hp_set('hp_hero_rol_badge', 'text', rolLabel);
    hp_set('hp_hero_rol_badge', 'class', `hp-rol-badge hp-rol-badge-lg ${badgeCls}`);

    /* ── Permisos chips ── */
    // PostgreSQL devuelve los arrays como string "{dashboard,compras}" o ya como array JS
    let permisos = u.permisos || [];
    if (typeof permisos === 'string') {
        permisos = permisos.replace(/[{}]/g, '').split(',').filter(Boolean);
    }
    if (permisos.length) {
        const html = permisos.map(p =>
            `<span class="hp-chip">${PERMISO_LABEL[p.trim()] || p.trim()}</span>`
        ).join('');
        hp_set('hp_permisos_chips', 'html', html);
        hp_set('hp_permisos_wrap', 'display', 'block');
    } else {
        hp_set('hp_permisos_wrap', 'display', 'none');
    }

    /* ── Campos formulario ── */
    hp_set('hp_f_nombre', 'text', nombreCompleto);
    hp_set('hp_f_cedula', 'text', u.cedula || 'Sin cédula');
    hp_set('hp_f_email', 'value', u.email || '');
    hp_set('hp_f_telefono', 'value', u.telefono || '');
    hp_set('hp_f_tipo_label', 'text', rolLabel);

    /* Tipo usuario: oculto para ADMIN, visible (solo lectura) para los demás */
    if (u.tipo_usuario === 'ADMIN') {
        hp_set('hp_campo_tipo', 'display', 'none');
    } else {
        hp_set('hp_campo_tipo', 'display', '');
        hp_set('hp_tipo_readonly', 'display', '');
        hp_set('hp_f_tipo', 'display', 'none');
        hp_set('hp_f_tipo_label', 'text', rolLabel);
    }

    /* ── Foto de perfil guardada ── */
    if (u.foto_perfil) {
        // Construir URL completa si viene como ruta relativa /uploads/...
        const fotoUrl = u.foto_perfil.startsWith('http')
            ? u.foto_perfil
            : `${STATIC_URL}${u.foto_perfil}`;
        const imgHtml = `<img src="${fotoUrl}" alt="foto" style="width:100%;height:100%;object-fit:cover;border-radius:50%">`;
        hp_set('hp_hero_avatar', 'html', imgHtml);
        hp_set('hp_avatar', 'html', imgHtml);
    }
}

// ── Toggle / Cerrar panel ──────────────────────────────
function hp_toggle() {
    const panel = document.getElementById('hp_panel');
    const overlay = document.getElementById('hp_overlay');
    const chevron = document.getElementById('hp_chevron');
    if (panel.classList.contains('abierto')) {
        hp_cerrar();
    } else {
        panel.classList.add('abierto');
        overlay.classList.add('show');
        chevron.classList.add('abierto');
    }
}
function hp_cerrar() {
    document.getElementById('hp_panel').classList.remove('abierto');
    document.getElementById('hp_overlay').classList.remove('show');
    document.getElementById('hp_chevron').classList.remove('abierto');
}

// ── Cambiar tab ────────────────────────────────────────
function hp_switchTab(tab, btn) {
    document.querySelectorAll('.hp-tab').forEach(b => b.classList.remove('hp-tab-active'));
    document.querySelectorAll('.hp-tab-body').forEach(c => c.classList.remove('hp-tab-active'));
    btn.classList.add('hp-tab-active');
    document.getElementById(`hp_tab_${tab}`)?.classList.add('hp-tab-active');
}

// ── Previsualizar y subir foto ────────────────────────
async function hp_previsualizarFoto(input) {
    const file = input.files[0];
    if (!file || !_hp_usuario) return;

    // 1️⃣ Previsualizar inmediatamente sin esperar al servidor
    const reader = new FileReader();
    reader.onload = e => {
        const src = e.target.result;
        const imgHtml = `<img src="${src}" alt="foto" style="width:100%;height:100%;object-fit:cover;border-radius:50%">`;
        hp_set('hp_hero_avatar', 'html', imgHtml);
        hp_set('hp_avatar', 'html', imgHtml);
    };
    reader.readAsDataURL(file);

    // 2️⃣ Subir al servidor
    const formData = new FormData();
    formData.append('foto', file);
    const token = localStorage.getItem('token');

    try {
        const res = await fetch(`${API_URL}/usuarios/${_hp_usuario.id_usuario}/foto`, {
            method: 'POST',
            headers: { Authorization: `Bearer ${token}` },
            body: formData
        });
        if (!res.ok) throw new Error('Error al subir la foto');
        const data = await res.json();

        // 3️⃣ Actualizar en memoria y localStorage para que persista
        _hp_usuario.foto_perfil = data.foto_perfil;
        localStorage.setItem('usuario', JSON.stringify(_hp_usuario));

        // 4️⃣ Mostrar la URL completa del servidor
        const fotoUrl = data.foto_perfil.startsWith('http')
            ? data.foto_perfil
            : `${STATIC_URL}${data.foto_perfil}`;
        const imgFinal = `<img src="${fotoUrl}" alt="foto" style="width:100%;height:100%;object-fit:cover;border-radius:50%">`;
        hp_set('hp_hero_avatar', 'html', imgFinal);
        hp_set('hp_avatar', 'html', imgFinal);

    } catch (e) {
        console.error('Error subiendo foto:', e);
    }
}

// ── Guardar información ────────────────────────────────
async function hp_guardarInfo() {
    const msg = document.getElementById('hp_info_msg');
    if (!_hp_usuario) { msg.className = 'hp-msg error'; msg.textContent = ' No hay sesión activa.'; return; }

    const email = document.getElementById('hp_f_email').value.trim();
    const telefono = document.getElementById('hp_f_telefono').value.trim();
    const tipo = _hp_usuario.tipo_usuario === 'ADMIN'
        ? document.getElementById('hp_f_tipo').value
        : _hp_usuario.tipo_usuario;

    if (!email) { msg.className = 'hp-msg error'; msg.textContent = ' El correo es obligatorio.'; return; }

    const body = { email, telefono, tipo_usuario: tipo };
    const token = localStorage.getItem('token');

    try {
        const res = await fetch(`${API_URL}/usuarios/${_hp_usuario.id_usuario}`, {
            method: 'PUT',
            headers: { 'Content-Type': 'application/json', Authorization: `Bearer ${token}` },
            body: JSON.stringify(body),
        });
        if (!res.ok) {
            const err = await res.json();
            throw new Error(err.message || 'Error al guardar');
        }
        const actualizado = await res.json();
        _hp_usuario = { ..._hp_usuario, ...actualizado };
        hp_pintarTodo(_hp_usuario);
        msg.className = 'hp-msg ok';
        msg.textContent = 'Cambios guardados correctamente.';
    } catch (e) {
        msg.className = 'hp-msg error';
        msg.textContent = `${e.message}`;
    }
    setTimeout(() => msg.textContent = '', 3500);
}

// ── Cambiar contraseña ─────────────────────────────────
// El backend no tiene endpoint de cambio de password aún — dejamos el flujo listo
async function hp_cambiarPassword() {
    const actual = document.getElementById('hp_pass_actual').value;
    const nueva = document.getElementById('hp_pass_nueva').value;
    const confirmar = document.getElementById('hp_pass_confirmar').value;
    const msg = document.getElementById('hp_pass_msg');

    if (!actual || !nueva || !confirmar) {
        msg.className = 'hp-msg error'; msg.textContent = ' Completa todos los campos.'; return;
    }
    if (nueva !== confirmar) {
        msg.className = 'hp-msg error'; msg.textContent = ' Las contraseñas no coinciden.'; return;
    }
    if (nueva.length < 6) {
        msg.className = 'hp-msg error'; msg.textContent = ' Mínimo 6 caracteres.'; return;
    }

    // TODO: cuando el backend tenga endpoint:
    // await fetch(`${API_URL}/auth/cambiar-password`, { method:'PATCH', ... })
    msg.className = 'hp-msg ok';
    msg.textContent = ' Contraseña actualizada. (Conecta POST /auth/cambiar-password)';
    document.getElementById('hp_pass_actual').value = '';
    document.getElementById('hp_pass_nueva').value = '';
    document.getElementById('hp_pass_confirmar').value = '';
    setTimeout(() => msg.textContent = '', 3500);
}

// ── Cerrar sesión ──────────────────────────────────────
function hp_cerrarSesion() {
    if (!confirm('¿Deseas cerrar sesión?')) return;
    localStorage.removeItem('token');
    localStorage.removeItem('usuario');
    sessionStorage.removeItem('token');
    sessionStorage.removeItem('usuario');
    window.location.replace('./login.html');
}

// ── Inicializar al cargar ──────────────────────────────
window.addEventListener('load', hp_cargarUsuario);

// ════════════════════════════════════════════════════════
//  MÓDULO USUARIOS
// ════════════════════════════════════════════════════════

let _usr_todos = [];   // cache todos los usuarios
let _usr_rol = '';   // filtro rol activo
let _usr_buscar = '';   // texto búsqueda

const USR_GRADIENTS = {
    ADMIN: 'linear-gradient(135deg,#fbbf24,#d97706)',
    OPERARIO: 'linear-gradient(135deg,#a78bfa,#7c3aed)',
    PRODUCTOR: 'linear-gradient(135deg,#0aae0a,#1b5e20)',
};

// ── Cargar todos los usuarios ──────────────────────────
async function usr_cargar() {
    const token = localStorage.getItem('token');
    if (!token) return;
    try {
        const res = await fetch(`${API_URL}/usuarios`, {
            headers: { Authorization: `Bearer ${token}` }
        });
        if (!res.ok) throw new Error('Sin acceso');
        _usr_todos = await res.json();
        usr_renderTabla();
    } catch (e) {
        document.getElementById('usr_tbody').innerHTML =
            `<tr><td colspan="7" class="empty-state" style="color:#dc2626">Error al cargar usuarios: ${e.message}</td></tr>`;
    }
}

// ── Filtrar en tiempo real ─────────────────────────────
function usr_filtrar() {
    _usr_buscar = document.getElementById('usr_buscar').value.toLowerCase();
    usr_renderTabla();
}

function usr_setRol(rol, btn) {
    _usr_rol = rol;
    document.querySelectorAll('.usr-ftab').forEach(b => b.classList.remove('active'));
    btn.classList.add('active');
    usr_renderTabla();
}

// ── Renderizar tabla ───────────────────────────────────
function usr_renderTabla() {
    const tbody = document.getElementById('usr_tbody');
    const count = document.getElementById('usr_count');

    let lista = _usr_todos.filter(u => {
        const matchRol = !_usr_rol || u.tipo_usuario === _usr_rol;
        const texto = `${u.nombre} ${u.apellido} ${u.email} ${u.cedula || ''}`.toLowerCase();
        const matchBuscar = !_usr_buscar || texto.includes(_usr_buscar);
        return matchRol && matchBuscar;
    });

    count.textContent = `${lista.length} usuario${lista.length !== 1 ? 's' : ''} encontrado${lista.length !== 1 ? 's' : ''}`;

    if (!lista.length) {
        tbody.innerHTML = `<tr><td colspan="7" class="empty-state">No se encontraron usuarios</td></tr>`;
        return;
    }

    tbody.innerHTML = lista.map(u => {
        const iniciales = ((u.nombre || '')[0] || (u.nombre || '')).toUpperCase() +
            ((u.apellido || '')[0] || (u.apellido || '')).toUpperCase();
        const grad = USR_GRADIENTS[u.tipo_usuario] || USR_GRADIENTS.PRODUCTOR;
        return `
        <tr>
            <td>
                <div class="usr-user-cell">
                    <span class="usr-avatar" style="background:${grad}">${iniciales}</span>
                    <div>
                        <div class="usr-user-name">${u.nombre} ${u.apellido}</div>
                    </div>
                </div>
            </td>
            <td>${u.cedula || '—'}</td>
            <td>${u.email}</td>
            <td>${u.telefono || '—'}</td>
            <td><span class="usr-rol usr-rol-${u.tipo_usuario}">${u.tipo_usuario}</span></td>
            <td>
                <span class="usr-estado ${u.activo ? 'activo' : 'inactivo'}">
                    ${u.activo ? 'Activo' : 'Inactivo'}
                </span>
            </td>
            <td>
                <div style="display:flex;gap:6px;justify-content:flex-end">
                    <button class="usr-btn-action usr-btn-edit" title="Editar"
                            onclick="usr_abrirEditar(${u.id_usuario})">
                        <i class="fi fi-rr-pencil"></i>
                    </button>
                    <button class="usr-btn-del usr-btn-action"
                            title="${u.activo ? 'Desactivar' : 'Activar'}"
                            onclick="usr_desactivar(${u.id_usuario}, '${u.nombre} ${u.apellido}')">
                        <i class="fi fi-rr-trash"></i>
                    </button>
                </div>
            </td>
        </tr>`;
    }).join('');
}

// ── Abrir panel CREAR ──────────────────────────────────
let _usr_editando = null;

function usr_abrirPanel() {
    _usr_editando = null;
    document.getElementById('usr_panel_titulo').textContent = 'Nuevo usuario';
    document.getElementById('usr_btn_guardar').innerHTML = '<i class="fi fi-rr-user-add"></i> Crear usuario';
    document.getElementById('usr_btn_guardar').disabled = false;

    // Cédula editable al crear
    document.getElementById('usr_campo_cedula').style.display = '';
    document.getElementById('usr_cedula_readonly').style.display = 'none';

    // Contraseña obligatoria al crear
    document.getElementById('usr_campo_password').style.display = '';

    // Rol editable al crear
    document.getElementById('usr_f_rol').disabled = false;

    ['usr_f_nombre', 'usr_f_apellido', 'usr_f_cedula', 'usr_f_email',
        'usr_f_telefono', 'usr_f_password'].forEach(id => {
            const el = document.getElementById(id);
            if (el) el.value = '';
        });
    document.getElementById('usr_f_rol').value = 'OPERARIO';
    document.getElementById('usr_msg').textContent = '';
    document.getElementById('usr_msg').className = 'hp-msg';

    document.getElementById('usr_panel').classList.add('abierto');
    document.getElementById('usr_overlay').classList.add('show');
}

// ── Abrir panel EDITAR ─────────────────────────────────
function usr_abrirEditar(id) {
    const u = _usr_todos.find(x => x.id_usuario === id);
    if (!u) return;
    _usr_editando = u;

    document.getElementById('usr_panel_titulo').textContent = 'Editar usuario';
    document.getElementById('usr_btn_guardar').innerHTML = '<i class="fi fi-rr-check"></i> Guardar cambios';
    document.getElementById('usr_btn_guardar').disabled = false;

    // Cédula solo lectura al editar
    document.getElementById('usr_campo_cedula').style.display = 'none';
    document.getElementById('usr_cedula_readonly').style.display = '';
    document.getElementById('usr_cedula_val').textContent = u.cedula || '—';

    // Contraseña oculta al editar (no se cambia aquí)
    document.getElementById('usr_campo_password').style.display = 'none';

    document.getElementById('usr_f_nombre').value = u.nombre || '';
    document.getElementById('usr_f_apellido').value = u.apellido || '';
    document.getElementById('usr_f_email').value = u.email || '';
    document.getElementById('usr_f_telefono').value = u.telefono || '';
    document.getElementById('usr_f_rol').value = u.tipo_usuario || 'OPERARIO';
    document.getElementById('usr_f_rol').disabled = false;

    document.getElementById('usr_msg').textContent = '';
    document.getElementById('usr_msg').className = 'hp-msg';

    document.getElementById('usr_panel').classList.add('abierto');
    document.getElementById('usr_overlay').classList.add('show');
}

function usr_cerrarPanel() {
    document.getElementById('usr_panel').classList.remove('abierto');
    document.getElementById('usr_overlay').classList.remove('show');
    _usr_editando = null;
}

// ── Guardar (crear o editar según _usr_editando) ───────
async function usr_guardar() {
    if (_usr_editando) {
        await usr_guardarEdicion();
    } else {
        await usr_crear();
    }
}

// ── Guardar edición ────────────────────────────────────
async function usr_guardarEdicion() {
    const msg = document.getElementById('usr_msg');
    const nombre = document.getElementById('usr_f_nombre').value.trim();
    const apellido = document.getElementById('usr_f_apellido').value.trim();
    const email = document.getElementById('usr_f_email').value.trim();
    const telefono = document.getElementById('usr_f_telefono').value.trim();
    const rol = document.getElementById('usr_f_rol').value;

    if (!nombre || !apellido || !email) {
        msg.className = 'hp-msg error';
        msg.textContent = ' Nombre, apellido y correo son obligatorios.';
        return;
    }

    const btn = document.getElementById('usr_btn_guardar');
    btn.disabled = true;
    btn.innerHTML = '<i class="fi fi-rr-spinner"></i> Guardando...';
    msg.style.display = 'none';

    const token = localStorage.getItem('token');
    try {
        const res = await fetch(`${API_URL}/usuarios/${_usr_editando.id_usuario}`, {
            method: 'PUT',
            headers: { 'Content-Type': 'application/json', Authorization: `Bearer ${token}` },
            body: JSON.stringify({ nombre, apellido, email, telefono, tipo_usuario: rol })
        });
        const data = await res.json();
        if (!res.ok) throw new Error(data.message || 'Error al guardar');

        // Actualizar caché local
        const idx = _usr_todos.findIndex(x => x.id_usuario === _usr_editando.id_usuario);
        if (idx !== -1) {
            _usr_todos[idx] = { ..._usr_todos[idx], nombre, apellido, email, telefono, tipo_usuario: rol };
        }

        msg.className = 'hp-msg ok';
        msg.style.display = 'block';
        msg.textContent = ' Usuario actualizado correctamente.';
        setTimeout(() => { usr_cerrarPanel(); usr_renderTabla(); }, 1200);
    } catch (e) {
        msg.className = 'hp-msg error';
        msg.style.display = 'block';
        msg.textContent = ` ${e.message}`;
        btn.disabled = false;
        btn.innerHTML = '<i class="fi fi-rr-check"></i> Guardar cambios';
    }
}

// ── Crear usuario ──────────────────────────────────────
async function usr_crear() {
    const msg = document.getElementById('usr_msg');
    const nombre = document.getElementById('usr_f_nombre').value.trim();
    const apellido = document.getElementById('usr_f_apellido').value.trim();
    const email = document.getElementById('usr_f_email').value.trim();
    const cedula = document.getElementById('usr_f_cedula').value.trim();
    const telefono = document.getElementById('usr_f_telefono').value.trim();
    const rol = document.getElementById('usr_f_rol').value;
    const password = document.getElementById('usr_f_password').value;

    // Los productores se crean desde el módulo Productores (transacción completa)
    if (rol === 'PRODUCTOR') {
        msg.className = 'hp-msg warn';
        msg.innerHTML = `Para crear un productor usa el módulo <strong>Productores</strong>.<br>
            <small>Crear desde aquí no genera el registro en la tabla de productores ni el QR.</small>
            <br><button onclick="usr_cerrarPanel();document.querySelector('[data-section=productores]').click()"
                style="margin-top:8px;padding:6px 14px;background:#0aae0a;color:#fff;border:none;
                       border-radius:8px;cursor:pointer;font-size:.8em;font-weight:700">
                Ir a Productores →
            </button>`;
        return;
    }

    if (!nombre || !apellido || !email || !password) {
        msg.className = 'hp-msg error';
        msg.textContent = ' Nombre, apellido, correo y contraseña son obligatorios.';
        return;
    }
    if (password.length < 6) {
        msg.className = 'hp-msg error';
        msg.textContent = 'La contraseña debe tener mínimo 6 caracteres.';
        return;
    }

    const token = localStorage.getItem('token');
    try {
        const res = await fetch(`${API_URL}/auth/register`, {
            method: 'POST',
            headers: { 'Content-Type': 'application/json', Authorization: `Bearer ${token}` },
            body: JSON.stringify({ nombre, apellido, email, cedula, telefono, tipo_usuario: rol, password })
        });
        const data = await res.json();
        if (!res.ok) throw new Error(data.message || 'Error al crear usuario');

        msg.className = 'hp-msg ok';
        msg.textContent = ' Usuario creado correctamente.';
        setTimeout(() => { usr_cerrarPanel(); usr_cargar(); }, 1200);
    } catch (e) {
        msg.className = 'hp-msg error';
        msg.textContent = ` ${e.message}`;
    }
}

// ── Desactivar usuario (soft delete) ──────────────────
async function usr_desactivar(id, nombre) {
    if (!confirm(`¿Desactivar al usuario "${nombre}"?`)) return;
    const token = localStorage.getItem('token');
    try {
        const res = await fetch(`${API_URL}/usuarios/${id}`, {
            method: 'DELETE',
            headers: { Authorization: `Bearer ${token}` }
        });
        if (!res.ok) throw new Error('No se pudo desactivar');
        // Actualizar en cache sin recargar
        const u = _usr_todos.find(x => x.id_usuario === id);
        if (u) u.activo = false;
        usr_renderTabla();
    } catch (e) {
        alert(`Error: ${e.message}`);
    }
}

// ════════════════════════════════════════════════════════
//  MÓDULO PRODUCTORES
//  GET    /api/productores?todos=true  → lista todos
//  GET    /api/productores/:id         → detalle
//  POST   /api/productores             → crear
//  PUT    /api/productores/:id         → editar (sin cédula)
//  PATCH  /api/productores/:id/estado  → activar/desactivar
// ════════════════════════════════════════════════════════

let _prd_todos = [];
let _prd_estado = '';
let _prd_buscar = '';
let _prd_editando = null;

// ── Cargar ────────────────────────────────────────────
async function prd_cargar() {
    const token = localStorage.getItem('token');

    // Si no hay token, mostrar mensaje claro
    if (!token) {
        document.getElementById('prd_tbody').innerHTML =
            `<tr><td colspan="7" class="empty-state" style="color:#dc2626"> No hay sesión activa. Inicia sesión primero.</td></tr>`;
        return;
    }

    // Mostrar botón nuevo solo si es ADMIN
    // _hp_usuario puede no estar listo aún — leer también del localStorage
    const usuarioLocal = _hp_usuario || JSON.parse(localStorage.getItem('usuario') || '{}');
    const esAdmin = usuarioLocal?.tipo_usuario === 'ADMIN';
    const btnNuevo = document.getElementById('prd_btn_nuevo');
    if (btnNuevo) btnNuevo.style.display = esAdmin ? '' : 'none';

    // Mostrar loading en tabla
    document.getElementById('prd_tbody').innerHTML =
        `<tr><td colspan="7" class="empty-state">Cargando productores...</td></tr>`;

    try {
        const res = await fetch(`${API_URL}/productores?todos=true`, {
            headers: { Authorization: `Bearer ${token}` }
        });

        if (!res.ok) {
            const err = await res.json().catch(() => ({}));
            throw new Error(err.message || `Error ${res.status}`);
        }

        const json = await res.json();
        _prd_todos = json.data || json;

        if (!Array.isArray(_prd_todos)) {
            throw new Error('Formato de respuesta inesperado del servidor');
        }

        prd_renderTabla();
    } catch (e) {
        document.getElementById('prd_tbody').innerHTML =
            `<tr><td colspan="7" class="empty-state" style="color:#dc2626">
                 ${e.message}
                <br><small style="color:#9ca3af">Verifica que el servidor esté corriendo en ${API_URL}</small>
             </td></tr>`;
    }
}

// ── Filtrar ────────────────────────────────────────────
function prd_filtrar() {
    _prd_buscar = document.getElementById('prd_buscar').value.toLowerCase();
    prd_renderTabla();
}
function prd_setEstado(estado, btn) {
    _prd_estado = estado;
    btn.parentElement.querySelectorAll('.usr-ftab').forEach(b => b.classList.remove('active'));
    btn.classList.add('active');
    prd_renderTabla();
}

// ── Render tabla ───────────────────────────────────────
function prd_renderTabla() {
    const tbody = document.getElementById('prd_tbody');
    const count = document.getElementById('prd_count');
    const usuarioLocal = _hp_usuario || JSON.parse(localStorage.getItem('usuario') || '{}');
    const esAdmin = usuarioLocal?.tipo_usuario === 'ADMIN';

    let lista = _prd_todos.filter(p => {
        const matchEstado = !_prd_estado || p.estado === _prd_estado;
        const texto = `${p.nombre || ''} ${p.usuario?.cedula || ''} ${p.finca || ''}`.toLowerCase();
        const matchBuscar = !_prd_buscar || texto.includes(_prd_buscar);
        return matchEstado && matchBuscar;
    });

    count.textContent = `${lista.length} productor${lista.length !== 1 ? 'es' : ''} encontrado${lista.length !== 1 ? 's' : ''}`;

    if (!lista.length) {
        tbody.innerHTML = `<tr><td colspan="8" class="empty-state">No se encontraron productores</td></tr>`;
        return;
    }

    tbody.innerHTML = lista.map(p => {
        const nombre = p.nombre || p.usuario?.nombre || '—';
        const apellido = p.usuario?.apellido || '';
        const cedula = p.usuario?.cedula || '—';
        const iniciales = nombre[0]?.toUpperCase() || '?';
        const activo = p.estado === 'ACTIVO';
        const qrValido = p.codigo_qr && p.codigo_qr.startsWith('data:image');
        const qrCell = qrValido
            ? `<button class="prd-qr-icon-btn" onclick="qr_ver(${p.id_productor})" title="Ver código QR">
                    <svg width="16" height="16" viewBox="0 0 24 24" fill="currentColor" style="pointer-events:none">
                        <path d="M3 3h7v7H3V3zm2 2v3h3V5H5zm8-2h7v7h-7V3zm2 2v3h3V5h-3zM3 13h7v7H3v-7zm2 2v3h3v-3H5zm11 0h2v2h-2v-2zm-3-2h2v2h-2v-2zm0 4h2v2h-2v-2zm4-2h2v2h-2v-2zm0 4h2v2h-2v-2zm-4 0h2v2h-2v-2z"/>
                    </svg>
               </button>`
            : esAdmin
                ? `<button class="prd-qr-icon-btn" style="background:#fef3c7;border-color:#fde68a;color:#d97706"
                        onclick="prd_regenerarQR(${p.id_productor})" title="Regenerar QR">
                        <svg width="14" height="14" viewBox="0 0 24 24" fill="currentColor" style="pointer-events:none">
                            <path d="M12 4V1L8 5l4 4V6c3.31 0 6 2.69 6 6 0 1.01-.25 1.97-.7 2.8l1.46 1.46A7.93 7.93 0 0020 12c0-4.42-3.58-8-8-8zm0 14c-3.31 0-6-2.69-6-6 0-1.01.25-1.97.7-2.8L5.24 7.74A7.93 7.93 0 004 12c0 4.42 3.58 8 8 8v3l4-4-4-4v3z"/>
                        </svg>
                   </button>`
                : `<span style="color:#d1d5db;font-size:.75em">—</span>`;
        return `
        <tr>
            <td>
                <div class="usr-user-cell">
                    <span class="usr-avatar" style="background:linear-gradient(135deg,#0aae0a,#1b5e20)">${iniciales}</span>
                    <div>
                        <div class="usr-user-name">${nombre} ${apellido}</div>
                        ${p.usuario?.email ? `<div style="font-size:.76em;color:#9ca3af">${p.usuario.email}</div>` : ''}
                    </div>
                </div>
            </td>
            <td style="font-family:monospace;font-size:.82em">${cedula}</td>
            <td>${p.finca || '—'}</td>
            <td style="font-size:.82em;color:#6b7280">${p.ubicacion || '—'}</td>
            <td>${p.usuario?.telefono || '—'}</td>
            <td class="prd-qr-cell">${qrCell}</td>
            <td>
                <span class="usr-estado ${activo ? 'activo' : 'inactivo'}">
                    ${activo ? 'Activo' : 'Inactivo'}
                </span>
            </td>
            <td>
                ${esAdmin ? `
                <div style="display:flex;gap:6px;justify-content:flex-end">
                    <button class="usr-btn-action usr-btn-edit" title="Editar"
                            onclick="prd_abrirEditar(${p.id_productor})">
                        <i class="fi fi-rr-pencil"></i>
                    </button>
                    <button class="usr-btn-action usr-btn-del"
                            onclick="prd_toggleEstado(${p.id_productor}, '${nombre}', '${p.estado}')">
                        <i class="fi fi-rr-${activo ? 'trash' : 'rotate-right'}"></i>
                    </button>
                </div>` : '—'}
            </td>
        </tr>`;
    }).join('');
}// ── Panel CREAR ────────────────────────────────────────
function prd_abrirPanel() {
    _prd_editando = null;
    document.getElementById('prd_panel_titulo').textContent = 'Nuevo productor';
    document.getElementById('prd_btn_accion').innerHTML = '<i class="fi fi-rr-user-add"></i> Crear productor';
    document.getElementById('prd_btn_accion').onclick = prd_crear;

    // Mostrar cédula editable y sección usuario
    document.getElementById('prd_f_cedula').style.display = '';
    document.getElementById('prd_cedula_readonly').style.display = 'none';
    document.getElementById('prd_campos_usuario').style.display = '';

    ['prd_f_nombre', 'prd_f_apellido', 'prd_f_cedula', 'prd_f_telefono',
        'prd_f_finca', 'prd_f_ubicacion', 'prd_f_email', 'prd_f_password'].forEach(id => {
            const el = document.getElementById(id);
            if (el) el.value = '';
        });
    document.getElementById('prd_msg').textContent = '';
    document.getElementById('prd_msg').className = 'hp-msg';

    document.getElementById('prd_panel').classList.add('abierto');
    document.getElementById('prd_overlay').classList.add('show');
}

// ── Panel EDITAR ───────────────────────────────────────
function prd_abrirEditar(id) {
    const p = _prd_todos.find(x => x.id_productor === id);
    if (!p) return;
    _prd_editando = p;

    document.getElementById('prd_panel_titulo').textContent = 'Editar productor';
    document.getElementById('prd_btn_accion').innerHTML = '<i class="fi fi-rr-check"></i> Guardar cambios';
    document.getElementById('prd_btn_accion').onclick = prd_guardarEdicion;

    document.getElementById('prd_f_cedula').style.display = 'none';
    document.getElementById('prd_cedula_readonly').style.display = '';
    document.getElementById('prd_cedula_val').textContent = p.usuario?.cedula || '—';

    document.getElementById('prd_campos_usuario').style.display = 'none';

    const nombre = p.usuario?.nombre || p.nombre || '';
    const apellido = p.usuario?.apellido || p.apellido || '';

    document.getElementById('prd_f_nombre').value = nombre;
    document.getElementById('prd_f_apellido').value = apellido;
    document.getElementById('prd_f_telefono').value = p.usuario?.telefono || '';
    document.getElementById('prd_f_finca').value = p.finca || '';
    document.getElementById('prd_f_ubicacion').value = p.ubicacion || '';

    document.getElementById('prd_msg').textContent = '';
    document.getElementById('prd_msg').className = 'hp-msg';

    document.getElementById('prd_panel').classList.add('abierto');
    document.getElementById('prd_overlay').classList.add('show');
}

function prd_cerrarPanel() {
    document.getElementById('prd_panel').classList.remove('abierto');
    document.getElementById('prd_overlay').classList.remove('show');
    _prd_editando = null;
}

// ── Crear ──────────────────────────────────────────────
async function prd_crear() {
    const msg = document.getElementById('prd_msg');
    const nombre = document.getElementById('prd_f_nombre').value.trim();
    const apellido = document.getElementById('prd_f_apellido').value.trim();
    const cedula = document.getElementById('prd_f_cedula').value.trim();
    const telefono = document.getElementById('prd_f_telefono').value.trim();
    const finca = document.getElementById('prd_f_finca').value.trim();
    const ubicacion = document.getElementById('prd_f_ubicacion').value.trim();
    const email = document.getElementById('prd_f_email').value.trim();
    const password = document.getElementById('prd_f_password').value;

    if (!nombre || !apellido || !cedula || !email || !password) {
        msg.className = 'hp-msg error';
        msg.textContent = ' Nombre, apellido, cédula, correo y contraseña son obligatorios.';
        return;
    }
    if (password.length < 6) {
        msg.className = 'hp-msg error';
        msg.textContent = ' La contraseña debe tener mínimo 6 caracteres.';
        return;
    }

    const token = localStorage.getItem('token');
    try {
        const res = await fetch(`${API_URL}/productores`, {
            method: 'POST',
            headers: { 'Content-Type': 'application/json', Authorization: `Bearer ${token}` },
            body: JSON.stringify({ nombre, apellido, cedula, telefono, finca, ubicacion, email, password })
        });
        const data = await res.json();
        if (!res.ok) throw new Error(data.message || 'Error al crear productor');

        msg.className = 'hp-msg ok';
        msg.textContent = ' Productor creado correctamente.';
        setTimeout(() => { prd_cerrarPanel(); prd_cargar(); }, 1200);
    } catch (e) {
        msg.className = 'hp-msg error';
        msg.textContent = ` ${e.message}`;
    }
}

// ── Guardar edición ────────────────────────────────────
async function prd_guardarEdicion() {
    const msg = document.getElementById('prd_msg');
    if (!_prd_editando) return;

    const nombre = document.getElementById('prd_f_nombre').value.trim();
    const apellido = document.getElementById('prd_f_apellido').value.trim();
    const telefono = document.getElementById('prd_f_telefono').value.trim();
    const finca = document.getElementById('prd_f_finca').value.trim();
    const ubicacion = document.getElementById('prd_f_ubicacion').value.trim();

    if (!nombre) {
        msg.className = 'hp-msg error';
        msg.textContent = 'El nombre es obligatorio.';
        return;
    }

    const token = localStorage.getItem('token');
    try {
        // 1. Actualizar datos del productor (finca, ubicacion, telefono)
        const resPrd = await fetch(`${API_URL}/productores/${_prd_editando.id_productor}`, {
            method: 'PUT',
            headers: { 'Content-Type': 'application/json', Authorization: `Bearer ${token}` },
            body: JSON.stringify({ telefono, finca, ubicacion })
        });
        const dataPrd = await resPrd.json();
        if (!resPrd.ok) throw new Error(dataPrd.message || 'Error al guardar productor');

        // 2. Actualizar nombre y apellido en la tabla usuarios (donde viven esos datos)
        const idUsuario = _prd_editando.id_usuario || _prd_editando.usuario?.id_usuario;
        if (idUsuario) {
            const resUsr = await fetch(`${API_URL}/usuarios/${idUsuario}`, {
                method: 'PUT',
                headers: { 'Content-Type': 'application/json', Authorization: `Bearer ${token}` },
                body: JSON.stringify({ nombre, apellido, telefono })
            });
            // Si el endpoint falla no bloqueamos — solo advertimos
            if (!resUsr.ok) {
                const errUsr = await resUsr.json().catch(() => ({}));
                console.warn('No se pudo actualizar usuario:', errUsr.message);
            }
        }

        // Actualizar caché local para que la tabla refleje el cambio sin recargar
        const idx = _prd_todos.findIndex(p => p.id_productor === _prd_editando.id_productor);
        if (idx !== -1) {
            _prd_todos[idx] = {
                ..._prd_todos[idx],
                telefono, finca, ubicacion,
                usuario: {
                    ...(_prd_todos[idx].usuario || {}),
                    nombre, apellido, telefono
                }
            };
        }

        msg.className = 'hp-msg ok';
        msg.textContent = 'Productor actualizado correctamente.';
        setTimeout(() => { prd_cerrarPanel(); prd_renderTabla(); }, 1200);
    } catch (e) {
        msg.className = 'hp-msg error';
        msg.textContent = ` ${e.message}`;
    }
}

// ── Toggle activo/inactivo ─────────────────────────────
async function prd_toggleEstado(id, nombre, estadoActual) {
    const nuevoEstado = estadoActual === 'ACTIVO' ? 'INACTIVO' : 'ACTIVO';
    const accion = nuevoEstado === 'INACTIVO' ? 'desactivar' : 'reactivar';
    if (!confirm(`¿Deseas ${accion} al productor "${nombre}"?`)) return;

    const token = localStorage.getItem('token');
    try {
        const res = await fetch(`${API_URL}/productores/${id}/estado`, {
            method: 'PATCH',
            headers: { 'Content-Type': 'application/json', Authorization: `Bearer ${token}` },
            body: JSON.stringify({ estado: nuevoEstado })
        });
        if (!res.ok) {
            const err = await res.json();
            throw new Error(err.message || 'Error al cambiar estado');
        }
        const p = _prd_todos.find(x => x.id_productor === id);
        if (p) p.estado = nuevoEstado;
        prd_renderTabla();
    } catch (e) {
        alert(`Error: ${e.message}`);
    }
}

// ── Regenerar QR ────────────────────────────────────────
async function prd_regenerarQR(id) {
    const token = localStorage.getItem('token');
    const btn = event.currentTarget;
    btn.disabled = true;
    btn.style.opacity = '.5';
    try {
        const res = await fetch(`${API_URL}/productores/${id}/qr`, {
            method: 'POST',
            headers: { Authorization: `Bearer ${token}` }
        });
        const data = await res.json();
        if (!res.ok) throw new Error(data.message || 'Error al regenerar QR');

        // Actualizar en caché y re-renderizar
        const p = _prd_todos.find(x => x.id_productor === id);
        if (p && data.data?.codigo_qr) p.codigo_qr = data.data.codigo_qr;
        prd_renderTabla();
    } catch (e) {
        alert(`Error: ${e.message}`);
        btn.disabled = false;
        btn.style.opacity = '1';
    }
}

async function prd_regenerarTodosQR() {
    const total = _prd_todos.length;
    if (!total) { alert('No hay productores cargados. Ve a la sección Productores primero.'); return; }
    if (!confirm(`¿Regenerar el QR de los ${total} productores?\n\nEsto puede tardar unos segundos.`)) return;

    const token = localStorage.getItem('token');
    let ok = 0, errores = 0;

    showLoading();
    for (const p of _prd_todos) {
        try {
            const res = await fetch(`${API_URL}/productores/${p.id_productor}/qr`, {
                method: 'POST',
                headers: { Authorization: `Bearer ${token}` }
            });
            const data = await res.json();
            if (!res.ok) throw new Error(data.message);
            if (data.data?.codigo_qr) p.codigo_qr = data.data.codigo_qr;
            ok++;
        } catch (e) {
            console.error(`QR error productor #${p.id_productor}:`, e.message);
            errores++;
        }
    }
    hideLoading();
    prd_renderTabla();
    alert(` QR regenerados: ${ok}${errores ? '\n Errores: ' + errores : ''}\n\nTodos los QR ahora contienen solo el número de cédula.`);
}

// ════════════════════════════════════════
//  MODAL QR
// ════════════════════════════════════════
function qr_ver(id_productor) {
    const p = _prd_todos.find(x => x.id_productor == id_productor);

    if (!p) { alert('Productor no encontrado. Recarga la sección.'); return; }

    const qrValido = p.codigo_qr && p.codigo_qr.startsWith('data:image');
    if (!qrValido) {
        alert(' Este productor tiene un QR inválido o pendiente de regenerar.\n\nSolución: llama a POST /api/productores/' + p.id_productor + '/qr para regenerarlo.');
        return;
    }

    const nombre = p.usuario?.nombre || p.nombre || 'Productor';
    const apellido = p.usuario?.apellido || '';
    const cedula = p.usuario?.cedula || '—';
    const finca = p.finca || 'Sin finca';
    const inicial = (nombre[0] || 'P').toUpperCase();
    const nombreCompleto = `${nombre} ${apellido}`.trim();

    document.getElementById('qr_modal_inicial').textContent = inicial;
    document.getElementById('qr_modal_nombre').textContent = nombreCompleto;
    document.getElementById('modal-qr-meta').textContent = `Cédula: ${cedula}  ·  Finca: ${finca}`;
    document.getElementById('modal-qr-canvas').innerHTML =
        `<img id="qr-img" src="${p.codigo_qr}" alt="QR" style="width:240px;height:240px;border-radius:10px;border:1px solid #e5e7eb;display:block">`;

    const dl = document.getElementById('qr_modal_dl');
    dl.href = p.codigo_qr;
    dl.download = `QR_${nombreCompleto.replace(/\s+/g, '_')}.png`;

    document.getElementById('modalQRProductor').style.display = 'flex';
}

function qr_cerrar() {
    document.getElementById('modalQRProductor').style.display = 'none';
}

function qr_imprimir() {
    const img = document.getElementById('qr-img');
    if (!img) { alert('No hay QR para imprimir'); return; }
    const nombre = document.getElementById('qr_modal_nombre').textContent;
    const meta = document.getElementById('modal-qr-meta').textContent;
    const inicial = nombre[0].toUpperCase();

    const html = `<!DOCTYPE html><html><head><meta charset="UTF-8"><title>QR ${nombre}</title>
      <style>
        *{margin:0;padding:0;box-sizing:border-box}
        body{font-family:'Segoe UI',sans-serif;display:flex;align-items:center;
             justify-content:center;min-height:100vh;background:#fff}
        .card{width:320px;border:2px solid #e5e7eb;border-radius:18px;overflow:hidden}
        .top{background:linear-gradient(135deg,#0aae0a,#1b5e20);padding:20px;
             display:flex;align-items:center;gap:14px}
        .av{width:50px;height:50px;border-radius:50%;background:rgba(255,255,255,.22);
            display:flex;align-items:center;justify-content:center;
            font-size:1.4em;font-weight:900;color:#fff;flex-shrink:0}
        .n{font-size:1em;font-weight:800;color:#fff;display:block}
        .m{font-size:.75em;color:rgba(255,255,255,.82);display:block;margin-top:4px}
        .qrw{background:#f9fafb;padding:22px;display:flex;flex-direction:column;
             align-items:center;gap:10px}
        .qrw img{width:220px;height:220px;border-radius:10px;border:1px solid #e5e7eb}
        .hint{font-size:.7em;color:#9ca3af;font-weight:600}
        .brand{background:#f0fdf4;padding:8px;text-align:center;font-size:.68em;
               color:#0aae0a;font-weight:700;border-top:1px solid #dcfce7}
        @media print{body{margin:0}}
      </style></head><body>
      <div class="card">
        <div class="top">
          <div class="av">${inicial}</div>
          <div><span class="n">${nombre}</span><span class="m">${meta}</span></div>
        </div>
        <div class="qrw">
          <img src="${img.src}" alt="QR">
          <span class="hint">Escanea para identificar este productor</span>
        </div>
        <div class="brand">AgroTrace · Sistema de Trazabilidad</div>
      </div>
      <script>window.addEventListener('load',()=>{setTimeout(()=>{window.print();},300)})<\/script>
      </body></html>`;

    const blob = new Blob([html], { type: 'text/html;charset=utf-8' });
    const url = URL.createObjectURL(blob);
    window.open(url, '_blank', 'width=520,height=620');
    setTimeout(() => URL.revokeObjectURL(url), 10000);
}

document.addEventListener('keydown', e => { if (e.key === 'Escape') { qr_cerrar(); pro_cerrarPanel(); det_cerrar(); } });

// ════════════════════════════════════════
//  AVISO ROL PRODUCTOR EN PANEL USUARIOS
// ════════════════════════════════════════
function usr_chkRol(sel) {
    const msg = document.getElementById('usr_msg');
    if (sel.value === 'PRODUCTOR') {
        msg.className = 'hp-msg warn';
        msg.innerHTML = `Los productores se crean desde el módulo <strong>Productores</strong> para generar también el QR y el registro completo.<br>
            <button onclick="usr_cerrarPanel();document.querySelector('[data-section=productores]').click()"
                style="margin-top:8px;padding:6px 14px;background:#0aae0a;color:#fff;border:none;
                       border-radius:8px;cursor:pointer;font-size:.8em;font-weight:700">
                Ir a Productores →
            </button>`;
    } else {
        msg.className = 'hp-msg';
        msg.innerHTML = '';
    }
}

/// ════════════════════════════════════════
// MÓDULO PRODUCTOS
// ════════════════════════════════════════

let pro_lista = [];
let pro_buscar = "";
let pro_disponible = "";
let pro_editando = null;


// ─────────────────────────────
// API segura
// ─────────────────────────────

async function pro_api(url, options = {}) {

    const token = localStorage.getItem("token");

    const res = await fetch(url, {
        headers: {
            "Content-Type": "application/json",
            Authorization: `Bearer ${token}`
        },
        ...options
    });

    const data = await res.json().catch(() => ({}));

    if (!res.ok) {
        throw new Error(data.message || "Error en la petición");
    }

    return data;
}


// ─────────────────────────────
// CARGAR PRODUCTOS
// ─────────────────────────────

async function pro_cargar() {

    try {

        const data = await pro_api(`${API_URL}/productos`);

        pro_lista = Array.isArray(data) ? data : data.data || [];

        pro_renderTabla();

    } catch (e) {

        document.getElementById("pro_tbody").innerHTML =
            `<tr>
                <td colspan="7" style="text-align:center;padding:40px;color:#ef4444">
                    ${e.message}
                </td>
            </tr>`;
    }
}


// ─────────────────────────────
// FILTROS
// ─────────────────────────────

function pro_filtrar(valor) {
    pro_buscar = valor.toLowerCase();
    pro_renderTabla();
}

function pro_setDisponible(valor, btn) {

    pro_disponible = valor;

    document
        .querySelectorAll("#productos .usr-ftab")
        .forEach(b => b.classList.remove("active"));

    btn.classList.add("active");

    pro_renderTabla();
}


// ─────────────────────────────
// RENDER TABLA
// ─────────────────────────────

function pro_renderTabla() {

    const tbody = document.getElementById("pro_tbody");
    if (!tbody) return;

    let lista = pro_lista.filter(p => {

        const texto =
            `${p.nombre || ""} ${p.descripcion || ""}`
                .toLowerCase();

        const buscarOk =
            !pro_buscar || texto.includes(pro_buscar);

        const estadoOk =
            pro_disponible === ""
                ? true
                : pro_disponible === "true"
                    ? p.disponible
                    : !p.disponible;

        return buscarOk && estadoOk;
    });


    document.getElementById("pro_count").textContent =
        `${lista.length} producto${lista.length !== 1 ? "s" : ""}`;


    if (!lista.length) {

        tbody.innerHTML =
            `<tr>
                <td colspan="7" style="text-align:center;padding:40px;color:#9ca3af">
                    No hay productos
                </td>
            </tr>`;

        return;
    }


    const fmt = n => n != null
        ? `$ ${Number(n).toLocaleString("es-CO")}`
        : "—";


    tbody.innerHTML = lista.map(p => {

        const id = Number(p.id_producto);
        const disponible = p.disponible;

        return `
        <tr>

            <td>${p.nombre}</td>

            <td>${p.descripcion || "—"}</td>

            <td>${p.unidad_medida || "—"}</td>

            <td>${fmt(p.precio_base)}</td>

            <td>
                <span class="usr-estado ${disponible ? "activo" : "inactivo"}">
                    ${disponible ? "Disponible" : "No disponible"}
                </span>
            </td>

            <td>

                <button class="usr-btn-action usr-btn-edit" onclick="pro_abrirEditar(${id})">
                    <i class="fi fi-rr-pencil"></i> 
                </button>

                <button class="usr-btn-action usr-btn-del" onclick="pro_toggleDisponible(${id}, '${p.nombre}', ${disponible})">
                    <i class="fi fi-rr-power"></i> ${disponible ? "" : "<i class='fi fi-rr-power-on'></i>"}
                </button>
            

            </td>
        </tr>`;
    }).join("");
}


// ─────────────────────────────
// PANEL PRODUCTOS — abrir / cerrar / editar
// ─────────────────────────────

function pro_abrirPanel() {
    pro_editando = null;
    document.getElementById('pro_panel_titulo').textContent = 'Nuevo producto';
    document.getElementById('pro_btn_guardar').innerHTML = '<i class="fi fi-rr-check"></i> Guardar producto';
    document.getElementById('pro_btn_guardar').disabled = false;

    ['pro_f_nombre', 'pro_f_descripcion', 'pro_f_precio_base'].forEach(id => {
        const el = document.getElementById(id);
        if (el) el.value = '';
    });
    const cat = document.getElementById('pro_f_categoria');
    if (cat) cat.value = '';
    const uni = document.getElementById('pro_f_unidad');
    if (uni) uni.value = '';

    const msg = document.getElementById('pro_msg');
    if (msg) msg.style.display = 'none';

    document.getElementById('pro_overlay').classList.add('show');
    document.getElementById('pro_panel').classList.add('abierto');
}

function pro_abrirEditar(id) {
    const p = pro_lista.find(x => Number(x.id_producto) === Number(id));
    if (!p) return;
    pro_editando = id;

    document.getElementById('pro_panel_titulo').textContent = 'Editar producto';
    document.getElementById('pro_btn_guardar').innerHTML = '<i class="fi fi-rr-check"></i> Guardar cambios';
    document.getElementById('pro_btn_guardar').disabled = false;

    document.getElementById('pro_f_nombre').value = p.nombre || '';
    document.getElementById('pro_f_descripcion').value = p.descripcion || '';
    document.getElementById('pro_f_precio_base').value = p.precio_base ?? '';

    /*const cat = document.getElementById('pro_f_categoria');
    if (cat) cat.value = p.categoria || '';*/
    const uni = document.getElementById('pro_f_unidad');
    if (uni) uni.value = p.unidad_medida || '';

    const msg = document.getElementById('pro_msg');
    if (msg) msg.style.display = 'none';

    document.getElementById('pro_overlay').classList.add('show');
    document.getElementById('pro_panel').classList.add('abierto');
}

function pro_cerrarPanel() {
    document.getElementById('pro_overlay').classList.remove('show');
    document.getElementById('pro_panel').classList.remove('abierto');
    pro_editando = null;
}

// ─────────────────────────────
// GUARDAR PRODUCTO
// ─────────────────────────────

async function pro_guardar() {
    const msg = document.getElementById('pro_msg');

    const nombre = document.getElementById('pro_f_nombre').value.trim();
    if (!nombre) {
        msg.style.display = 'block';
        msg.style.background = '#fee2e2';
        msg.style.color = '#991b1b';
        msg.textContent = ' El nombre del producto es obligatorio.';
        return;
    }

    const precioBaseVal = document.getElementById('pro_f_precio_base').value;
    const precioDiaVal = document.getElementById('pro_f_precio_dia').value;

    if (precioBaseVal && Number(precioBaseVal) < 0) {
        msg.style.display = 'block';
        msg.style.background = '#fee2e2';
        msg.style.color = '#991b1b';
        msg.textContent = ' El precio no puede ser negativo.';
        return;
    }

    const body = {
        nombre,
        descripcion: document.getElementById('pro_f_descripcion').value.trim() || undefined,
        categoria: document.getElementById('pro_f_categoria').value || undefined,
        unidad_medida: document.getElementById('pro_f_unidad').value || undefined,
        precio_base: precioBaseVal !== '' ? Number(precioBaseVal) : 0,
        precio_dia: precioDiaVal !== '' ? Number(precioDiaVal) : undefined,
    };

    const btn = document.getElementById('pro_btn_guardar');
    btn.disabled = true;
    btn.innerHTML = '<i class="fi fi-rr-spinner"></i> Guardando...';
    msg.style.display = 'none';

    try {
        // Usar pro_editando !== null para que id=0 funcione igual
        if (pro_editando !== null) {
            await pro_api(`${API_URL}/productos/${pro_editando}`, {
                method: 'PUT',
                body: JSON.stringify(body)
            });
        } else {
            await pro_api(`${API_URL}/productos`, {
                method: 'POST',
                body: JSON.stringify(body)
            });
        }

        msg.style.display = 'block';
        msg.style.background = '#dcfce7';
        msg.style.color = '#166534';
        msg.textContent = pro_editando !== null
            ? ' Producto actualizado correctamente.'
            : ' Producto creado correctamente.';

        await pro_cargar();
        setTimeout(() => pro_cerrarPanel(), 1000);

    } catch (e) {
        msg.style.display = 'block';
        msg.style.background = '#fee2e2';
        msg.style.color = '#991b1b';
        msg.textContent = ` ${e.message}`;
        btn.disabled = false;
        btn.innerHTML = '<i class="fi fi-rr-check"></i> ' + (pro_editando !== null ? 'Guardar cambios' : 'Guardar producto');
    }
}


// ─────────────────────────────
// ACTIVAR / DESACTIVAR
// ─────────────────────────────

async function pro_toggleDisponible(id, nombre, actual) {

    const confirmar = confirm(
        `¿Cambiar estado del producto "${nombre}"?`
    );

    if (!confirmar) return;

    try {

        await pro_api(`${API_URL}/productos/${id}/estado`, {
            method: "PATCH",
            body: JSON.stringify({
                disponible: !actual
            })
        });

        await pro_cargar();

    } catch (e) {

        alert(e.message);
    }
}
// ── fin módulo productos ──
// ════════════════════════════════════════════════════════
//  MÓDULO COMPRAS
// ════════════════════════════════════════════════════════
let _cmp_todos = [];
let _cmp_buscar = '';
let _cmp_estado = '';
let _cmp_pago = '';       // '' | 'PENDIENTE' | 'PAGADO'
let _cmp_fechaDesde = '';
let _cmp_fechaHasta = '';

async function cmp_cargar() {
    const token = localStorage.getItem('token');

    // Resetear filtros al entrar a la sección
    _cmp_estado = '';
    _cmp_pago = '';
    _cmp_buscar = '';
    _cmp_fechaDesde = '';
    _cmp_fechaHasta = '';
    const buscarInput = document.getElementById('cmp_buscar');
    if (buscarInput) buscarInput.value = '';
    const desdeinput = document.getElementById('cmp_fecha_desde');
    if (desdeinput) desdeinput.value = '';
    const hastaInput = document.getElementById('cmp_fecha_hasta');
    if (hastaInput) hastaInput.value = '';
    document.querySelectorAll('#compras .usr-ftab').forEach((b, i) => {
        b.classList.toggle('active', i === 0);
    });

    try {
        const res = await fetch(`${API_URL}/compras`, {
            headers: { Authorization: `Bearer ${token}` }
        });
        const json = await res.json();
        _cmp_todos = Array.isArray(json) ? json : (json.data || []);
        cmp_renderTabla();
    } catch (e) {
        document.getElementById('cmp_tbody').innerHTML =
            `<tr><td colspan="8" style="text-align:center;padding:40px;color:#ef4444">Error: ${e.message}</td></tr>`;
    }
}

function cmp_filtrar(val) { _cmp_buscar = val.toLowerCase(); cmp_renderTabla(); }
function cmp_setFechaDesde(val) { _cmp_fechaDesde = val; cmp_renderTabla(); }
function cmp_setFechaHasta(val) { _cmp_fechaHasta = val; cmp_renderTabla(); }

function cmp_setEstado(val, btn) {
    _cmp_estado = val;
    document.querySelectorAll('#compras .usr-ftab').forEach(b => b.classList.remove('active'));
    btn.classList.add('active');
    cmp_renderTabla();
}

function cmp_setPago(val, btn) {
    _cmp_pago = val;
    document.querySelectorAll('#compras .cmp-pago-tab').forEach(b => b.classList.remove('active'));
    btn.classList.add('active');
    cmp_renderTabla();
}

function cmp_renderTabla() {
    const tbody = document.getElementById('cmp_tbody');
    if (!tbody) return;

    const lista = _cmp_todos.filter(c => {
        // Buscar en factura, productor Y operario
        const nombreProductor = c.tipo_productor === 'EXTERNO'
            ? (c.nombre_productor_externo || '')
            : [c.productor?.usuario?.nombre, c.productor?.usuario?.apellido, c.productor?.nombre]
                .filter(Boolean).join(' ');
        const txt = `${c.numero_factura || ''} ${nombreProductor}`.toLowerCase();
        const okBuscar = !_cmp_buscar || txt.includes(_cmp_buscar);
        // Normalizar estado: COMPLETADA y COMPLETADO se tratan igual
        const estadoRaw = (c.estado || '').toUpperCase().trim();
        const estadoCompra = estadoRaw === 'COMPLETADA' ? 'COMPLETADO' : estadoRaw;
        const filtroEstado = (_cmp_estado || '').toUpperCase().trim();
        const okEstado = !filtroEstado || estadoCompra === filtroEstado;

        // Filtros de fecha
        let okFecha = true;
        if (_cmp_fechaDesde || _cmp_fechaHasta) {
            const fechaRaw = c.fecha_compra || c.fecha || '';
            if (!fechaRaw) {
                okFecha = false;
            } else {
                const fechaCompra = new Date(parseFechaLocal(fechaRaw));
                fechaCompra.setHours(0, 0, 0, 0);
                if (_cmp_fechaDesde) {
                    const desde = new Date(parseFechaLocal(_cmp_fechaDesde));
                    desde.setHours(0, 0, 0, 0);
                    if (fechaCompra < desde) okFecha = false;
                }
                if (_cmp_fechaHasta) {
                    const hasta = new Date(parseFechaLocal(_cmp_fechaHasta));
                    hasta.setHours(23, 59, 59, 999);
                    if (fechaCompra > hasta) okFecha = false;
                }
            }
        }

        // Filtro por comprobante de pago
        const okPago = !_cmp_pago || (c.estado_pago || 'PENDIENTE').toUpperCase() === _cmp_pago;

        return okBuscar && okEstado && okFecha && okPago;
    });

    document.getElementById('cmp_count').textContent = `${lista.length} registro${lista.length !== 1 ? 's' : ''}`;

    if (!lista.length) {
        tbody.innerHTML = `<tr><td colspan="8" style="text-align:center;padding:40px;color:#9ca3af">Sin registros</td></tr>`;
        return;
    }

    const fmt = n => n != null ? `$${Number(n).toLocaleString('es-CO')}` : '—';
    const fmtFecha = f => fmtFechaLocal(f);

    tbody.innerHTML = lista.map(c => {
        // Nombre del productor
        const esExterno = c.tipo_productor === 'EXTERNO' || (!c.id_productor && c.nombre_productor_externo);
        const productor = esExterno
            ? `${c.nombre_productor_externo || 'Externo'} <span class="badge-externo">(externo)</span>`
            : c.productor?.usuario?.nombre
                ? `${c.productor.usuario.nombre} ${c.productor.usuario.apellido || ''}`.trim()
                : (c.productor?.nombre || '—');

        const nDetalles = c.detalles?.length ?? '—';
        const idEntrega = c.id_entrega || c.id_compra;
        const estadoPago = c.estado_pago || 'PENDIENTE';
        const comprobante = c.comprobante_pago || null;
        const isPagado = estadoPago === 'PAGADO';
        const estadoBadge = isPagado
            ? `<span style="background:#d1fae5;color:#065f46;border-radius:99px;padding:2px 8px;font-size:.72rem;font-weight:700"> Pagado</span>`
            : `<span style="background:#fef3c7;color:#92400e;border-radius:99px;padding:2px 8px;font-size:.72rem;font-weight:700">Pendiente</span>`;
        const comprobanteCol = isPagado && comprobante
            ? `<div style="display:flex;flex-direction:column;gap:4px;align-items:flex-start">
                ${estadoBadge}
                <a href="${comprobante.startsWith('http') ? comprobante : (STATIC_URL + comprobante)}"
                   target="_blank"
                   style="font-size:.72rem;color:#2563eb;text-decoration:none;display:flex;align-items:center;gap:3px">
                   <i class="fi fi-rr-download"></i> Ver comprobante
                </a>
                <button class="usr-btn-action" title="Eliminar comprobante"
                        style="font-size:.7rem;padding:2px 6px;color:#dc2626;background:#fee2e2;border:none;border-radius:6px;cursor:pointer"
                        onclick="cmp_eliminarComprobante(${idEntrega})">
                    <i class="fi fi-rr-trash"></i>
                </button>
               </div>`
            : `<div style="display:flex;flex-direction:column;gap:4px;align-items:flex-start">
                ${estadoBadge}
                <label style="cursor:pointer;font-size:.72rem;color:#2563eb;display:flex;align-items:center;gap:3px">
                    <i class="fi fi-rr-upload"></i> Subir
                    <input type="file" accept=".pdf,.jpg,.jpeg,.png,.webp"
                           style="display:none"
                           onchange="cmp_subirComprobante(${idEntrega}, this)">
                </label>
               </div>`;
        return `<tr>
            <td style="font-family:monospace;font-size:.82em;font-weight:700">${c.numero_factura || '—'}</td>
            <td>${productor}</td>
            <td style="font-size:.85em;color:#6b7280">${fmtFecha(c.fecha_compra)}</td>
            <td style="text-align:center">${nDetalles}</td>
            <td style="font-weight:700;color:#111827">${fmt(c.total)}</td>
            <td><span class="badge-estado badge-${c.estado || 'pendiente'}">${c.estado || 'pendiente'}</span></td>
            <td>${comprobanteCol}</td>
            <td>
                <div style="display:flex;gap:6px;justify-content:flex-end">
                    <button class="usr-btn-action usr-btn-edit" title="Ver detalle"
                            onclick="det_abrir('compra', ${c.id_compra})">
                        <i class="fi fi-rr-eye"></i>
                    </button>
                </div>
            </td>
            <td>
                <button class="usr-btn-action usr-btn-del" title="Eliminar compra"
                        onclick="cmp_desactivar(${c.id_compra})">
                    <i class="fi fi-rr-trash"></i>
                </button>
            </td>
        </tr>`;
    }).join('');
}
function cmp_desactivar(id) {
    if (!confirm('¿Confirma que desea desactivar esta compra? Esta acción se puede revertir.')) return;

    const token = localStorage.getItem('token');

    fetch(`${API_URL}/compras/${id}/desactivar`, {
        method: 'PATCH',
        headers: {
            'Content-Type': 'application/json',
            Authorization: `Bearer ${token}`
        },
        body: JSON.stringify({ activo: false }) // aquí "activo" es el campo que marca si está disponible
    })
        .then(res => {
            if (!res.ok) return res.json().then(err => { throw new Error(err.message || 'Error al desactivar'); });

            // Actualizamos la lista local, filtrando o marcando como inactivo
            _cmp_todos = _cmp_todos.map(c => c.id_compra === id ? { ...c, activo: false } : c);

            cmp_renderTabla(); // renderizamos la tabla con los cambios
        })
        .catch(e => alert(`Error: ${e.message}`));
}

// ── SUBIR COMPROBANTE (admin) ─────────────────────────────
async function cmp_subirComprobante(idEntrega, inputEl) {
    const file = inputEl.files[0];
    if (!file) return;

    // ── Validación en el frontend antes de enviar ─────────────────
    const maxMB = 10;
    if (file.size > maxMB * 1024 * 1024) {
        alert(`El archivo es demasiado grande. Máximo ${maxMB} MB.`);
        inputEl.value = '';
        return;
    }
    const ext = file.name.split('.').pop().toLowerCase();
    const tiposOk = ['pdf', 'jpg', 'jpeg', 'png', 'webp'];
    if (!tiposOk.includes(ext)) {
        alert(`Tipo de archivo no permitido: .${ext}\nSolo se aceptan: PDF, JPG, JPEG, PNG, WEBP`);
        inputEl.value = '';
        return;
    }

    const token = localStorage.getItem('token') || '';
    const formData = new FormData();
    // El campo DEBE llamarse 'comprobante' — es lo que espera el backend
    formData.append('comprobante', file);

    showLoading();
    try {
        const res = await fetch(`${API_URL}/entregas/${idEntrega}/comprobante`, {
            method: 'POST',
            //  NO incluir Content-Type — el navegador lo pone automáticamente
            // con el boundary correcto para multipart/form-data
            headers: { Authorization: `Bearer ${token}` },
            body: formData,
        });

        // Parsear respuesta de forma segura (puede ser JSON o HTML de error)
        let json = null;
        const contentType = res.headers.get('content-type') || '';
        if (contentType.includes('application/json')) {
            json = await res.json();
        } else {
            const texto = await res.text();
            throw new Error(`Error del servidor (${res.status}): ${texto.substring(0, 120)}`);
        }

        if (!res.ok) throw new Error(json?.message || json?.error || `Error ${res.status}`);

        await cmp_cargar();
        const banner = document.createElement('div');
        banner.textContent = 'Comprobante subido. Entrega marcada como PAGADA.';
        banner.style.cssText = 'position:fixed;bottom:24px;right:24px;z-index:9999;background:#d1fae5;color:#065f46;padding:12px 20px;border-radius:12px;font-weight:600;box-shadow:0 4px 16px rgba(0,0,0,.15)';
        document.body.appendChild(banner);
        setTimeout(() => banner.remove(), 4000);
    } catch (e) {
        alert('No se pudo subir el comprobante:\n' + e.message);
    } finally {
        hideLoading();
        inputEl.value = '';
    }
}

// ── ELIMINAR COMPROBANTE (admin) ──────────────────────────
async function cmp_eliminarComprobante(idEntrega) {
    if (!confirm('¿Eliminar el comprobante? La entrega volverá a estado PENDIENTE.')) return;

    const token = localStorage.getItem('token') || '';
    showLoading();
    try {
        const res = await fetch(`${API_URL}/entregas/${idEntrega}/comprobante`, {
            method: 'DELETE',
            headers: { Authorization: `Bearer ${token}` },
        });
        if (!res.ok) {
            const json = await res.json();
            throw new Error(json.message || 'Error al eliminar comprobante');
        }
        await cmp_cargar();
    } catch (e) {
        alert('Error: ' + e.message);
    } finally {
        hideLoading();
    }
}

// ════════════════════════════════════════════════════════
//  MÓDULO VENTAS
// ════════════════════════════════════════════════════════
let _vnt_todos = [];
let _vnt_buscar = '';
let _vnt_estado = '';
let _vnt_fechaDesde = '';
let _vnt_fechaHasta = '';

async function vnt_cargar() {
    const token = localStorage.getItem('token');

    // Resetear filtros al entrar a la sección
    _vnt_estado = '';
    _vnt_buscar = '';
    _vnt_fechaDesde = '';
    _vnt_fechaHasta = '';
    const buscarInput = document.getElementById('vnt_buscar');
    if (buscarInput) buscarInput.value = '';
    const desdeInput = document.getElementById('vnt_fecha_desde');
    if (desdeInput) desdeInput.value = '';
    const hastaInput = document.getElementById('vnt_fecha_hasta');
    if (hastaInput) hastaInput.value = '';
    document.querySelectorAll('#ventas .usr-ftab').forEach((b, i) => {
        b.classList.toggle('active', i === 0);
    });

    try {
        const res = await fetch(`${API_URL}/ventas`, {
            headers: { Authorization: `Bearer ${token}` }
        });
        const json = await res.json();
        _vnt_todos = Array.isArray(json) ? json : (json.data || []);
        vnt_renderTabla();
    } catch (e) {
        document.getElementById('vnt_tbody').innerHTML =
            `<tr><td colspan="8" style="text-align:center;padding:40px;color:#ef4444">Error: ${e.message}</td></tr>`;
    }
}

function vnt_filtrar(val) { _vnt_buscar = val.toLowerCase(); vnt_renderTabla(); }
function vnt_setFechaDesde(val) { _vnt_fechaDesde = val; vnt_renderTabla(); }
function vnt_setFechaHasta(val) { _vnt_fechaHasta = val; vnt_renderTabla(); }

function vnt_setEstado(val, btn) {
    _vnt_estado = val;
    document.querySelectorAll('#ventas .usr-ftab').forEach(b => b.classList.remove('active'));
    btn.classList.add('active');
    vnt_renderTabla();
}

function vnt_renderTabla() {
    const tbody = document.getElementById('vnt_tbody');
    if (!tbody) return;

    const lista = _vnt_todos.filter(v => {
        // Buscar en factura, cliente, comerciante Y operario
        const txt = `${v.numero_factura || ''} ${v.cliente || ''} ${v.comerciante?.nombre || ''}`.toLowerCase();
        const okBuscar = !_vnt_buscar || txt.includes(_vnt_buscar);
        // Normalizar estado: COMPLETADA y COMPLETADO se tratan igual
        const estadoRawV = (v.estado || '').toUpperCase().trim();
        const estadoVenta = estadoRawV === 'COMPLETADA' ? 'COMPLETADO' : estadoRawV;
        const filtroEstado = (_vnt_estado || '').toUpperCase().trim();
        const okEstado = !filtroEstado || estadoVenta === filtroEstado;

        // Filtros de fecha
        let okFecha = true;
        if (_vnt_fechaDesde || _vnt_fechaHasta) {
            const fechaRaw = v.fecha_venta || v.fecha || '';
            if (!fechaRaw) {
                okFecha = false;
            } else {
                const fechaVenta = new Date(parseFechaLocal(fechaRaw));
                fechaVenta.setHours(0, 0, 0, 0);
                if (_vnt_fechaDesde) {
                    const desde = new Date(parseFechaLocal(_vnt_fechaDesde));
                    desde.setHours(0, 0, 0, 0);
                    if (fechaVenta < desde) okFecha = false;
                }
                if (_vnt_fechaHasta) {
                    const hasta = new Date(parseFechaLocal(_vnt_fechaHasta));
                    hasta.setHours(23, 59, 59, 999);
                    if (fechaVenta > hasta) okFecha = false;
                }
            }
        }

        return okBuscar && okEstado && okFecha;
    });

    document.getElementById('vnt_count').textContent = `${lista.length} registro${lista.length !== 1 ? 's' : ''}`;

    if (!lista.length) {
        tbody.innerHTML = `<tr><td colspan="8" style="text-align:center;padding:40px;color:#9ca3af">Sin registros</td></tr>`;
        return;
    }

    const fmt = n => n != null ? `$${Number(n).toLocaleString('es-CO')}` : '—';
    const fmtFecha = f => fmtFechaLocal(f);

    tbody.innerHTML = lista.map(v => {
        const nDetalles = v.detalles?.length ?? '—';

        // Columna de factura — el admin puede reenviar el correo si quiere
        const emailCom = v.comerciante?.email || v.comerciante?.correo || '';
        const facturaBtn = `<button class="usr-btn-action" title="${emailCom ? 'Reenviar factura por correo' : 'Sin correo — asignar y enviar'}"
                       style="background:${emailCom ? '#eff6ff' : '#f9fafb'};color:${emailCom ? '#2563eb' : '#9ca3af'}"
                       onclick="vnt_abrirModalReenvio(${v.id_venta}, '${(emailCom).replace(/'/g, "\\'")}', '${(v.numero_factura || '').replace(/'/g, "\\'")}', '${(v.comerciante?.nombre || v.cliente || '').replace(/'/g, "\\'")}')">
                   <i class="fi fi-rr-envelope"></i>
               </button>`;
        return `<tr>
            <td style="font-family:monospace;font-size:.82em;font-weight:700">${v.numero_factura || '—'}</td>
            <td>${v.comerciante?.nombre ?? (v.cliente || '—')}</td>
            <td style="font-size:.85em;color:#6b7280">${fmtFecha(v.fecha_venta)}</td>
            <td style="text-align:center">${nDetalles}</td>
            <td style="font-weight:700;color:#111827">${fmt(v.total)}</td>
            <td><span class="badge-estado badge-${v.estado || 'pendiente'}">${v.estado || 'pendiente'}</span></td>
            <td style="text-align:center">${facturaBtn}</td>
            <td>
                <div style="display:flex;gap:6px;justify-content:flex-end">
                    ${(v.estado || '').toUpperCase().trim() !== 'COMPLETADO' && (v.estado || '').toUpperCase().trim() !== 'COMPLETADA'
                ? `<button class="usr-btn-action" title="Marcar como COMPLETADO"
                                 style="background:#d1fae5;color:#065f46"
                                 onclick="vnt_marcarCompletada(${v.id_venta})">
                             <i class="fi fi-rr-check"></i>
                         </button>` : ''}
                    <button class="usr-btn-action usr-btn-edit" title="Ver detalle"
                            onclick="det_abrir('venta', ${v.id_venta})">
                        <i class="fi fi-rr-eye"></i>
                    </button>
                </div>
            </td>
        </tr>`;
    }).join('');
}

// ════════════════════════════════════════════════════════
//  SIMULACION FACTURA ELECTRONICA
// ════════════════════════════════════════════════════════

/**
 * Simula el envío de una factura electrónica al correo del comerciante.
 * Muestra una ventana emergente con los datos de la factura
 * tal como aparecería en el correo — sin enviar nada real.
 */
// ════════════════════════════════════════════════════════
//  REENVÍO DE FACTURA — Panel Admin
//  El admin puede reenviar la factura de cualquier venta
//  a cualquier correo desde la tabla de ventas.
// ════════════════════════════════════════════════════════

/**
 * Abre un pequeño modal inline para reenviar la factura desde el panel admin.
 * Más simple que el modal del operario — solo pide confirmar/cambiar el email.
 */
function vnt_abrirModalReenvio(id_venta, emailActual, numeroFactura, nombreCliente) {
    // Remover modal anterior si existe
    const anterior = document.getElementById('modal-reenvio-factura');
    if (anterior) anterior.remove();

    const overlay = document.createElement('div');
    overlay.id = 'modal-reenvio-factura';
    overlay.style.cssText = 'position:fixed;inset:0;z-index:9999;background:rgba(0,0,0,.5);backdrop-filter:blur(4px);display:flex;align-items:center;justify-content:center;padding:16px';
    overlay.onclick = (e) => { if (e.target === overlay) overlay.remove(); };

    overlay.innerHTML = `
        <div style="background:#fff;border-radius:16px;width:100%;max-width:420px;
                    box-shadow:0 24px 64px rgba(0,0,0,.2);overflow:hidden;
                    animation:slideUp .25s ease">
            <!-- Header -->
            <div style="background:linear-gradient(135deg,#1d4ed8,#2563eb);padding:18px 20px;
                        display:flex;align-items:center;gap:10px">
                <div style="width:36px;height:36px;background:rgba(255,255,255,.18);border-radius:50%;
                            display:flex;align-items:center;justify-content:center;flex-shrink:0">
                    <i class="fi fi-rr-envelope" style="color:#fff;display:flex;font-size:.95rem"></i>
                </div>
                <div>
                    <div style="color:#fff;font-weight:800;font-size:.95rem">Enviar Factura</div>
                    <div style="color:rgba(255,255,255,.75);font-size:.75rem">${numeroFactura || 'Sin número'} · ${nombreCliente || 'Sin cliente'}</div>
                </div>
                <button onclick="document.getElementById('modal-reenvio-factura').remove()"
                    style="margin-left:auto;background:rgba(255,255,255,.15);border:none;cursor:pointer;
                           color:#fff;width:28px;height:28px;border-radius:50%;font-size:.9rem;
                           display:flex;align-items:center;justify-content:center;flex-shrink:0">✕</button>
            </div>

            <!-- Body -->
            <div style="padding:20px">
                <label style="font-size:.8rem;font-weight:700;color:#374151;display:block;margin-bottom:6px">
                    Correo del comerciante
                </label>
                <div style="display:flex;gap:8px;margin-bottom:10px">
                    <input type="email" id="reenvio-email-input"
                        value="${emailActual}"
                        placeholder="correo@comerciante.com"
                        style="flex:1;border:1.5px solid #d1d5db;border-radius:8px;padding:9px 12px;
                               font-size:.87rem;outline:none;transition:border-color .2s"
                        onfocus="this.style.borderColor='#2563eb'"
                        onblur="this.style.borderColor='#d1d5db'"
                        onkeydown="if(event.key==='Enter'){event.preventDefault();vnt_confirmarReenvio(${id_venta})}" />
                </div>
                <div id="reenvio-estado" style="font-size:.8rem;font-weight:600;min-height:18px;margin-bottom:12px"></div>
                <div style="display:flex;gap:8px;justify-content:flex-end">
                    <button onclick="document.getElementById('modal-reenvio-factura').remove()"
                        style="background:#f3f4f6;color:#374151;border:none;border-radius:8px;
                               padding:9px 16px;font-size:.85rem;font-weight:600;cursor:pointer">
                        Cancelar
                    </button>
                    <button id="reenvio-btn-enviar" onclick="vnt_confirmarReenvio(${id_venta})"
                        style="background:#2563eb;color:#fff;border:none;border-radius:8px;
                               padding:9px 18px;font-size:.85rem;font-weight:700;cursor:pointer;
                               display:flex;align-items:center;gap:6px">
                        <i class="fi fi-rr-paper-plane" style="display:flex"></i> Enviar factura
                    </button>
                </div>
            </div>
        </div>
        <style>
            @keyframes slideUp {
                from { transform:translateY(16px);opacity:0 }
                to   { transform:translateY(0);opacity:1 }
            }
        </style>`;

    document.body.appendChild(overlay);
    setTimeout(() => document.getElementById('reenvio-email-input')?.focus(), 100);
}

async function vnt_confirmarReenvio(id_venta) {
    const email = (document.getElementById('reenvio-email-input')?.value || '').trim();
    const estadoEl = document.getElementById('reenvio-estado');
    const btn = document.getElementById('reenvio-btn-enviar');

    if (!email) {
        estadoEl.textContent = 'Ingresa un correo válido.';
        estadoEl.style.color = '#dc2626';
        return;
    }
    if (!/^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(email)) {
        estadoEl.textContent = 'El formato del correo no es válido.';
        estadoEl.style.color = '#dc2626';
        return;
    }

    btn.disabled = true;
    btn.innerHTML = '<i class="fi fi-rr-spinner" style="display:flex"></i> Enviando...';
    estadoEl.textContent = '';

    const token = localStorage.getItem('token') || '';
    try {
        const res = await fetch(`${API_URL}/ventas/${id_venta}/estado`, {
            method: 'PATCH',
            headers: { 'Content-Type': 'application/json', Authorization: `Bearer ${token}` },
            body: JSON.stringify({ estado: 'COMPLETADA', email_factura: email })
        });
        if (!res.ok) {
            const err = await res.json().catch(() => ({}));
            throw new Error(err.message || `Error ${res.status}`);
        }
        estadoEl.textContent = `✓ Factura enviada a ${email}`;
        estadoEl.style.color = '#16a34a';
        btn.innerHTML = '<i class="fi fi-rr-check" style="display:flex"></i> Enviado';
        // Recargar tabla después de 1.5s y cerrar modal
        setTimeout(() => {
            document.getElementById('modal-reenvio-factura')?.remove();
            vnt_cargar();
        }, 1500);
    } catch (e) {
        estadoEl.textContent = `Error: ${e.message}`;
        estadoEl.style.color = '#dc2626';
        btn.disabled = false;
        btn.innerHTML = '<i class="fi fi-rr-paper-plane" style="display:flex"></i> Reintentar';
    }
}

async function vnt_marcarCompletada(id_venta) {
    if (!confirm('¿Marcar esta venta como completada?')) return;
    const token = localStorage.getItem('token') || '';
    showLoading();
    try {
        const res = await fetch(`${API_URL}/ventas/${id_venta}/estado`, {
            method: 'PATCH',
            headers: { 'Content-Type': 'application/json', Authorization: `Bearer ${token}` },
            body: JSON.stringify({ estado: 'COMPLETADA' })
        });
        if (!res.ok) { const e = await res.json(); throw new Error(e.message); }
        await vnt_cargar();
    } catch (e) {
        alert('Error: ' + e.message);
    } finally { hideLoading(); }
}


// ════════════════════════════════════════════════════════
//  MODAL DETALLE COMPRA / VENTA
// ════════════════════════════════════════════════════════
async function det_abrir(tipo, id) {
    const token = localStorage.getItem('token');
    const modal = document.getElementById('det_modal');
    modal.style.display = 'flex';

    document.getElementById('det_titulo').textContent = tipo === 'compra' ? 'Detalle de Compra' : ' Detalle de Venta';
    document.getElementById('det_subtitulo').textContent = 'Cargando...';
    document.getElementById('det_info').innerHTML = '';
    document.getElementById('det_tbody').innerHTML = '<tr><td colspan="4" style="padding:20px;text-align:center;color:#9ca3af">Cargando...</td></tr>';
    document.getElementById('det_total').textContent = '';

    try {
        const url = tipo === 'compra' ? `${API_URL}/compras/${id}` : `${API_URL}/ventas/${id}`;
        const res = await fetch(url, { headers: { Authorization: `Bearer ${token}` } });
        const json = await res.json();
        const d = json.data || json;

        const fmt = n => n != null ? `$${Number(n).toLocaleString('es-CO')}` : '—';
        const fmtFecha = f => fmtFechaLocal(f);

        document.getElementById('det_subtitulo').textContent = `Factura: ${d.numero_factura || '—'}`;

        // Info cards
        let infoHTML = '';
        if (tipo === 'compra') {
            const esExternoDet = d.tipo_productor === 'EXTERNO' || (!d.id_productor && d.nombre_productor_externo);
            const prod = esExternoDet
                ? `${d.nombre_productor_externo || 'Externo'} (externo)`
                : d.productor?.usuario?.nombre
                    ? `${d.productor.usuario.nombre} ${d.productor.usuario.apellido || ''}`.trim()
                    : (d.productor?.nombre || '—');
            infoHTML = `
                <div class="det-info-item"><span class="det-info-label">Productor</span><span class="det-info-value">${prod}</span></div>
                <div class="det-info-item"><span class="det-info-label">Fecha compra</span><span class="det-info-value">${fmtFecha(d.fecha_compra)}</span></div>
                <div class="det-info-item"><span class="det-info-label">Estado</span><span class="det-info-value"><span class="badge-estado badge-${d.estado || 'pendiente'}">${d.estado || 'pendiente'}</span></span></div>
                <div class="det-info-item"><span class="det-info-label">Total</span><span class="det-info-value" style="color:#0aae0a">${fmt(d.total)}</span></div>`;
        } else {
            infoHTML = `
                <div class="det-info-item"><span class="det-info-label">Cliente</span><span class="det-info-value">${d.cliente || '—'}</span></div>
                <div class="det-info-item"><span class="det-info-label">Fecha venta</span><span class="det-info-value">${fmtFecha(d.fecha_venta)}</span></div>
                <div class="det-info-item"><span class="det-info-label">Estado</span><span class="det-info-value"><span class="badge-estado badge-${d.estado || 'pendiente'}">${d.estado || 'pendiente'}</span></span></div>
                <div class="det-info-item"><span class="det-info-label">Total</span><span class="det-info-value" style="color:#0aae0a">${fmt(d.total)}</span></div>`;
        }
        document.getElementById('det_info').innerHTML = infoHTML;

        // Detalles
        const detalles = d.detalles || [];
        if (!detalles.length) {
            document.getElementById('det_tbody').innerHTML =
                '<tr><td colspan="4" style="padding:20px;text-align:center;color:#9ca3af">Sin productos registrados</td></tr>';
        } else {
            document.getElementById('det_tbody').innerHTML = detalles.map(item => `
                <tr>
                    <td style="padding:8px 10px;border-bottom:1px solid #f3f4f6">${item.producto?.nombre || '—'}</td>
                    <td style="padding:8px 10px;text-align:right;border-bottom:1px solid #f3f4f6">${item.cantidad} ${item.producto?.unidad_medida || ''}</td>
                    <td style="padding:8px 10px;text-align:right;border-bottom:1px solid #f3f4f6">${fmt(item.precio_unitario)}</td>
                    <td style="padding:8px 10px;text-align:right;border-bottom:1px solid #f3f4f6;font-weight:700">${fmt(item.subtotal)}</td>
                </tr>`).join('');
        }
        document.getElementById('det_total').textContent = fmt(d.total);

    } catch (e) {
        document.getElementById('det_subtitulo').textContent = 'Error al cargar';
        document.getElementById('det_tbody').innerHTML =
            `<tr><td colspan="4" style="padding:20px;text-align:center;color:#ef4444">${e.message}</td></tr>`;
    }
}

function det_cerrar() {
    document.getElementById('det_modal').style.display = 'none';
}

// ════════════════════════════════════════════════════════
//  MÓDULO HISTORIAL
// ════════════════════════════════════════════════════════
let _his_tabActual = 'transacciones';
let _his_transacciones = [];
let _his_precios = [];
let _his_buscar = '';

async function his_cargar() {
    const token = localStorage.getItem('token');

    const inicio = document.getElementById('his_fecha_inicio')?.value || '';
    const fin = document.getElementById('his_fecha_fin')?.value || '';

    try {
        if (_his_tabActual === 'transacciones') {
            // ── Cargar compras Y ventas en paralelo desde endpoints reales ──
            const [resC, resV] = await Promise.all([
                fetch(`${API_URL}/compras`, { headers: { Authorization: `Bearer ${token}` } }),
                fetch(`${API_URL}/ventas`, { headers: { Authorization: `Bearer ${token}` } }),
            ]);
            const jsonC = resC.ok ? await resC.json() : [];
            const jsonV = resV.ok ? await resV.json() : [];

            const compras = (Array.isArray(jsonC) ? jsonC : (jsonC.data || [])).map(c => ({
                _tipo: 'compra',
                id_ref: c.id_compra,
                numero: c.numero_factura || `COMP-${String(c.id_compra).padStart(6, '0')}`,
                fecha: c.fecha_compra || c.fecha,
                contraparte: (c.tipo_productor === 'EXTERNO' || (!c.id_productor && c.nombre_productor_externo))
                    ? `${c.nombre_productor_externo || 'Externo'} (externo)`
                    : c.productor?.usuario
                        ? `${c.productor.usuario.nombre || ''} ${c.productor.usuario.apellido || ''}`.trim()
                        : (c.productor?.nombre || '—'),
                producto: c.detalles?.map(d => d.producto?.nombre || `#${d.id_producto}`).join(', ') || '—',
                peso: c.detalles?.reduce((s, d) => s + Number(d.peso_kg || d.cantidad || 0), 0) || null,
                total: c.total,
                estado: c.estado || 'pendiente',
                estado_pago: c.estado_pago || 'PENDIENTE',
            }));

            const ventas = (Array.isArray(jsonV) ? jsonV : (jsonV.data || [])).map(v => ({
                _tipo: 'venta',
                id_ref: v.id_venta,
                numero: v.numero_factura || `VENT-${String(v.id_venta).padStart(6, '0')}`,
                fecha: v.fecha_venta || v.fecha,
                contraparte: v.comerciante?.nombre || v.cliente || '—',
                producto: v.detalles?.map(d => d.producto?.nombre || `#${d.id_producto}`).join(', ') || '—',
                peso: v.detalles?.reduce((s, d) => s + Number(d.cantidad || 0), 0) || null,
                total: v.total,
                estado: v.estado || 'pendiente',
                estado_pago: null,
            }));

            // Combinar y ordenar por fecha descendente
            let todas = [...compras, ...ventas].sort((a, b) => {
                const da = a.fecha ? new Date(parseFechaLocal(a.fecha)) : 0;
                const db = b.fecha ? new Date(parseFechaLocal(b.fecha)) : 0;
                return db - da;
            });

            // Aplicar filtro de fechas en cliente
            if (inicio) {
                const desdeDate = new Date(inicio);
                desdeDate.setHours(0, 0, 0, 0);
                todas = todas.filter(t => {
                    if (!t.fecha) return false;
                    const fd = new Date(parseFechaLocal(t.fecha));
                    fd.setHours(0, 0, 0, 0);
                    return fd >= desdeDate;
                });
            }
            if (fin) {
                const hastaDate = new Date(fin);
                hastaDate.setHours(23, 59, 59, 999);
                todas = todas.filter(t => {
                    if (!t.fecha) return false;
                    return new Date(parseFechaLocal(t.fecha)) <= hastaDate;
                });
            }

            _his_transacciones = todas;
            his_renderTransacciones();
        } else {
            // ── Pestaña PRECIOS → carga desde /precios (módulo admin) ──
            const res = await fetch(`${API_URL}/precios`,
                { headers: { Authorization: `Bearer ${token}` } });
            const json = await res.json();
            _his_precios = Array.isArray(json) ? json : (json.data || []);
            his_renderPrecios();
        }
    } catch (e) {
        const id = _his_tabActual === 'transacciones' ? 'his_tbody_trans' : 'his_tbody_precios';
        document.getElementById(id).innerHTML =
            `<tr><td colspan="7" style="text-align:center;padding:40px;color:#ef4444">Error: ${e.message}</td></tr>`;
    }
}

function his_filtrar(val) { _his_buscar = val.toLowerCase(); his_renderActual(); }

function his_setTab(tab, btn) {
    _his_tabActual = tab;
    _his_buscar = '';
    document.getElementById('his_search').value = '';
    document.querySelectorAll('.his-tab').forEach(b => b.classList.remove('active'));
    btn.classList.add('active');
    document.getElementById('his_tab_transacciones').style.display = tab === 'transacciones' ? '' : 'none';
    document.getElementById('his_tab_precios').style.display = tab === 'precios' ? '' : 'none';
    his_cargar();
}

function his_renderActual() {
    if (_his_tabActual === 'transacciones') his_renderTransacciones();
    else his_renderPrecios();
}

function his_renderTransacciones() {
    const tbody = document.getElementById('his_tbody_trans');
    if (!tbody) return;

    const lista = _his_transacciones.filter(t => {
        const txt = `${t._tipo || ''} ${t.contraparte || ''} ${t.producto || ''} ${t.numero || ''} ${t.estado || ''}`.toLowerCase();
        return !_his_buscar || txt.includes(_his_buscar);
    });

    document.getElementById('his_count').textContent = `${lista.length} registro${lista.length !== 1 ? 's' : ''}`;

    if (!lista.length) {
        tbody.innerHTML = `<tr><td colspan="7" style="text-align:center;padding:40px;color:#9ca3af">Sin registros</td></tr>`;
        return;
    }

    const fmt = n => n != null ? `$${Number(n).toLocaleString('es-CO')}` : '—';
    const fmtFecha = f => fmtFechaLocal(f);

    tbody.innerHTML = lista.map(t => {
        const esCompra = t._tipo === 'compra';
        const tipoBadge = `<span class="badge-estado badge-${esCompra ? 'compra' : 'venta'}">${esCompra ? 'Compra' : 'Venta'}</span>`;

        // Estado pago solo aplica a compras
        let estadoExtra = '';
        if (esCompra && t.estado_pago) {
            const isPagado = t.estado_pago === 'PAGADO';
            estadoExtra = isPagado
                ? `<br><span style="font-size:.68rem;background:#d1fae5;color:#065f46;border-radius:99px;padding:1px 6px;font-weight:700"> Pago</span>`
                : `<br><span style="font-size:.68rem;background:#fef3c7;color:#92400e;border-radius:99px;padding:1px 6px;font-weight:700">⏳ Pago pend.</span>`;
        }

        const pesoStr = t.peso ? `${Number(t.peso).toLocaleString('es-CO')} kg` : '—';

        return `<tr>
            <td style="font-family:monospace;font-size:.82em;font-weight:700">${t.numero}</td>
            <td>${tipoBadge}</td>
            <td style="font-size:.84em;color:#6b7280">${fmtFecha(t.fecha)}</td>
            <td style="font-size:.84em">${t.contraparte}</td>
            <td style="font-size:.82em;color:#6b7280">${t.producto}<br><small>${pesoStr}</small></td>
            <td style="font-weight:700;color:#111827">${fmt(t.total)}${estadoExtra}</td>
            <td><span class="badge-estado badge-${(t.estado || 'pendiente').toLowerCase()}">${t.estado || 'pendiente'}</span></td>
        </tr>`;
    }).join('');
}

function his_renderPrecios() {
    const tbody = document.getElementById('his_tbody_precios');
    if (!tbody) return;

    const fmt = n => n != null ? `$${Number(n).toLocaleString('es-CO')}` : '—';

    // Leer filtros de fecha del toolbar (compartidos con transacciones)
    const inicio = document.getElementById('his_fecha_inicio')?.value || '';
    const fin    = document.getElementById('his_fecha_fin')?.value    || '';

    const lista = _his_precios.filter(p => {
        const nombre = (p.producto?.nombre || '').toLowerCase();
        const okBuscar = !_his_buscar || nombre.includes(_his_buscar);

        let okFecha = true;
        if (inicio || fin) {
            const fechaRaw = p.fecha || '';
            if (!fechaRaw) {
                okFecha = false;
            } else {
                const fd = new Date(parseFechaLocal(fechaRaw));
                fd.setHours(0, 0, 0, 0);
                if (inicio) {
                    const d = new Date(parseFechaLocal(inicio));
                    d.setHours(0, 0, 0, 0);
                    if (fd < d) okFecha = false;
                }
                if (fin) {
                    const h = new Date(parseFechaLocal(fin));
                    h.setHours(23, 59, 59, 999);
                    if (fd > h) okFecha = false;
                }
            }
        }

        return okBuscar && okFecha;
    });

    document.getElementById('his_count').textContent =
        `${lista.length} registro${lista.length !== 1 ? 's' : ''}`;

    if (!lista.length) {
        tbody.innerHTML = `<tr><td colspan="7" style="text-align:center;padding:40px;color:#9ca3af">Sin registros de precios semanales</td></tr>`;
        return;
    }

    tbody.innerHTML = lista.map(p => {
        const nombreProd = p.producto?.nombre || `Producto #${p.id_producto}`;
        const estado = p.activo
            ? `<span style="background:#d1fae5;color:#065f46;border-radius:99px;padding:2px 10px;font-size:.73rem;font-weight:700">Activo</span>`
            : `<span style="background:#f3f4f6;color:#6b7280;border-radius:99px;padding:2px 10px;font-size:.73rem;font-weight:700">Inactivo</span>`;
        const fecha = p.fecha
            ? fmtFechaLocal(p.fecha)
            : '—';
        const primo = Number(p.precio_base_kg);
        const otros = primo + 100;
        return `<tr>
            <td><strong>${nombreProd}</strong></td>
            <td style="text-align:right;font-weight:600">${fmt(p.precio_base_kg)}</td>
            <td style="text-align:right;color:#16a34a;font-weight:700">${fmt(primo)}</td>
            <td style="text-align:right;color:#2563eb;font-weight:700">${fmt(otros)}</td>
            <td style="font-size:.84em;color:#6b7280">${fecha}</td>
            <td>${estado}</td>
        </tr>`;
    }).join('');
}

// ── Exportar Excel ──────────────────────────────────────
function his_exportarExcel() {
    const datos = _his_tabActual === 'transacciones' ? _his_transacciones : _his_precios;
    if (!datos.length) { alert('No hay datos para exportar'); return; }

    // Usamos TSV (tab-separated) con BOM UTF-8 → Excel abre cada columna separada correctamente
    const TAB = '\t';
    const NL = '\r\n';
    const esc = v => {
        const s = String(v ?? '');
        // Si contiene tab o salto de línea, encerramos en comillas
        return s.includes('\t') || s.includes('\n') ? `"${s.replace(/"/g, '""')}"` : s;
    };
    const fmtFecha = d => d ? fmtFechaLocal(d) : '';
    const fmtMonto = n => n != null ? Number(n).toLocaleString('es-CO', { minimumFractionDigits: 2 }) : '';

    let filas = [];

    if (_his_tabActual === 'transacciones') {
        filas.push(['Número', 'Tipo', 'Fecha', 'Contraparte', 'Producto', 'Total ($)', 'Estado']);
        datos.forEach(t => filas.push([
            t.numero || '',
            t._tipo || '',
            fmtFecha(t.fecha),
            t.contraparte || '',
            t.producto || '',
            fmtMonto(t.total),
            t.estado || '',
        ]));
    } else {
        filas.push(['Producto', 'Precio Base/kg', 'Transporte', 'Costo Transp/kg', 'Precio Productor/kg', 'Fecha', 'Estado']);
        datos.forEach(p => filas.push([
            p.producto?.nombre || `Producto #${p.id_producto}`,
            fmtMonto(p.precio_base_kg),
            fmtMonto(p.precio_transporte),
            fmtMonto(p.costo_transporte_kg),
            fmtMonto(p.precio_final_kg),
            fmtFecha(p.fecha),
            p.activo ? 'Activo' : 'Inactivo'
        ]));
    }

    const tsv = filas.map(r => r.map(esc).join(TAB)).join(NL);
    const blob = new Blob(['\uFEFF' + tsv], { type: 'text/tab-separated-values;charset=utf-8' });
    const url = URL.createObjectURL(blob);
    const a = document.createElement('a');
    a.href = url;
    a.download = `historial_${_his_tabActual}_${fechaHoyColombia()}.xls`;
    a.click();
    setTimeout(() => URL.revokeObjectURL(url), 5000);
}

// ── Exportar PDF ────────────────────────────────────────
function his_exportarPDF() {
    const datos = _his_tabActual === 'transacciones' ? _his_transacciones : _his_precios;
    if (!datos.length) { alert('No hay datos para exportar'); return; }

    const fmt = n => n != null ? `$${Number(n).toLocaleString('es-CO')}` : '—';
    const titulo = _his_tabActual === 'transacciones' ? 'Historial de Transacciones' : 'Historial de Precios';
    const fecha = new Date().toLocaleDateString('es-CO', { dateStyle: 'long' });

    let filas = '';
    let cabecera = '';
    if (_his_tabActual === 'transacciones') {
        cabecera = '<tr><th>Número</th><th>Tipo</th><th>Fecha</th><th>Contraparte</th><th>Producto</th><th>Total</th><th>Estado</th></tr>';
        filas = datos.map(t => `<tr>
            <td>${t.numero || '—'}</td>
            <td>${t._tipo === 'compra' ? 'Compra' : 'Venta'}</td>
            <td>${t.fecha ? fmtFechaLocal(t.fecha) : '—'}</td>
            <td>${t.contraparte || '—'}</td>
            <td>${t.producto || '—'}</td>
            <td>${fmt(t.total)}</td>
            <td>${t.estado || '—'}</td>
        </tr>`).join('');
    } else {
        cabecera = '<tr><th>Producto</th><th>Base/kg</th><th>Transporte</th><th>Costo/kg</th><th>Precio Productor/kg</th><th>Fecha</th><th>Estado</th></tr>';
        filas = datos.map(p => `<tr>
            <td>${p.producto?.nombre || '—'}</td>
            <td>${fmt(p.precio_base_kg)}</td>
            <td>${fmt(p.precio_transporte)}</td>
            <td>${fmt(p.costo_transporte_kg)}</td>
            <td><strong style="color:#16a34a">${fmt(p.precio_final_kg)}</strong></td>
            <td>${p.fecha ? fmtFechaLocal(p.fecha) : '—'}</td>
            <td>${p.activo ? 'Activo' : 'Inactivo'}</td>
        </tr>`).join('');
    }

    const html = `<!DOCTYPE html><html><head><meta charset="UTF-8"><title>${titulo}</title>
    <style>
        body{font-family:'Segoe UI',sans-serif;color:#111827;margin:40px}
        h1{font-size:1.4em;font-weight:900;color:#0aae0a;margin-bottom:4px}
        .sub{font-size:.85em;color:#6b7280;margin-bottom:24px}
        table{width:100%;border-collapse:collapse;font-size:.82em}
        th{background:#f0fdf4;color:#166534;padding:8px 10px;text-align:left;
           border-bottom:2px solid #dcfce7;font-weight:700}
        td{padding:7px 10px;border-bottom:1px solid #f3f4f6}
        tr:hover td{background:#fafafa}
        .footer{margin-top:24px;font-size:.72em;color:#9ca3af;text-align:right}
        @media print{body{margin:20px}.footer{position:fixed;bottom:0;right:20px}}
    </style></head><body>
    <h1><i class="fi fi-sc-seedling"></i> AgroTrace — ${titulo}</h1>
    <div class="sub">Generado el ${fecha} · ${datos.length} registros</div>
    <table><thead>${cabecera}</thead><tbody>${filas}</tbody></table>
    <div class="footer">AgroTrace · Sistema de Trazabilidad de Plátano</div>
    <script>window.addEventListener('load',()=>{setTimeout(()=>window.print(),400)})<\/script>
    </body></html>`;

    const blob = new Blob([html], { type: 'text/html;charset=utf-8' });
    const url = URL.createObjectURL(blob);
    window.open(url, '_blank', 'width=900,height=700');
    setTimeout(() => URL.revokeObjectURL(url), 15000);
}

/* GALERÍA — métricas eliminadas por diseño (solo título + descripción) */


/* ══════════════════════════════════════════
   GALERÍA — Cargar métricas reales con animación
══════════════════════════════════════════ */
(function () {

    function countUp(id, target, suffix, dur) {
        const el = document.getElementById(id);
        if (!el) return;
        // Limpiar y poner estructura correcta
        el.innerHTML = '<span class="dbg-num-val">0</span>' + (suffix ? `<span class="dbg-num-suf">${suffix}</span>` : '');
        const valEl = el.querySelector('.dbg-num-val');
        const t0 = performance.now();
        (function run(now) {
            const p = Math.min((now - t0) / dur, 1);
            const v = Math.round(target * (1 - Math.pow(1 - p, 3)));
            valEl.textContent = v.toLocaleString('es-CO');
            if (p < 1) requestAnimationFrame(run);
        })(performance.now());
    }

    async function dbg_load() {
        const token = localStorage.getItem('token') || '';
        const headers = token ? { Authorization: `Bearer ${token}` } : {};

        const [vR, cR, prR, plR] = await Promise.allSettled([
            fetch(`${API_URL}/ventas`, { headers }),
            fetch(`${API_URL}/compras`, { headers }),
            fetch(`${API_URL}/productos`, { headers }),
            fetch(`${API_URL}/productores?todos=true`, { headers }),
            fetch(`${API_URL}/comerciantes?todos=true`, { headers })
        ]);

        const vArr = vR.status === 'fulfilled' ? await vR.value.json() : [];
        const cArr = cR.status === 'fulfilled' ? await cR.value.json() : [];
        const prArr = prR.status === 'fulfilled' ? await prR.value.json() : [];
        const plRaw = plR.status === 'fulfilled' ? await plR.value.json() : [];
        const plArr = Array.isArray(plRaw) ? plRaw : (plRaw.data || []);

        const activos = plArr.filter(p => p.estado === 'ACTIVO').length;
        const pct = plArr.length ? Math.round(activos / plArr.length * 100) : 100;

        const vals = {
            ventas: [vArr.length, '', 1400],
            compras: [cArr.length, '', 1400],
            productos: [prArr.length, '', 1300],
            productores: [plArr.length, '', 1300],
            analisis: [pct, '%', 1600],
            reportes: [vArr.length + cArr.length, '', 1500],
        };

        // Animar los 2 ids de cada métrica (original + clon)
        Object.entries(vals).forEach(([metric, [val, suf, dur]]) => {
            countUp(`dbg_${metric}_1`, val, suf, dur);
            countUp(`dbg_${metric}_2`, val, suf, dur);
        });
    }

    const _orig = window.cargarDashboard;
    if (typeof _orig === 'function') {
        window.cargarDashboard = async function () {
            await _orig.apply(this, arguments);
            dbg_load();
        };
    } else {
        document.addEventListener('DOMContentLoaded', dbg_load);
    }
})();
/* =========================================
   CONTADOR EN VIVO DASHBOARD AGROTRACE
   Actualiza métricas automáticamente
========================================= */

async function actualizarMetricasDashboard() {

    try {

        const token = localStorage.getItem("token");

        const [comprasRes, ventasRes, productosRes, productoresRes] = await Promise.all([
            fetch(`${API_URL}/compras`, { headers: { Authorization: `Bearer ${token}` } }),
            fetch(`${API_URL}/ventas`, { headers: { Authorization: `Bearer ${token}` } }),
            fetch(`${API_URL}/productos`, { headers: { Authorization: `Bearer ${token}` } }),
            fetch(`${API_URL}/productores?todos=true`, { headers: { Authorization: `Bearer ${token}` } })
        ]);

        const compras = await comprasRes.json();
        const ventas = await ventasRes.json();
        const productos = await productosRes.json();
        const productores = await productoresRes.json();

        const cArr = Array.isArray(compras) ? compras : [];
        const vArr = Array.isArray(ventas) ? ventas : [];
        const pArr = Array.isArray(productos) ? productos : [];
        const plArr = Array.isArray(productores) ? productores : (productores.data || []);

        const metricas = {
            ventas: vArr.length,
            compras: cArr.length,
            productos: pArr.length,
            productores: plArr.length,
            reportes: vArr.length + cArr.length,
            analisis: 100
        };

        document.querySelectorAll(".dbg-num").forEach(el => {

            const tipo = el.dataset.metric;

            if (metricas[tipo] !== undefined) {

                const nuevoValor = metricas[tipo];
                animarNumero(el, nuevoValor);

            }

        });

    } catch (error) {
        console.error("Error actualizando métricas:", error);
    }

}


/* =========================================
   ANIMACIÓN DEL CONTADOR
========================================= */

function animarNumero(elemento, valorFinal) {

    const valorActual = parseInt(elemento.textContent) || 0;
    const incremento = Math.ceil((valorFinal - valorActual) / 20);

    let contador = valorActual;

    const intervalo = setInterval(() => {

        contador += incremento;

        if (
            (incremento > 0 && contador >= valorFinal) ||
            (incremento < 0 && contador <= valorFinal)
        ) {
            contador = valorFinal;
            clearInterval(intervalo);
        }

        elemento.textContent = contador;

    }, 30);

}


/* =========================================
   ACTUALIZACIÓN AUTOMÁTICA
========================================= */

actualizarMetricasDashboard();

/* refresca cada 5 segundos */
setInterval(actualizarMetricasDashboard, 5000);

// ════════════════════════════════════════════════════════
//  UTILIDAD GLOBAL — Exportar PDF (igual que historial)
// ════════════════════════════════════════════════════════
function _generarPDF(titulo, cabecera, filas, totalHTML) {
    const fecha = new Date().toLocaleDateString('es-CO', { dateStyle: 'long' });
    const html = `<!DOCTYPE html><html><head><meta charset="UTF-8"><title>${titulo}</title>
    <style>
        body{font-family:'Segoe UI',sans-serif;color:#111827;margin:40px}
        h1{font-size:1.4em;font-weight:900;color:#0aae0a;margin-bottom:4px}
        .sub{font-size:.85em;color:#6b7280;margin-bottom:24px}
        table{width:100%;border-collapse:collapse;font-size:.82em}
        th{background:#f0fdf4;color:#166534;padding:8px 10px;text-align:left;border-bottom:2px solid #dcfce7;font-weight:700}
        td{padding:7px 10px;border-bottom:1px solid #f3f4f6}
        tr:hover td{background:#fafafa}
        .total{text-align:right;margin-top:16px;font-size:1em;font-weight:800;color:#111827}
        .footer{margin-top:24px;font-size:.72em;color:#9ca3af;text-align:right}
        @media print{body{margin:20px}.footer{position:fixed;bottom:0;right:20px}}
    </style></head><body>
    <h1> AgroTrace — ${titulo}</h1>
    <div class="sub">Generado el ${fecha} · ${filas.length} registros</div>
    <table><thead>${cabecera}</thead><tbody>${filas.map(r => `<tr>${r.map(c => `<td>${c ?? '—'}</td>`).join('')}</tr>`).join('')}</tbody></table>
    ${totalHTML ? `<div class="total">${totalHTML}</div>` : ''}
    <div class="footer">AgroTrace · Sistema de Trazabilidad</div>
    <script>window.addEventListener('load',()=>{setTimeout(()=>window.print(),400)})<\/script>
    </body></html>`;
    const blob = new Blob([html], { type: 'text/html;charset=utf-8' });
    const url = URL.createObjectURL(blob);
    window.open(url, '_blank', 'width=900,height=700');
    setTimeout(() => URL.revokeObjectURL(url), 15000);
}

// ════════════════════════════════════════════════════════
//  UTILIDAD GLOBAL — Exportar Excel con SheetJS real
// ════════════════════════════════════════════════════════
function _generarExcel(nombreArchivo, nombreHoja, encabezados, filas) {
    // Cargar SheetJS dinámicamente si no está disponible
    function _doExport() {
        const XLSX = window.XLSX;
        const wsData = [encabezados, ...filas];
        const ws = XLSX.utils.aoa_to_sheet(wsData);
        // Ancho de columnas automático
        ws['!cols'] = encabezados.map((h, i) => ({
            wch: Math.max(h.length, ...filas.map(r => String(r[i] ?? '').length), 10)
        }));
        const wb = XLSX.utils.book_new();
        XLSX.utils.book_append_sheet(wb, ws, nombreHoja);
        XLSX.writeFile(wb, `${nombreArchivo}_${fechaHoyColombia()}.xlsx`);
    }
    if (window.XLSX) {
        _doExport();
    } else {
        const s = document.createElement('script');
        s.src = 'https://cdn.jsdelivr.net/npm/xlsx@0.18.5/dist/xlsx.full.min.js';
        s.onload = _doExport;
        document.head.appendChild(s);
    }
}

// ════════════════════════════════════════════════════════
//  CORRECCIÓN: his_exportarExcel usa SheetJS real
// ════════════════════════════════════════════════════════
function his_exportarExcel() {
    const datos = _his_tabActual === 'transacciones' ? _his_transacciones : _his_precios;
    if (!datos.length) { alert('No hay datos para exportar'); return; }
    const fmtF = d => d ? fmtFechaLocal(d) : '';
    const fmtM = n => n != null ? Number(n).toLocaleString('es-CO', { minimumFractionDigits: 2 }) : '';
    let encabezados, filas;
    if (_his_tabActual === 'transacciones') {
        encabezados = ['Número', 'Tipo', 'Fecha', 'Contraparte', 'Producto', 'Total ($)', 'Estado'];
        filas = datos.map(t => [
            t.numero || '',
            t._tipo || '',
            fmtF(t.fecha),
            t.contraparte || '',
            t.producto || '',
            fmtM(t.total),
            t.estado || '',
        ]);
    } else {
        encabezados = ['Producto', 'Precio Base/kg', 'Transporte', 'Costo/kg', 'Precio Productor/kg', 'Fecha', 'Estado'];
        filas = datos.map(p => [
            p.producto?.nombre || `Producto #${p.id_producto}`,
            fmtM(p.precio_base_kg),
            fmtM(p.precio_transporte),
            fmtM(p.costo_transporte_kg),
            fmtM(p.precio_final_kg),
            fmtF(p.fecha),
            p.activo ? 'Activo' : 'Inactivo',
        ]);
    }
    _generarExcel(`historial_${_his_tabActual}`, 'Historial', encabezados, filas);
}

// ════════════════════════════════════════════════════════
//  MÓDULO REPORTES
// ════════════════════════════════════════════════════════
let _rep_tab = 'entregas';
let _rep_data = { entregas: [], compras: [], ventas: [], desfase: [] };

function rep_setTab(tab, btn) {
    _rep_tab = tab;
    document.querySelectorAll('#reportes .an-tab').forEach(b => b.classList.remove('active'));
    if (btn) btn.classList.add('active');
    ['entregas', 'compras', 'ventas', 'desfase'].forEach(t => {
        const p = document.getElementById(`rep_panel_${t}`);
        if (p) p.classList.toggle('active', t === tab);
    });
    // Siempre cargar filtros al cambiar a entregas (en caso de primera vez)
    rep_cargarFiltros();
}

let _rep_filtros_cargados = false;

async function rep_cargarFiltros() {
    // Solo cargar una vez para no duplicar opciones
    if (_rep_filtros_cargados) return;
    const token = localStorage.getItem('token') || '';
    const h = token ? { Authorization: `Bearer ${token}` } : {};
    try {
        const [prdRes, proRes] = await Promise.all([
            fetch(`${API_URL}/productores?todos=true`, { headers: h }),
            fetch(`${API_URL}/productos`, { headers: h })
        ]);
        const productores = await prdRes.json();
        const productos = await proRes.json();
        const prdArr = Array.isArray(productores) ? productores : (productores.data || []);
        const proArr = Array.isArray(productos) ? productos : (productos.data || []);

        // Resetear antes de poblar para evitar duplicados
        const selPrd = document.getElementById('rep_ent_productor');
        if (selPrd) {
            selPrd.innerHTML = '<option value="">Todos los productores</option>';
            prdArr.forEach(p => {
                const nombre = p.usuario
                    ? `${p.usuario.nombre} ${p.usuario.apellido || ''}`.trim()
                    : (p.nombre || `#${p.id_productor}`);
                selPrd.innerHTML += `<option value="${p.id_productor}">${nombre}</option>`;
            });
        }
        const selPro = document.getElementById('rep_ent_producto');
        if (selPro) {
            selPro.innerHTML = '<option value="">Todos los productos</option>';
            proArr.forEach(p => {
                selPro.innerHTML += `<option value="${p.id_producto}">${p.nombre}</option>`;
            });
        }
        _rep_filtros_cargados = true;
    } catch (e) { console.warn('rep_cargarFiltros:', e.message); }
}

async function rep_cargarEntregas() {
    const token = localStorage.getItem('token') || '';
    const inicio = document.getElementById('rep_ent_inicio').value;
    const fin = document.getElementById('rep_ent_fin').value;
    const idPrd = document.getElementById('rep_ent_productor').value;
    const idPro = document.getElementById('rep_ent_producto').value;
    let qs = [];
    if (inicio) qs.push(`inicio=${inicio}`);
    if (fin) qs.push(`fin=${fin}`);
    if (idPrd) qs.push(`id_productor=${idPrd}`);

    const tbody = document.getElementById('rep_ent_tbody');
    const countEl = document.getElementById('rep_ent_count');
    tbody.innerHTML = `<tr><td colspan="6" class="empty-state">Cargando...</td></tr>`;
    showLoading();
    try {
        const res = await fetch(`${API_URL}/compras${qs.length ? '?' + qs.join('&') : ''}`, { headers: { Authorization: `Bearer ${token}` } });
        const json = await res.json();
        let compras = Array.isArray(json) ? json : (json.data || []);

        // Filtrar por fecha en cliente (por si el backend no lo soporta)
        if (inicio || fin) {
            compras = compras.filter(c => {
                const f = c.fecha_compra || c.fecha;
                if (!f) return false;
                const fd = new Date(parseFechaLocal(f)); fd.setHours(0, 0, 0, 0);
                if (inicio) { const d = new Date(parseFechaLocal(inicio)); d.setHours(0, 0, 0, 0); if (fd < d) return false; }
                if (fin) { const h = new Date(parseFechaLocal(fin)); h.setHours(23, 59, 59, 999); if (fd > h) return false; }
                return true;
            });
        }

        // Filtrar por productor en cliente (doble seguridad si el backend no filtra)
        if (idPrd) {
            compras = compras.filter(c => {
                if (String(c.id_productor) === String(idPrd)) return true;
                if (String(c.productor?.id_productor) === String(idPrd)) return true;
                return false;
            });
        }

        // Desplegar por detalle (cada línea = 1 producto de la compra)
        let rows = [];
        compras.forEach(c => {
            const productor = c.productor?.usuario
                ? `${c.productor.usuario.nombre} ${c.productor.usuario.apellido || ''}`.trim()
                : (c.productor?.nombre || c.nombre_productor_externo || '—');
            const fecha = c.fecha_compra ? fmtFechaLocal(c.fecha_compra) : '—';
            const detalles = c.detalles || [];
            if (!detalles.length) {
                if (!idPro) rows.push({ productor, producto: '—', peso: '—', precio: '—', total: c.total || 0, fecha });
            } else {
                detalles.forEach(det => {
                    // Filtrar por producto: comparar id Y nombre (case-insensitive)
                    if (idPro) {
                        const idOk = String(det.producto?.id_producto) === String(idPro);
                        if (!idOk) return;
                    }
                    rows.push({
                        productor,
                        producto: det.producto?.nombre || '—',
                        peso: parseFloat(det.cantidad || det.peso_kg || 0),
                        precio: parseFloat(det.precio_unitario || 0),
                        total: parseFloat(det.subtotal || (det.cantidad * det.precio_unitario) || 0),
                        fecha
                    });
                });
            }
        });

        _rep_data.entregas = rows;
        countEl.textContent = `${rows.length} registro${rows.length !== 1 ? 's' : ''}`;
        const fmt = n => n != null ? `$${Number(n).toLocaleString('es-CO')}` : '—';
        if (!rows.length) {
            tbody.innerHTML = `<tr><td colspan="6" class="empty-state">No hay datos para los filtros seleccionados</td></tr>`;
            document.getElementById('rep_ent_total').textContent = '';
        } else {
            tbody.innerHTML = rows.map(r => `<tr>
                <td>${r.productor}</td><td>${r.producto}</td>
                <td>${r.peso} kg</td><td>${fmt(r.precio)}</td>
                <td style="font-weight:700">${fmt(r.total)}</td><td>${r.fecha}</td>
            </tr>`).join('');
            const totalGen = rows.reduce((s, r) => s + parseFloat(r.total || 0), 0);
            document.getElementById('rep_ent_total').textContent = `Total general: ${fmt(totalGen)}`;
        }
    } catch (e) {
        tbody.innerHTML = `<tr><td colspan="6" class="empty-state" style="color:#ef4444">${e.message}</td></tr>`;
    } finally { hideLoading(); }
}

async function rep_cargarCompras() {
    const token = localStorage.getItem('token') || '';
    const inicio = document.getElementById('rep_cmp_inicio').value;
    const fin = document.getElementById('rep_cmp_fin').value;
    let qs = [];
    if (inicio) qs.push(`inicio=${inicio}`);
    if (fin) qs.push(`fin=${fin}`);

    const tbody = document.getElementById('rep_cmp_tbody');
    tbody.innerHTML = `<tr><td colspan="3" class="empty-state">Cargando...</td></tr>`;
    showLoading();
    try {
        const res = await fetch(`${API_URL}/compras${qs.length ? '?' + qs.join('&') : ''}`, { headers: { Authorization: `Bearer ${token}` } });
        const json = await res.json();
        let compras = Array.isArray(json) ? json : (json.data || []);

        // Filtrar por fecha en cliente
        if (inicio || fin) {
            compras = compras.filter(c => {
                const f = c.fecha_compra || c.fecha;
                if (!f) return false;
                const fd = new Date(parseFechaLocal(f)); fd.setHours(0, 0, 0, 0);
                if (inicio) { const d = new Date(parseFechaLocal(inicio)); d.setHours(0, 0, 0, 0); if (fd < d) return false; }
                if (fin) { const h = new Date(parseFechaLocal(fin)); h.setHours(23, 59, 59, 999); if (fd > h) return false; }
                return true;
            });
        }

        // Agrupar por producto
        const mapa = {};
        compras.forEach(c => {
            (c.detalles || []).forEach(det => {
                const key = det.producto?.nombre || 'Sin nombre';
                if (!mapa[key]) mapa[key] = { producto: key, kg: 0, total: 0 };
                mapa[key].kg += parseFloat(det.cantidad || 0);
                mapa[key].total += parseFloat(det.subtotal || det.cantidad * det.precio_unitario || 0);
            });
        });
        const rows = Object.values(mapa);
        _rep_data.compras = rows;
        document.getElementById('rep_cmp_count').textContent = `${rows.length} producto${rows.length !== 1 ? 's' : ''}`;
        const fmt = n => `$${Number(n).toLocaleString('es-CO')}`;
        if (!rows.length) {
            tbody.innerHTML = `<tr><td colspan="3" class="empty-state">No hay datos para los filtros seleccionados</td></tr>`;
        } else {
            tbody.innerHTML = rows.map(r => `<tr>
                <td>${r.producto}</td>
                <td>${Number(r.kg).toLocaleString('es-CO')} kg</td>
                <td style="font-weight:700">${fmt(r.total)}</td>
            </tr>`).join('');
            const totalGen = rows.reduce((s, r) => s + r.total, 0);
            document.getElementById('rep_cmp_total').textContent = `Total general: ${fmt(totalGen)}`;
        }
    } catch (e) {
        tbody.innerHTML = `<tr><td colspan="3" class="empty-state" style="color:#ef4444">${e.message}</td></tr>`;
    } finally { hideLoading(); }
}

async function rep_cargarVentas() {
    const token = localStorage.getItem('token') || '';
    const inicio = document.getElementById('rep_vnt_inicio').value;
    const fin = document.getElementById('rep_vnt_fin').value;
    let qs = [];
    if (inicio) qs.push(`inicio=${inicio}`);
    if (fin) qs.push(`fin=${fin}`);

    const tbody = document.getElementById('rep_vnt_tbody');
    tbody.innerHTML = `<tr><td colspan="5" class="empty-state">Cargando...</td></tr>`;
    showLoading();
    try {
        const res = await fetch(`${API_URL}/ventas${qs.length ? '?' + qs.join('&') : ''}`, { headers: { Authorization: `Bearer ${token}` } });
        const json = await res.json();
        let ventas = Array.isArray(json) ? json : (json.data || []);

        // Filtrar por fecha en cliente
        if (inicio || fin) {
            ventas = ventas.filter(v => {
                const f = v.fecha_venta || v.fecha;
                if (!f) return false;
                const fd = new Date(parseFechaLocal(f)); fd.setHours(0, 0, 0, 0);
                if (inicio) { const d = new Date(parseFechaLocal(inicio)); d.setHours(0, 0, 0, 0); if (fd < d) return false; }
                if (fin) { const h = new Date(parseFechaLocal(fin)); h.setHours(23, 59, 59, 999); if (fd > h) return false; }
                return true;
            });
        }

        let rows = [];
        ventas.forEach(v => {
            const comerciante = v.comerciante?.nombre || v.cliente || '—';
            const fecha = v.fecha_venta ? fmtFechaLocal(v.fecha_venta) : '—';
            (v.detalles || []).forEach(det => {
                rows.push({
                    comerciante,
                    producto: det.producto?.nombre || '—',
                    cantidad: det.cantidad,
                    total: det.subtotal || det.cantidad * det.precio_unitario,
                    fecha
                });
            });
            if (!(v.detalles || []).length) {
                rows.push({ comerciante, producto: '—', cantidad: '—', total: v.total || 0, fecha });
            }
        });
        _rep_data.ventas = rows;
        document.getElementById('rep_vnt_count').textContent = `${rows.length} registro${rows.length !== 1 ? 's' : ''}`;
        const fmt = n => n != null ? `$${Number(n).toLocaleString('es-CO')}` : '—';
        if (!rows.length) {
            tbody.innerHTML = `<tr><td colspan="5" class="empty-state">No hay datos para los filtros seleccionados</td></tr>`;
        } else {
            tbody.innerHTML = rows.map(r => `<tr>
                <td>${r.comerciante}</td><td>${r.producto}</td>
                <td>${r.cantidad}</td><td style="font-weight:700">${fmt(r.total)}</td><td>${r.fecha}</td>
            </tr>`).join('');
            const totalGen = rows.reduce((s, r) => s + parseFloat(r.total || 0), 0);
            document.getElementById('rep_vnt_total').textContent = `Total general: ${fmt(totalGen)}`;
        }
    } catch (e) {
        tbody.innerHTML = `<tr><td colspan="5" class="empty-state" style="color:#ef4444">${e.message}</td></tr>`;
    } finally { hideLoading(); }
}

async function rep_cargarDesfase() {
    const token = localStorage.getItem('token') || '';
    const inicio = document.getElementById('rep_des_inicio').value;
    const fin = document.getElementById('rep_des_fin').value;
    let qs = [];
    if (inicio) qs.push(`inicio=${inicio}`);
    if (fin) qs.push(`fin=${fin}`);
    const qStr = qs.length ? '?' + qs.join('&') : '';

    const tbody = document.getElementById('rep_des_tbody');
    tbody.innerHTML = `<tr><td colspan="4" class="empty-state">Cargando...</td></tr>`;
    showLoading();
    try {
        const [cRes, vRes] = await Promise.all([
            fetch(`${API_URL}/compras${qStr}`, { headers: { Authorization: `Bearer ${token}` } }),
            fetch(`${API_URL}/ventas${qStr}`, { headers: { Authorization: `Bearer ${token}` } })
        ]);
        const compras = await cRes.json();
        const ventas = await vRes.json();
        let cArr = Array.isArray(compras) ? compras : (compras.data || []);
        let vArr = Array.isArray(ventas) ? ventas : (ventas.data || []);

        // Filtrar por fecha en cliente
        const filtrarPorFecha = (arr, campo) => {
            if (!inicio && !fin) return arr;
            return arr.filter(x => {
                const f = x[campo] || x.fecha;
                if (!f) return false;
                const fd = new Date(parseFechaLocal(f)); fd.setHours(0, 0, 0, 0);
                if (inicio) { const d = new Date(parseFechaLocal(inicio)); d.setHours(0, 0, 0, 0); if (fd < d) return false; }
                if (fin) { const h = new Date(parseFechaLocal(fin)); h.setHours(23, 59, 59, 999); if (fd > h) return false; }
                return true;
            });
        };
        cArr = filtrarPorFecha(cArr, 'fecha_compra');
        vArr = filtrarPorFecha(vArr, 'fecha_venta');

        const mapaC = {}, mapaV = {};
        cArr.forEach(c => (c.detalles || []).forEach(det => {
            const k = det.producto?.nombre || 'Sin nombre';
            mapaC[k] = (mapaC[k] || 0) + parseFloat(det.cantidad || 0);
        }));
        vArr.forEach(v => (v.detalles || []).forEach(det => {
            const k = det.producto?.nombre || 'Sin nombre';
            mapaV[k] = (mapaV[k] || 0) + parseFloat(det.cantidad || 0);
        }));

        const productos = [...new Set([...Object.keys(mapaC), ...Object.keys(mapaV)])];
        const rows = productos.map(p => ({
            producto: p,
            comprado: mapaC[p] || 0,
            vendido: mapaV[p] || 0,
            diferencia: (mapaC[p] || 0) - (mapaV[p] || 0)
        }));
        _rep_data.desfase = rows;
        document.getElementById('rep_des_count').textContent = `${rows.length} producto${rows.length !== 1 ? 's' : ''}`;
        const fmtN = n => `${Number(n).toLocaleString('es-CO')} kg`;
        if (!rows.length) {
            tbody.innerHTML = `<tr><td colspan="4" class="empty-state">No hay datos para los filtros seleccionados</td></tr>`;
        } else {
            tbody.innerHTML = rows.map(r => {
                const color = r.diferencia < 0 ? '#dc2626' : r.diferencia === 0 ? '#6b7280' : '#16a34a';
                return `<tr>
                    <td>${r.producto}</td>
                    <td>${fmtN(r.comprado)}</td>
                    <td>${fmtN(r.vendido)}</td>
                    <td style="font-weight:700;color:${color}">${r.diferencia >= 0 ? '+' : ''}${fmtN(r.diferencia)}</td>
                </tr>`;
            }).join('');
        }
    } catch (e) {
        tbody.innerHTML = `<tr><td colspan="4" class="empty-state" style="color:#ef4444">${e.message}</td></tr>`;
    } finally { hideLoading(); }
}

// ── Exportar reportes ──────────────────────────────────
function rep_exportarPDF(tab) {
    const data = _rep_data[tab];
    if (!data || !data.length) { alert('Primero genera el reporte'); return; }
    const cfgs = {
        entregas: {
            titulo: 'Reporte de Entregas por Productor',
            cab: '<tr><th>Productor</th><th>Producto</th><th>Peso (kg)</th><th>Precio/kg</th><th>Total</th><th>Fecha</th></tr>',
            fila: r => [r.productor, r.producto, r.peso + ' kg', r.precio != null ? '$' + Number(r.precio).toLocaleString('es-CO') : '—', r.total != null ? '$' + Number(r.total).toLocaleString('es-CO') : '—', r.fecha],
            total: () => { const t = data.reduce((s, r) => s + parseFloat(r.total || 0), 0); return `Total general: $${t.toLocaleString('es-CO')}`; }
        },
        compras: {
            titulo: 'Reporte de Compras',
            cab: '<tr><th>Producto</th><th>Total comprado (kg)</th><th>Total pagado</th></tr>',
            fila: r => [r.producto, Number(r.kg).toLocaleString('es-CO') + ' kg', '$' + Number(r.total).toLocaleString('es-CO')],
            total: () => { const t = data.reduce((s, r) => s + r.total, 0); return `Total general: $${t.toLocaleString('es-CO')}`; }
        },
        ventas: {
            titulo: 'Reporte de Ventas',
            cab: '<tr><th>Comerciante</th><th>Producto</th><th>Cantidad</th><th>Total vendido</th><th>Fecha</th></tr>',
            fila: r => [r.comerciante, r.producto, r.cantidad, r.total != null ? '$' + Number(r.total).toLocaleString('es-CO') : '—', r.fecha],
            total: () => { const t = data.reduce((s, r) => s + parseFloat(r.total || 0), 0); return `Total general: $${t.toLocaleString('es-CO')}`; }
        },
        desfase: {
            titulo: 'Comparación Compras vs Ventas',
            cab: '<tr><th>Producto</th><th>Total comprado (kg)</th><th>Total vendido (kg)</th><th>Diferencia</th></tr>',
            fila: r => [r.producto, Number(r.comprado).toLocaleString('es-CO') + ' kg', Number(r.vendido).toLocaleString('es-CO') + ' kg', (r.diferencia >= 0 ? '+' : '') + Number(r.diferencia).toLocaleString('es-CO') + ' kg'],
            total: null
        }
    };
    const cfg = cfgs[tab];
    _generarPDF(cfg.titulo, cfg.cab, data.map(cfg.fila), cfg.total ? cfg.total() : '');
}

function rep_exportarExcel(tab) {
    const data = _rep_data[tab];
    if (!data || !data.length) { alert('Primero genera el reporte'); return; }
    const cfgs = {
        entregas: {
            nombre: 'reporte_entregas', hoja: 'Entregas',
            cols: ['Productor', 'Producto', 'Peso (kg)', 'Precio/kg', 'Total', 'Fecha'],
            fila: r => [r.productor, r.producto, r.peso, r.precio, r.total, r.fecha]
        },
        compras: {
            nombre: 'reporte_compras', hoja: 'Compras',
            cols: ['Producto', 'Total comprado (kg)', 'Total pagado'],
            fila: r => [r.producto, r.kg, r.total]
        },
        ventas: {
            nombre: 'reporte_ventas', hoja: 'Ventas',
            cols: ['Comerciante', 'Producto', 'Cantidad', 'Total vendido', 'Fecha'],
            fila: r => [r.comerciante, r.producto, r.cantidad, r.total, r.fecha]
        },
        desfase: {
            nombre: 'reporte_desfase', hoja: 'Compras vs Ventas',
            cols: ['Producto', 'Total comprado (kg)', 'Total vendido (kg)', 'Diferencia'],
            fila: r => [r.producto, r.comprado, r.vendido, r.diferencia]
        }
    };
    const cfg = cfgs[tab];
    _generarExcel(cfg.nombre, cfg.hoja, cfg.cols, data.map(cfg.fila));
}

// Cargar filtros automáticamente al entrar a reportes
const _origMostrarSeccion = window.mostrarSeccion || mostrarSeccion;

// ════════════════════════════════════════════════════════
//  PDF EN DETALLE DE COMPRA / VENTA
// ════════════════════════════════════════════════════════
let _det_tipo_actual = '';
let _det_data_actual = null;

// Parche a det_abrir para guardar los datos globalmente
const _orig_det_abrir = det_abrir;
window.det_abrir = async function (tipo, id) {
    _det_tipo_actual = tipo;
    _det_data_actual = null;
    await _orig_det_abrir(tipo, id);
    // Recuperar datos desde el DOM después de que cargó
};

function det_descargarPDF() {
    const titulo = document.getElementById('det_titulo').textContent;
    const subtitulo = document.getElementById('det_subtitulo').textContent;
    const total = document.getElementById('det_total').textContent;
    // Leer info
    const infoItems = document.querySelectorAll('#det_info .det-info-item');
    let infoHTML = '<table style="width:100%;margin-bottom:20px;font-size:.85em"><tbody>';
    infoItems.forEach(item => {
        const label = item.querySelector('.det-info-label')?.textContent || '';
        const value = item.querySelector('.det-info-value')?.textContent || '';
        infoHTML += `<tr><td style="font-weight:700;padding:4px 8px;color:#374151;width:40%">${label}</td><td style="padding:4px 8px">${value}</td></tr>`;
    });
    infoHTML += '</tbody></table>';
    // Leer tabla de productos
    const thEls = document.querySelectorAll('#det_modal table thead th');
    const ths = Array.from(thEls).map(th => th.textContent.trim()).filter(Boolean);
    const rows = Array.from(document.querySelectorAll('#det_tbody tr')).map(tr =>
        Array.from(tr.querySelectorAll('td')).map(td => td.textContent.trim())
    );
    const cabecera = `<tr>${ths.map(h => `<th>${h}</th>`).join('')}</tr>`;
    const fecha = new Date().toLocaleDateString('es-CO', { dateStyle: 'long' });
    const html = `<!DOCTYPE html><html><head><meta charset="UTF-8"><title>${titulo}</title>
    <style>
        body{font-family:'Segoe UI',sans-serif;color:#111827;margin:40px}
        h1{font-size:1.4em;font-weight:900;color:#0aae0a;margin-bottom:2px}
        .sub{font-size:.85em;color:#6b7280;margin-bottom:16px}
        table{width:100%;border-collapse:collapse;font-size:.82em}
        th{background:#f0fdf4;color:#166534;padding:8px 10px;text-align:left;border-bottom:2px solid #dcfce7;font-weight:700}
        td{padding:7px 10px;border-bottom:1px solid #f3f4f6}
        .total-row{text-align:right;margin-top:14px;font-size:1.05em;font-weight:800}
        .footer{margin-top:24px;font-size:.72em;color:#9ca3af;text-align:right}
        @media print{body{margin:20px}.footer{position:fixed;bottom:0;right:20px}}
    </style></head><body>
    <h1> AgroTrace — ${titulo}</h1>
    <div class="sub">${subtitulo} · Generado el ${fecha}</div>
    ${infoHTML}
    <table><thead>${cabecera}</thead><tbody>
    ${rows.map(r => `<tr>${r.map(c => `<td>${c}</td>`).join('')}</tr>`).join('')}
    </tbody></table>
    <div class="total-row">Total: <span style="color:#0aae0a">${total}</span></div>
    <div class="footer">AgroTrace · Sistema de Trazabilidad</div>
    <script>window.addEventListener('load',()=>{setTimeout(()=>window.print(),400)})<\/script>
    </body></html>`;
    const blob = new Blob([html], { type: 'text/html;charset=utf-8' });
    const url = URL.createObjectURL(blob);
    window.open(url, '_blank', 'width=900,height=700');
    setTimeout(() => URL.revokeObjectURL(url), 15000);
}

// ════════════════════════════════════════════════════════
//  RANKING — con nombres reales, total pagado, fechas
// ════════════════════════════════════════════════════════
let _ranking_data = [];

// analisis_loadRanking ya está definida arriba con la lógica correcta.
// Este bloque solo agrega las funciones de exportación PDF/Excel.

function ranking_exportarPDF() {
    if (!_ranking_data.length) { alert('Primero genera el ranking'); return; }
    const tipo = document.getElementById('ar_tipo').value;
    const inicio = document.getElementById('ar_inicio')?.value || '';
    const fin = document.getElementById('ar_fin')?.value || '';
    const labels = { total: 'Total kg entregados', promedio: 'Promedio kg/entrega', frecuencia: 'Nº entregas' };
    const titulo = `Ranking de Productores — ${labels[tipo] || tipo}`;
    const periodo = (inicio || fin) ? ` · Período: ${inicio || 'inicio'} → ${fin || 'hoy'}` : '';
    const cab = '<tr><th>#</th><th>Productor</th><th>Cédula</th><th>Valor</th><th>Total pagado</th></tr>';
    const filas = _ranking_data.map(r => {
        const nombre = (r.nombre && r.nombre.trim()) ? r.nombre.trim() : `Productor ${r.id_productor}`;
        const valFmt = tipo === 'frecuencia'
            ? `${r.valor} entregas`
            : `${parseFloat(r.valor).toFixed(1)} kg`;
        return [r.posicion, nombre, r.cedula || '—', valFmt, r.total_pagado ? formatCurrency(r.total_pagado) : '—'];
    });
    _generarPDF(titulo + periodo, cab, filas, '');
}

function ranking_exportarExcel() {
    if (!_ranking_data.length) { alert('Primero genera el ranking'); return; }
    const tipo = document.getElementById('ar_tipo').value;
    const labels = { total: 'Total kg', promedio: 'Promedio kg', frecuencia: 'Nº entregas' };
    const cols = ['Posición', 'Productor', 'Cédula', 'Finca', labels[tipo] || tipo, 'Total pagado ($)'];
    const filas = _ranking_data.map(r => [
        r.posicion,
        (r.nombre && r.nombre.trim()) ? r.nombre.trim() : `Productor ${r.id_productor}`,
        r.cedula || '',
        r.finca || '',
        parseFloat(r.valor),
        parseFloat(r.total_pagado || 0),
    ]);
    _generarExcel(`ranking_${tipo}`, 'Ranking', cols, filas);
}

// ════════════════════════════════════════════════════════
//  ACTIVIDADES RECIENTES EN DASHBOARD
// ════════════════════════════════════════════════════════
async function db_cargarActividades() {
    const token = localStorage.getItem('token') || '';
    const h = token ? { Authorization: `Bearer ${token}` } : {};
    const tbody = document.getElementById('db_actividades_tbody');
    if (!tbody) return;
    tbody.innerHTML = '<tr><td colspan="4" class="empty-state">Cargando...</td></tr>';
    try {
        const [cRes, vRes, prdRes, prRes] = await Promise.allSettled([
            fetch(`${API_URL}/compras`, { headers: h }),
            fetch(`${API_URL}/ventas`, { headers: h }),
            fetch(`${API_URL}/productores?todos=true`, { headers: h }),
            fetch(`${API_URL}/productos`, { headers: h }),
        ]);
        const compras = cRes.status === 'fulfilled' ? await cRes.value.json() : [];
        const ventas = vRes.status === 'fulfilled' ? await vRes.value.json() : [];
        const productores = prdRes.status === 'fulfilled' ? await prdRes.value.json() : [];
        const productos = prRes.status === 'fulfilled' ? await prRes.value.json() : [];

        const cArr = (Array.isArray(compras) ? compras : compras.data || []).slice(0, 10);
        const vArr = (Array.isArray(ventas) ? ventas : ventas.data || []).slice(0, 10);
        const prdArr = (Array.isArray(productores) ? productores : productores.data || []).slice(0, 5);
        const proArr = (Array.isArray(productos) ? productos : productos.data || []).slice(0, 5);

        let actividades = [];

        cArr.forEach(c => {
            // Productor externo o afiliado
            const esExterno = c.tipo_productor === 'EXTERNO' || (!c.id_productor && c.nombre_productor_externo);
            const productor = esExterno
                ? `${c.nombre_productor_externo || 'Externo'} <span style="background:#fef3c7;color:#b45309;padding:1px 6px;border-radius:20px;font-size:.75em;font-weight:700">(externo)</span>`
                : c.productor?.usuario
                    ? `${c.productor.usuario.nombre} ${c.productor.usuario.apellido || ''}`.trim()
                    : (c.productor?.nombre || '—');
            actividades.push({
                fecha: c.fecha_compra || c.createdAt,
                tipo: 'Compra',
                color: '#16a34a',
                usuario: productor,
                desc: `Compra #${c.numero_factura || c.id_compra} · $${Number(c.total || 0).toLocaleString('es-CO')}`
            });
        });
        vArr.forEach(v => actividades.push({
            fecha: v.fecha_venta || v.createdAt,
            tipo: 'Venta',
            color: '#2563eb',
            usuario: v.cliente || '—',
            desc: `Venta #${v.numero_factura || v.id_venta} · $${Number(v.total || 0).toLocaleString('es-CO')}`
        }));
        prdArr.forEach(p => {
            const nombre = p.usuario ? `${p.usuario.nombre} ${p.usuario.apellido || ''}`.trim() : (p.nombre || '—');
            actividades.push({
                fecha: p.createdAt,
                tipo: 'Productor',
                color: '#9333ea',
                usuario: 'Admin',
                desc: `Productor registrado: ${nombre}`
            });
        });
        proArr.forEach(p => actividades.push({
            fecha: p.createdAt,
            tipo: 'Producto',
            color: '#d97706',
            usuario: 'Admin',
            desc: `Producto: ${p.nombre} · $${Number(p.precio_dia || p.precio_base || 0).toLocaleString('es-CO')}/kg`
        }));

        // Ordenar por fecha desc, tomar 20
        actividades = actividades
            .filter(a => a.fecha)
            .sort((a, b) => new Date(b.fecha) - new Date(a.fecha))
            .slice(0, 20);

        if (!actividades.length) {
            tbody.innerHTML = '<tr><td colspan="4" class="empty-state">No hay actividades recientes</td></tr>';
            return;
        }
        tbody.innerHTML = actividades.map(a => {
            const fechaStr = fmtFechaLocal(a.fecha);
            return `<tr>
                <td style="white-space:nowrap;font-size:.82em;color:#6b7280">${fechaStr}</td>
                <td><span style="background:${a.color}18;color:${a.color};padding:2px 8px;border-radius:20px;font-size:.78em;font-weight:700">${a.tipo}</span></td>
                <td style="font-size:.85em">${a.usuario}</td>
                <td style="font-size:.85em;color:#374151">${a.desc}</td>
            </tr>`;
        }).join('');
    } catch (e) {
        tbody.innerHTML = `<tr><td colspan="4" class="empty-state" style="color:#ef4444">${e.message}</td></tr>`;
    }
}

// Cargar actividades cuando se muestra el dashboard
(function () {
    const _origMS = mostrarSeccion;
    window.mostrarSeccion = function (sectionId) {
        _origMS(sectionId);
        if (sectionId === 'dashboard') db_cargarActividades();
        if (sectionId === 'reportes') rep_cargarFiltros();
    };
    // También carga al inicio
    window.addEventListener('DOMContentLoaded', () => {
        setTimeout(db_cargarActividades, 1500);
    });
})();
// =============================
// COMERCIANTES
// =============================

let _com_todos = [];
let _com_filtrados = [];
let _com_editando = null;


// CARGAR COMERCIANTES
async function com_cargar() {

    const token = localStorage.getItem("token");

    try {

        const res = await fetch(`${API_URL}/comerciantes`, {
            headers: {
                Authorization: `Bearer ${token}`
            }
        });

        if (!res.ok) throw new Error("Error cargando comerciantes");

        _com_todos = await res.json();
        _com_filtrados = [..._com_todos];

        document.getElementById("com_count").innerText =
            `${_com_filtrados.length} registros`;

        com_render();


    } catch (e) {

        alert(e.message);

    }

}



// RENDER TABLA
function com_render() {

    const tbody = document.getElementById("com_tbody");

    if (!_com_filtrados.length) {

        tbody.innerHTML =
            `<tr>
            <td colspan="6" class="empty-state">
            No hay comerciantes
            </td>
        </tr>`;

        return;
    }

    tbody.innerHTML = _com_filtrados.map(c => `

        <tr>

        <td>${c.id_comerciante}</td>

        <td>${c.nombre}</td>

        <td>${c.telefono}</td>

        <td>${c.direccion || '—'}</td>

        <td>
            ${c.email
            ? `<a href="mailto:${c.email}" style="color:#2563eb;font-size:.85em">${c.email}</a>`
            : '<span style="color:#d1d5db;font-size:.82em">Sin correo</span>'}
        </td>

        <td>
            ${c.activo
            ? '<span class="badge-success">Activo</span>'
            : '<span class="badge-danger">Inactivo</span>'}
        </td>

        <td>

            <button class="usr-btn-action"
            onclick="com_editar(${c.id_comerciante})"
            title="Editar">

            <i class="fi fi-rr-edit"></i>
            </button>

            <button class="usr-btn-action usr-btn-del"
            onclick="com_desactivar(${c.id_comerciante})"
            title="Desactivar">

            <i class="fi fi-rr-trash"></i>
            </button>

        </td>

        </tr>

    `).join('');

}



// BUSCAR
function com_filtrar(texto) {

    texto = texto.toLowerCase();

    _com_filtrados = _com_todos.filter(c =>

        c.nombre.toLowerCase().includes(texto) ||
        c.telefono.includes(texto)

    );

    document.getElementById("com_count").innerText =
        `${_com_filtrados.length} registros`;

    com_render();

}



// ABRIR FORMULARIO
function com_abrirPanel() {

    _com_editando = null;

    document.getElementById("com_nombre").value = "";
    document.getElementById("com_telefono").value = "";
    document.getElementById("com_direccion").value = "";
    document.getElementById("com_email").value = "";

    document.getElementById("com_panel").classList.add("open");

}



// EDITAR
function com_editar(id) {

    const c = _com_todos.find(x => x.id_comerciante === id);

    if (!c) return;

    _com_editando = id;

    document.getElementById("com_nombre").value = c.nombre;
    document.getElementById("com_telefono").value = c.telefono;
    document.getElementById("com_direccion").value = c.direccion || "";
    document.getElementById("com_email").value = c.email || "";

    document.getElementById("com_panel").classList.add("open");

}



// GUARDAR
async function com_guardar() {

    const nombre = document.getElementById("com_nombre").value.trim();
    const telefono = document.getElementById("com_telefono").value.trim();
    const direccion = document.getElementById("com_direccion").value.trim();

    if (!nombre || !telefono) {

        alert("Nombre y teléfono son obligatorios");
        return;

    }

    const token = localStorage.getItem("token");

    const email = document.getElementById("com_email")?.value.trim() || "";
    const data = {
        nombre,
        telefono,
        direccion,
        email,
    };

    try {

        let res;

        if (_com_editando) {

            res = await fetch(`${API_URL}/comerciantes/${_com_editando}`, {

                method: "PUT",

                headers: {
                    "Content-Type": "application/json",
                    Authorization: `Bearer ${token}`
                },

                body: JSON.stringify(data)

            });

        } else {

            res = await fetch(`${API_URL}/comerciantes`, {

                method: "POST",

                headers: {
                    "Content-Type": "application/json",
                    Authorization: `Bearer ${token}`
                },

                body: JSON.stringify(data)

            });

        }

        if (!res.ok) {

            const err = await res.json();
            throw new Error(err.message || "Error guardando");

        }

        document.getElementById("com_panel").classList.remove("open");

        com_cargar();

    } catch (e) {

        alert(e.message);

    }

}



// DESACTIVAR
async function com_desactivar(id) {

    if (!confirm("¿Desactivar comerciante?")) return;

    const token = localStorage.getItem("token");

    try {

        const res = await fetch(`${API_URL}/comerciantes/${id}`, {

            method: "PATCH",

            headers: {
                "Content-Type": "application/json",
                Authorization: `Bearer ${token}`
            },

            body: JSON.stringify({ activo: false })

        });

        if (!res.ok) {

            const err = await res.json();
            throw new Error(err.message);

        }

        com_cargar();

    } catch (e) {

        alert(e.message);

    }

}



function com_abrirPanel() {

    document
        .getElementById("com_panel")
        .classList.add("open");

    document
        .getElementById("com_overlay")
        .classList.add("show");

}

function com_cerrarPanel() {

    document
        .getElementById("com_panel")
        .classList.remove("open");

    document
        .getElementById("com_overlay")
        .classList.remove("show");

}


// ============================================================
// MÓDULO PRECIOS — AgroTrace Admin
// ============================================================

// ── Estado del módulo ────────────────────────────────────────
let _prc_lista = [];   // historial completo
let _prc_buscar = '';   // texto búsqueda tabla

// ── Alerta semanal (solo miércoles) ─────────────────────────
async function prc_verificarAlertaSemanal() {
    if (new Date().getDay() !== 4) return;    // 3 = miércoles
    try {
        const token = localStorage.getItem('token') || sessionStorage.getItem('token') || '';
        const res = await fetch(`${API_URL}/precios/semana`, {
            headers: { Authorization: `Bearer ${token}` }
        });
        if (!res.ok) return;
        const { hay_precio } = await res.json();
        if (!hay_precio) prc_mostrarAlerta();
    } catch (e) {
        console.warn('[PRECIOS] verificarAlertaSemanal:', e.message);
    }
}

function prc_mostrarAlerta() {
    const m = document.getElementById('prc_modal_alerta');
    if (m) m.classList.add('show');
}

function prc_cerrarAlerta(irASeccion) {
    const m = document.getElementById('prc_modal_alerta');
    if (m) m.classList.remove('show');
    if (irASeccion) mostrarSeccion('precios');
}

// ── Cargar sección ───────────────────────────────────────────
async function prc_cargar() {
    await Promise.all([prc_cargarSelectProductos(), prc_cargarHistorial()]);
}

async function prc_cargarSelectProductos() {
    try {
        const token = localStorage.getItem('token') || sessionStorage.getItem('token') || '';
        const res = await fetch(`${API_URL}/productos`, {
            headers: { Authorization: `Bearer ${token}` }
        });
        const lista = await res.json();
        const sel = document.getElementById('prc_sel_producto');
        if (!sel) return;
        sel.innerHTML = '<option value="">-- Seleccionar --</option>';
        (Array.isArray(lista) ? lista : [])
            .filter(p => p.disponible !== false)
            .forEach(p => {
                const opt = document.createElement('option');
                opt.value = p.id_producto;
                opt.textContent = p.nombre;
                sel.appendChild(opt);
            });
    } catch (e) { console.error('[PRECIOS] cargarSelectProductos:', e); }
}

async function prc_cargarHistorial() {
    try {
        const token = localStorage.getItem('token') || sessionStorage.getItem('token') || '';
        const res = await fetch(`${API_URL}/precios`, {
            headers: { Authorization: `Bearer ${token}` }
        });
        const datos = await res.json();
        _prc_lista = Array.isArray(datos) ? datos : [];
        prc_renderTabla();
    } catch (e) { console.error('[PRECIOS] cargarHistorial:', e); }
}

// ── Cuando cambia el producto en el select ──────────────────
// Pre-rellena el input con el precio actual y muestra el preview
function prc_alProductoCambia(id_producto) {
    const wrap = document.getElementById('prc_precio_actual_wrap');
    const val = document.getElementById('prc_precio_actual_val');
    const inp = document.getElementById('prc_inp_precio_base');
    const prev = document.getElementById('prc_preview_venta');

    if (!id_producto) {
        if (wrap) wrap.style.display = 'none';
        if (prev) prev.style.display = 'none';
        if (inp) inp.value = '';
        return;
    }
    const actual = _prc_lista.find(p => String(p.id_producto) === String(id_producto));
    if (actual) {
        const fmt = v => new Intl.NumberFormat('es-CO', { style: 'currency', currency: 'COP', minimumFractionDigits: 0 }).format(v);
        if (val) val.textContent = fmt(actual.precio_base_kg);
        if (wrap) wrap.style.display = 'block';
        if (inp) { inp.value = actual.precio_base_kg; prc_previewVenta(); }
    } else {
        if (wrap) wrap.style.display = 'none';
        if (inp) inp.value = '';
        if (prev) prev.style.display = 'none';
    }
}

// ── Preview de precios de venta en tiempo real ──────────────
// Muestra cuanto cobraria el operario al comerciante segun la regla
function prc_previewVenta() {
    const base = parseFloat(document.getElementById('prc_inp_precio_base')?.value || '0');
    const prev = document.getElementById('prc_preview_venta');
    const elP = document.getElementById('prc_prev_primo');
    const elO = document.getElementById('prc_prev_otro');
    if (!prev) return;
    if (!base || base <= 0) { prev.style.display = 'none'; return; }
    const fmt = v => new Intl.NumberFormat('es-CO', { style: 'currency', currency: 'COP', minimumFractionDigits: 0 }).format(v);
    if (elP) elP.textContent = fmt(base);        // EL PRIMO -> precio base
    if (elO) elO.textContent = fmt(base + 100);  // otros    -> base + $100/kg
    prev.style.display = 'block';
}

// ── Guardar precio base ──────────────────────────────────────
// Solo guarda producto + precio_base_kg.
// El descuento de transporte y asociacion se calcula al cerrar la ruta.
async function prc_guardarPrecioBase() {
    const id_producto = parseInt(document.getElementById('prc_sel_producto')?.value || '0');
    const precio_base_kg = parseFloat(document.getElementById('prc_inp_precio_base')?.value || '0');

    const showMsg = (msg, ok) => {
        const b = document.getElementById('prc_banner_form');
        if (!b) return prc_banner(msg, ok ? 'ok' : 'err');
        b.style.display = 'block';
        b.style.background = ok ? '#d1fae5' : '#fee2e2';
        b.style.color = ok ? '#065f46' : '#991b1b';
        b.textContent = msg;
        if (ok) setTimeout(() => { b.style.display = 'none'; }, 3000);
    };

    if (!id_producto) return showMsg('Selecciona un producto.', false);
    if (!precio_base_kg || precio_base_kg <= 0) return showMsg('Ingresa un precio base válido (mayor que 0).', false);

    const dto = { id_producto, precio_base_kg, precio_transporte: 0, total_kilos: 1, comerciante: 'GENERAL' };

    showLoading();
    try {
        const token = localStorage.getItem('token') || sessionStorage.getItem('token') || '';
        const res = await fetch(`${API_URL}/precios`, {
            method: 'POST',
            headers: { 'Content-Type': 'application/json', Authorization: `Bearer ${token}` },
            body: JSON.stringify(dto)
        });
        if (!res.ok) { const err = await res.json(); throw new Error(err.message || err.error || 'Error al guardar'); }
        showMsg(' Precio guardado correctamente.', true);
        prc_limpiarFormulario();
        await prc_cargarHistorial();
    } catch (e) {
        showMsg(e.message, false);
    } finally { hideLoading(); }
}

// ── Tabla de precios vigentes ────────────────────────────────
function prc_renderTabla() {
    const tbody = document.getElementById('prc_tbody');
    if (!tbody) return;
    const fmt = v => new Intl.NumberFormat('es-CO', { style: 'currency', currency: 'COP', minimumFractionDigits: 0 }).format(v);

    const lista = _prc_lista.filter(p => {
        if (!_prc_buscar) return true;
        return (p.producto?.nombre || '').toLowerCase().includes(_prc_buscar);
    });

    if (!lista.length) {
        tbody.innerHTML = `<tr><td colspan="7" class="empty-state">Sin precios registrados</td></tr>`;
        return;
    }

    tbody.innerHTML = lista.map(p => {
        const base = Number(p.precio_base_kg);
        const primo = base;
        const otros = base + 100;
        const fecha = p.fecha ? fmtFechaLocal(p.fecha) : '—';
        const badge = p.activo
            ? `<span style="background:#d1fae5;color:#065f46;border-radius:99px;padding:2px 9px;font-size:.72rem;font-weight:700">Activo</span>`
            : `<span style="background:#f3f4f6;color:#6b7280;border-radius:99px;padding:2px 9px;font-size:.72rem;font-weight:700">Inactivo</span>`;
        return `<tr>
            <td><strong>${p.producto?.nombre || '#' + p.id_producto}</strong></td>
            <td style="text-align:right;font-weight:600">${fmt(base)}</td>
            <td style="text-align:right;color:#16a34a;font-weight:700">${fmt(primo)}</td>
            <td style="text-align:right;color:#2563eb;font-weight:700">${fmt(otros)}</td>
            <td style="font-size:.82em;color:#6b7280">${fecha}</td>
            <td>${badge}</td>
            <td>
                <button class="usr-btn-action usr-btn-edit" title="Editar"
                        onclick="prc_editar(${p.id_precio}, ${p.id_producto}, ${base})">
                    <i class="fi fi-rr-edit"></i>
                </button>
            </td>
        </tr>`;
    }).join('');
}

// ── Editar precio desde la tabla ─────────────────────────────
function prc_editar(id_precio, id_producto, precio_actual) {
    const sel = document.getElementById('prc_sel_producto');
    const inp = document.getElementById('prc_inp_precio_base');
    if (sel) sel.value = String(id_producto);
    if (inp) { inp.value = precio_actual; prc_previewVenta(); }
    prc_alProductoCambia(id_producto);
    sel?.scrollIntoView({ behavior: 'smooth', block: 'center' });
}

function prc_filtrar(val) {
    _prc_buscar = val.toLowerCase();
    prc_renderTabla();
}

function prc_limpiarFormulario() {
    const sel = document.getElementById('prc_sel_producto');
    const inp = document.getElementById('prc_inp_precio_base');
    const prev = document.getElementById('prc_preview_venta');
    const wrap = document.getElementById('prc_precio_actual_wrap');
    if (sel) sel.value = '';
    if (inp) inp.value = '';
    if (prev) prev.style.display = 'none';
    if (wrap) wrap.style.display = 'none';
}

function prc_banner(msg, tipo) {
    const el = document.getElementById('prc_banner');
    if (!el) return;
    el.style.display = 'block';
    el.style.background = tipo === 'ok' ? '#d1fae5' : '#fee2e2';
    el.style.color = tipo === 'ok' ? '#065f46' : '#991b1b';
    el.textContent = msg;
    setTimeout(() => { el.style.display = 'none'; }, 4500);
}

// ── Hook en mostrarSeccion ───────────────────────────────────
(function () {
    const _orig = window.mostrarSeccion;
    window.mostrarSeccion = function (sectionId) {
        _orig(sectionId);
        if (sectionId === 'precios') prc_cargar();
    };

    // Verificar alerta al arrancar
    window.addEventListener('DOMContentLoaded', () => {
        setTimeout(prc_verificarAlertaSemanal, 2000);
    });
})();

// ════════════════════════════════════════════════════════════════════════
//  STOCK / INVENTARIO — Admin
// ════════════════════════════════════════════════════════════════════════

let _stk_todos = [];
let _stk_filtro = '';

async function stk_cargar() {
    try {
        const token = localStorage.getItem('token') || '';
        const res = await fetch(`${API_URL}/stock`, {
            headers: { Authorization: `Bearer ${token}` }
        });
        if (!res.ok) throw new Error('Error al cargar stock');
        _stk_todos = await res.json();
        stk_renderKpis();
        stk_renderTabla();
        stk_cargarMovimientos();
    } catch (e) {
        console.error('[STOCK]', e.message);
    }
}

function stk_filtrar(q) {
    _stk_filtro = q.toLowerCase();
    stk_renderTabla();
}

function stk_renderKpis() {
    const container = document.getElementById('stk_kpis');
    if (!container) return;
    const fmt = n => new Intl.NumberFormat('es-CO', { maximumFractionDigits: 2 }).format(n ?? 0) + ' kg';
    const totalDisp = _stk_todos.reduce((s, x) => s + Number(x.kilos_disponibles ?? 0), 0);
    const totalAcum = _stk_todos.reduce((s, x) => s + Number(x.kilos_acumulados ?? 0), 0);
    const sinStock = _stk_todos.filter(x => Number(x.kilos_disponibles) <= 0).length;
    const bajStock = _stk_todos.filter(x => Number(x.kilos_disponibles) > 0 && Number(x.kilos_disponibles) < 50).length;

    container.innerHTML = [
        { label: 'Total disponible', value: fmt(totalDisp), color: '#16a34a', bg: '#f0fdf4', icon: '' },
        { label: 'Total acumulado', value: fmt(totalAcum), color: '#1d4ed8', bg: '#eff6ff', icon: '' },
        { label: 'Productos sin stock', value: sinStock, color: sinStock ? '#dc2626' : '#16a34a', bg: sinStock ? '#fef2f2' : '#f0fdf4', icon: '' },
        { label: 'Stock bajo (< 50 kg)', value: bajStock, color: bajStock ? '#d97706' : '#16a34a', bg: bajStock ? '#fffbeb' : '#f0fdf4', icon: '' },
    ].map(k => `
        <div style="background:${k.bg};border-radius:14px;padding:16px 18px">
            <div style="font-size:1.2rem;margin-bottom:4px">${k.icon}</div>
            <div style="font-size:.75rem;color:#6b7280;font-weight:600;text-transform:uppercase;margin-bottom:4px">${k.label}</div>
            <div style="font-size:1.5rem;font-weight:800;color:${k.color}">${k.value}</div>
        </div>`).join('');
}

function stk_renderTabla() {
    const tbody = document.getElementById('stk_tbody');
    if (!tbody) return;
    const fmt = n => new Intl.NumberFormat('es-CO', { maximumFractionDigits: 2 }).format(n ?? 0) + ' kg';

    const lista = _stk_todos.filter(s =>
        !_stk_filtro || (s.producto || '').toLowerCase().includes(_stk_filtro)
    );

    const count = document.getElementById('stk_count');
    if (count) count.textContent = `${lista.length} producto${lista.length !== 1 ? 's' : ''}`;

    if (!lista.length) {
        tbody.innerHTML = '<tr><td colspan="6" class="empty-state">Sin datos de stock. Las rutas cerradas generan entradas de stock automáticamente.</td></tr>';
        return;
    }

    tbody.innerHTML = lista.map(s => {
        const disp = Number(s.kilos_disponibles ?? 0);
        const acum = Number(s.kilos_acumulados ?? 0);
        const pct = acum > 0 ? Math.min(100, Math.round((disp / acum) * 100)) : 0;
        const barColor = pct > 50 ? '#16a34a' : pct > 20 ? '#f59e0b' : '#ef4444';

        const badge = disp <= 0
            ? '<span style="background:#fee2e2;color:#dc2626;border-radius:99px;padding:2px 9px;font-size:.72rem;font-weight:700">Sin stock</span>'
            : disp < 50
                ? '<span style="background:#fef3c7;color:#92400e;border-radius:99px;padding:2px 9px;font-size:.72rem;font-weight:700"> Bajo</span>'
                : '<span style="background:#d1fae5;color:#065f46;border-radius:99px;padding:2px 9px;font-size:.72rem;font-weight:700"> Disponible</span>';

        return `<tr>
            <td style="font-weight:600">${s.producto}</td>
            <td style="text-align:right;font-weight:700;color:#16a34a;font-size:1.05rem">${fmt(disp)}</td>
            <td style="text-align:right;color:#6b7280">${fmt(acum)}</td>
            <td>
                <div style="background:#f3f4f6;border-radius:99px;height:8px;overflow:hidden;min-width:80px">
                    <div style="background:${barColor};height:8px;width:${pct}%;border-radius:99px"></div>
                </div>
                <div style="font-size:.7rem;color:#9ca3af;margin-top:2px">${pct}% disponible</div>
            </td>
            <td>${badge}</td>
            <td>
                <button onclick="stk_filtrarMovPorProducto(${s.id_producto}, '${s.producto}')"
                    style="background:#f0fdf4;color:#166534;border:1px solid #bbf7d0;border-radius:6px;
                           padding:3px 10px;font-size:.75rem;cursor:pointer;font-weight:600">
                    Ver movimientos
                </button>
            </td>
        </tr>`;
    }).join('');
}

async function stk_cargarMovimientos(id_producto) {
    const tbody = document.getElementById('stk_movs_tbody');
    if (!tbody) return;
    tbody.innerHTML = '<tr><td colspan="6" style="text-align:center;padding:20px;color:#9ca3af">Cargando...</td></tr>';

    try {
        const token = localStorage.getItem('token') || '';
        const tipo = document.getElementById('stk_filtro_tipo')?.value || '';
        let url = `${API_URL}/stock/movimientos`;
        const params = [];
        if (id_producto) params.push(`id_producto=${id_producto}`);
        if (tipo) params.push(`tipo=${tipo}`);
        if (params.length) url += '?' + params.join('&');

        const res = await fetch(url, { headers: { Authorization: `Bearer ${token}` } });
        if (!res.ok) throw new Error('Error al cargar movimientos');
        const movs = await res.json();

        const fmt = n => new Intl.NumberFormat('es-CO', { maximumFractionDigits: 2 }).format(n) + ' kg';
        const fmtF = f => f ? fmtFechaLocal(f) : '—';

        if (!movs.length) {
            tbody.innerHTML = '<tr><td colspan="6" class="empty-state">Sin movimientos registrados</td></tr>';
            return;
        }

        tbody.innerHTML = movs.map(m => {
            const entrada = m.tipo === 'ENTRADA';
            return `<tr>
                <td style="font-size:.83rem;color:#6b7280;white-space:nowrap">${fmtF(m.fecha)}</td>
                <td>
                    <span style="background:${entrada ? '#d1fae5' : '#fee2e2'};color:${entrada ? '#065f46' : '#dc2626'};
                        border-radius:99px;padding:2px 9px;font-size:.72rem;font-weight:700">
                        ${entrada ? '▲ Entrada' : '▼ Salida'}
                    </span>
                </td>
                <td style="font-weight:600">${m.producto || '—'}</td>
                <td style="text-align:right;font-weight:700;color:${entrada ? '#16a34a' : '#dc2626'}">
                    ${entrada ? '+' : '-'}${fmt(m.kilos)}
                </td>
                <td>
                    <span style="font-size:.78rem;background:#f3f4f6;border-radius:6px;padding:2px 8px">
                        ${m.referencia_tipo || '—'} #${m.referencia_id || '—'}
                    </span>
                </td>
                <td style="font-size:.78rem;color:#6b7280">${m.descripcion || '—'}</td>
            </tr>`;
        }).join('');
    } catch (e) {
        if (tbody) tbody.innerHTML = `<tr><td colspan="6" class="empty-state">Error: ${e.message}</td></tr>`;
    }
}

let _stk_filtro_prod = null;
function stk_filtrarMovPorProducto(id_producto, nombre) {
    _stk_filtro_prod = id_producto;
    // Scroll to movimientos
    document.getElementById('stk_movs_tbody')?.scrollIntoView({ behavior: 'smooth' });
    stk_cargarMovimientos(id_producto);
}

// Polling: actualizar stock cada 30 seg cuando la sección está visible
setInterval(() => {
    const seccion = document.getElementById('stock');
    if (seccion && seccion.classList.contains('active')) {
        stk_cargar();
    }
}, 30000);

// ════════════════════════════════════════════════════════
//  HELPERS FILTRO FECHA — COMPRAS Y VENTAS
// ════════════════════════════════════════════════════════

function cmp_aplicarFiltroFecha() {
    _cmp_fechaDesde = document.getElementById('cmp_fecha_desde').value;
    _cmp_fechaHasta = document.getElementById('cmp_fecha_hasta').value;
    cmp_renderTabla();
}

function cmp_limpiarFechas() {
    document.getElementById('cmp_fecha_desde').value = '';
    document.getElementById('cmp_fecha_hasta').value = '';
    _cmp_fechaDesde = '';
    _cmp_fechaHasta = '';
    cmp_renderTabla();
}

function vnt_aplicarFiltroFecha() {
    _vnt_fechaDesde = document.getElementById('vnt_fecha_desde').value;
    _vnt_fechaHasta = document.getElementById('vnt_fecha_hasta').value;
    vnt_renderTabla();
}

function vnt_limpiarFechas() {
    document.getElementById('vnt_fecha_desde').value = '';
    document.getElementById('vnt_fecha_hasta').value = '';
    _vnt_fechaDesde = '';
    _vnt_fechaHasta = '';
    vnt_renderTabla();
}

// ════════════════════════════════════════════════════════
//  HELPERS FILTRO FECHA — COMPRAS Y VENTAS
// ════════════════════════════════════════════════════════

function cmp_aplicarFiltroFecha() {
    _cmp_fechaDesde = document.getElementById('cmp_fecha_desde').value;
    _cmp_fechaHasta = document.getElementById('cmp_fecha_hasta').value;
    cmp_renderTabla();
}

function cmp_limpiarFechas() {
    document.getElementById('cmp_fecha_desde').value = '';
    document.getElementById('cmp_fecha_hasta').value = '';
    _cmp_fechaDesde = '';
    _cmp_fechaHasta = '';
    cmp_renderTabla();
}

function vnt_aplicarFiltroFecha() {
    _vnt_fechaDesde = document.getElementById('vnt_fecha_desde').value;
    _vnt_fechaHasta = document.getElementById('vnt_fecha_hasta').value;
    vnt_renderTabla();
}

function vnt_limpiarFechas() {
    document.getElementById('vnt_fecha_desde').value = '';
    document.getElementById('vnt_fecha_hasta').value = '';
    _vnt_fechaDesde = '';
    _vnt_fechaHasta = '';
    vnt_renderTabla();
}