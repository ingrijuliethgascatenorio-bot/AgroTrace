import { Injectable, UnauthorizedException } from '@nestjs/common';
import { PassportStrategy } from '@nestjs/passport';
import { ExtractJwt, Strategy } from 'passport-jwt';
import { UsersService } from '../users/users.service';

@Injectable()
export class JwtStrategy extends PassportStrategy(Strategy) {
  constructor(private usersService: UsersService) {
    super({
      jwtFromRequest: ExtractJwt.fromAuthHeaderAsBearerToken(),
      ignoreExpiration: false,
      secretOrKey: process.env.JWT_SECRET || 'secret_agrotrace_2024',
    });
  }

  // ✅ CORREGIDO: validar que el usuario sigue activo en cada request
  async validate(payload: { id_usuario: number; tipo_usuario: string; email: string; permisos: string[] }) {
    const usuario = await this.usersService.buscarPorId(payload.id_usuario);
    if (!usuario || !usuario.activo) {
      throw new UnauthorizedException('Sesion invalida o usuario inactivo');
    }
    // Devolver el objeto completo: se accede como req.user en los controllers
    const { password: _, ...user } = usuario;
    return user;
  }
}
