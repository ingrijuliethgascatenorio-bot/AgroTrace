import {
  Column,
  Entity,
  JoinColumn,
  ManyToOne,
  OneToMany,
  PrimaryGeneratedColumn,
} from 'typeorm';
import { Usuario } from '../users/entities/usuario.entity';
import { DetalleVenta } from './detalle_venta.entity';
import { Comerciante } from '../comerciante/comerciante.entity';

@Entity('venta')
export class Venta {
  @PrimaryGeneratedColumn({ name: 'id_venta' })
  id_venta: number;

  @Column({ name: 'id_operario' })
  id_operario: number;

  // ✅ CORREGIDO: nullable para que operario pueda registrar sin comerciante
  @Column({ name: 'id_comerciante', nullable: true })
  id_comerciante: number | null;

  @Column({ type: 'date', name: 'fecha_venta' })
  fecha_venta: string;

  @Column({ type: 'decimal', precision: 12, scale: 2, default: 0 })
  total: number;

  @Column({ default: 'pendiente' })
  estado: string;

  @Column({ nullable: true, unique: true, name: 'numero_factura' })
  numero_factura: string;

  /**
   * Nombre del cliente/comerciante como texto libre.
   * La BD tiene esta columna NOT NULL — se llena con el nombre del comerciante
   * o 'Cliente general' si no se especifica.
   */
  @Column({ nullable: true, default: '' })
  cliente: string;

  @ManyToOne(() => Usuario, { nullable: true, eager: false })
  @JoinColumn({ name: 'id_operario' })
  operario: Usuario;

  @ManyToOne(() => Comerciante, { nullable: true, eager: false })
  @JoinColumn({ name: 'id_comerciante' })
  comerciante: Comerciante;

  @OneToMany(() => DetalleVenta, (d) => d.venta, { cascade: true, eager: true })
  detalles: DetalleVenta[];
}
