import {
  Entity,
  PrimaryGeneratedColumn,
  Column,
  CreateDateColumn,
  ManyToOne,
  JoinColumn,
} from 'typeorm';
import { Productor } from '../productor/productores.entity';
import { Usuario } from '../users/entities/usuario.entity';
import { Producto } from '../productos/producto.entity';

@Entity('entrega')
export class Entrega {
  @PrimaryGeneratedColumn()
  id_entrega: number;

  @Column()
  id_operario: number;

  /**
   * 'AFILIADO' → productor con QR registrado en el sistema
   * 'EXTERNO'   → persona sin cuenta, datos ingresados manualmente
   */
  @Column({ type: 'varchar', length: 10, default: 'AFILIADO' })
  tipo_productor: string;

  /** NULL cuando tipo_productor = 'EXTERNO' */
  @Column({ nullable: true, default: null })
  id_productor: number | null;

  /** Nombre del productor externo (solo cuando tipo_productor = 'EXTERNO') */
  @Column({ type: 'varchar', length: 150, nullable: true, default: null })
  nombre_productor_externo: string | null;

  /** Teléfono del productor externo (opcional) */
  @Column({ type: 'varchar', length: 30, nullable: true, default: null })
  telefono_productor_externo: string | null;

  @Column()
  id_producto: number;

  /**
   * Nombre libre cuando el operario selecciona "Otro producto".
   * NULL cuando se usa un producto del catálogo.
   */
  @Column({ type: 'varchar', length: 150, nullable: true, default: null })
  nombre_producto_otro: string | null;

  @Column({ type: 'decimal', precision: 10, scale: 2, default: 0 })
  peso_kg: number;

  @Column({ type: 'int', default: 0 })
  cantidad_unidades: number;

  /** NULL hasta que se liquide la ruta. En modo legacy se asigna al registrar. */
  @Column({
    type: 'decimal',
    precision: 10,
    scale: 2,
    nullable: true,
    default: null,
  })
  precio_unitario: number | null;

  /** NULL hasta que se liquide la ruta. */
  @Column({
    type: 'decimal',
    precision: 12,
    scale: 2,
    nullable: true,
    default: null,
  })
  total: number | null;

  @CreateDateColumn()
  fecha: Date;

  // ── Ruta dinamica ──────────────────────────────────────────────────────
  /** FK hacia la ruta. NULL = modo legacy (precio asignado al registrar) */
  @Column({ nullable: true, default: null, name: 'ruta_id' })
  ruta_id: number | null;

  /**
   * PENDIENTE_LIQUIDACION  → sin precio aun
   * LIQUIDADO              → precio asignado al cerrar ruta
   * PAGADO                 → comprobante subido
   */
  @Column({ type: 'varchar', length: 30, default: 'PENDIENTE_LIQUIDACION' })
  estado_liquidacion: string;

  // ── Comprobante de pago ────────────────────────────────────────────────
  @Column({ type: 'text', nullable: true, default: null })
  comprobante_pago: string | null;

  @Column({ type: 'varchar', length: 20, default: 'PENDIENTE' })
  estado_pago: string;

  @Column({ type: 'timestamp', nullable: true, default: null })
  fecha_pago: Date | null;

  // ── Relaciones ─────────────────────────────────────────────────────────
  @ManyToOne(() => Productor, { eager: false })
  @JoinColumn({ name: 'id_productor' })
  productor: Productor;

  @ManyToOne(() => Usuario, { eager: false })
  @JoinColumn({ name: 'id_operario' })
  operario: Usuario;

  @ManyToOne(() => Producto, { eager: false })
  @JoinColumn({ name: 'id_producto' })
  producto: Producto;
}
